// -----------------------------------------------------------------------------
// THE LIVING ABYSS — rock material family
// One shader, five geological families, chosen per formation. A basalt trench
// wall and a limestone shelf no longer share a single grey value, but they are
// still lit by the same water, so the world stays coherent.
// -----------------------------------------------------------------------------
import * as THREE from '../../vendor/three.module.js';
import { GLSL_HEADER, withShared } from '../shaders/common.js?rev=09';

export const FAMILY = {
  limestone: 0,
  reef: 1,
  sandstone: 2,
  basalt: 3,
  mineral: 4,
};

export const ROCK_VS = /* glsl */`
attribute float aAO;
varying vec3 vWorld;
varying vec3 vNrm;
varying float vAO;
void main(){
  vec4 local = vec4(position, 1.0);
  vec3 objectNormal = normal;
  #ifdef USE_INSTANCING
    local = instanceMatrix * local;
    // Correct for the non-uniform instance scales used by boulders/rubble.
    mat3 im = mat3(instanceMatrix);
    objectNormal /= vec3(dot(im[0],im[0]), dot(im[1],im[1]), dot(im[2],im[2]));
    objectNormal = im * objectNormal;
  #endif
  vec4 wp = modelMatrix * local;
  vWorld = wp.xyz;
  vNrm = normalize(mat3(modelMatrix) * objectNormal);
  vAO = aAO;
  gl_Position = projectionMatrix * viewMatrix * wp;
}
`;

export const ROCK_FS = GLSL_HEADER + /* glsl */`
uniform float uDetail;
uniform float uDarken;
uniform float uCaveLit;      // 1 = surface rock, 0 = deep interior rock
uniform sampler2D uRockColorMap;
uniform sampler2D uRockNormalMap;
uniform sampler2D uRockRoughnessMap;
uniform float uRockMapsReady;
varying vec3 vWorld;
varying vec3 vNrm;
varying float vAO;

void main(){
  vec3 N = normalize(vNrm);
  // procedural detail must not alias into moiré at distance
  float dcam = length(uCamPos - vWorld);
  float nf = 1.0 - smoothstep(24.0, 260.0, dcam);

  float detailH;
  vec3 albedo = rockAlbedo(vWorld, N, 1.0, nf, detailH);
  N = sandRippleNormal(vWorld, N, nf);

  // interior rock is darker and more mineral, with no sediment rain
  albedo = mix(albedo * vec3(0.66, 0.72, 0.80), albedo, uCaveLit);

  N = perturbNormal(vWorld, N, 0.42, uDetail * (0.66 + 0.55 * nf));
  if (nf > 0.02) {
    N = perturbNormal(vWorld, N, 1.8, uDetail * 0.40 * nf);
    N = perturbNormal(vWorld, N, 6.5, uDetail * 0.20 * nf);
  }

  float roughness = 0.72;
  // CC0 rock scan used only for limestone and sandstone: triplanar projection
  // avoids UV stretching on the original irregular geometry. Existing family
  // palettes, erosion, lighting and procedural relief remain in place.
  float mappedFamily = (uFamily < 0.5 || (uFamily > 1.5 && uFamily < 2.5)) ? 1.0 : 0.0;
  if (uRockMapsReady > 0.5 && mappedFamily > 0.5 && nf > 0.02) {
    vec3 w = pow(abs(normalize(vNrm)), vec3(4.0));
    w /= max(w.x + w.y + w.z, 0.0001);
    vec3 q = vWorld * 0.48;
    vec3 colX = texture2D(uRockColorMap, q.yz).rgb;
    vec3 colY = texture2D(uRockColorMap, q.xz).rgb;
    vec3 colZ = texture2D(uRockColorMap, q.xy).rgb;
    vec3 mapped = colX * w.x + colY * w.y + colZ * w.z;
    albedo *= mix(vec3(1.0), clamp(mapped * 1.8 + 0.25, 0.45, 1.6), 0.48 * nf);

    vec3 nx = texture2D(uRockNormalMap, q.yz).xyz * 2.0 - 1.0;
    vec3 ny = texture2D(uRockNormalMap, q.xz).xyz * 2.0 - 1.0;
    vec3 nz = texture2D(uRockNormalMap, q.xy).xyz * 2.0 - 1.0;
    vec3 baseN = normalize(vNrm);
    vec3 texN = normalize(vec3(nx.z * sign(baseN.x), nx.x, nx.y) * w.x
                        + vec3(ny.x, ny.z * sign(baseN.y), ny.y) * w.y
                        + vec3(nz.x, nz.y, nz.z * sign(baseN.z)) * w.z);
    N = normalize(mix(N, texN, 0.20 * nf));
    float r = texture2D(uRockRoughnessMap, q.yz).r * w.x
            + texture2D(uRockRoughnessMap, q.xz).r * w.y
            + texture2D(uRockRoughnessMap, q.xy).r * w.z;
    roughness = mix(roughness, clamp(r, 0.35, 0.96), 0.65 * nf);
  }
  vec3 col = litSurface(albedo, N, vWorld, roughness, clamp(vAO, 0.0, 1.0), 1.0);
  col *= uDarken;
  col = applyWater(col, vWorld);
  gl_FragColor = vec4(col, 1.0);
}
`;

// Asset is loaded once and shared by every rock material. Node-based geometry
// tests have no DOM and simply keep the original procedural shader fallback.
const rockMaps = {
  uRockColorMap: { value: null }, uRockNormalMap: { value: null },
  uRockRoughnessMap: { value: null }, uRockMapsReady: { value: 0 },
};
if (typeof document !== 'undefined') {
  const loader = new THREE.TextureLoader();
  const root = './assets/textures/rock022/';
  let loaded = 0;
  const load = (uniform, file, srgb) => {
    const tex = loader.load(root + file, () => {
      if (++loaded === 3) rockMaps.uRockMapsReady.value = 1;
    }, undefined, (error) => console.warn('Rock texture could not be loaded; retaining procedural material.', error));
    tex.wrapS = tex.wrapT = THREE.RepeatWrapping;
    if (srgb) tex.colorSpace = THREE.SRGBColorSpace;
    uniform.value = tex;
  };
  load(rockMaps.uRockColorMap, 'Rock022_1K-JPG_Color.jpg', true);
  load(rockMaps.uRockNormalMap, 'Rock022_1K-JPG_NormalGL.jpg', false);
  load(rockMaps.uRockRoughnessMap, 'Rock022_1K-JPG_Roughness.jpg', false);
}

const cache = new Map();

/**
 * @param {object} opts family: 'limestone'|'reef'|'sandstone'|'basalt'|'mineral'
 */
export function createRockMaterial(opts = {}) {
  const fam = opts.family ?? 'limestone';
  const key = [
    fam, opts.detail ?? 1, opts.darken ?? 1, opts.caveLit ?? 1,
    opts.wetness ?? 0.6, opts.mineral ?? 0, opts.side ?? 'front',
  ].join('|');
  if (!opts.unique && cache.has(key)) return cache.get(key);

  const mat = new THREE.ShaderMaterial({
    uniforms: withShared({
      ...rockMaps,
      uDetail: { value: opts.detail ?? 1.0 },
      uDarken: { value: opts.darken ?? 1.0 },
      uCaveLit: { value: opts.caveLit ?? 1.0 },
      uFamily: { value: FAMILY[fam] ?? 0 },
      uWetness: { value: opts.wetness ?? 0.6 },
      uMineral: { value: opts.mineral ?? 0 },
    }),
    vertexShader: ROCK_VS,
    fragmentShader: ROCK_FS,
    side: opts.side === 'double' ? THREE.DoubleSide : THREE.FrontSide,
    transparent: !!opts.transparent,
  });
  mat.name = 'rock_' + fam;
  cache.set(key, mat);
  return mat;
}

export const rockMaterial = createRockMaterial({ family: 'limestone', detail: 1.0 });

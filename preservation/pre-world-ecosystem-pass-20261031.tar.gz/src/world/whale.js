// One licensed animated blue whale on a small open-water patrol. Non-solid,
// sampled clearance only; no claim of real migration or collision-certified AI.
import * as THREE from '../../vendor/three.module.js';
import {GLTFLoader} from '../../vendor/jsm/loaders/GLTFLoader.js';
import {clone} from '../../vendor/jsm/utils/SkeletonUtils.js';
import {withShared} from '../shaders/common.js?rev=09';
import {MARINE_VS,MARINE_FS} from './large-marine.js?rev=09';
import {planWhaleRoute} from './whale-route.js?rev=09';

export async function addBlueWhale(scene,field,colliders){
 const route=planWhaleRoute(field,colliders);if(!route)return null;
 const asset=await new GLTFLoader().loadAsync('./assets/models/marine_pass12/blue-whale.glb');
 if(!asset.animations.length)throw new Error('Blue-whale animation missing');
 const model=clone(asset.scene),orient=new THREE.Group();orient.rotation.y=Math.PI/2;orient.add(model);
 const mixer=new THREE.AnimationMixer(model);mixer.clipAction(asset.animations[0]).play();mixer.update(0);
 orient.updateMatrixWorld(true);
 const bounds=new THREE.Box3().setFromObject(orient),size=bounds.getSize(new THREE.Vector3()),center=bounds.getCenter(new THREE.Vector3());
 if(!Number.isFinite(size.x)||size.x<.01)throw new Error('Invalid whale model bounds');
 orient.position.copy(center).multiplyScalar(-1);
 const rig=new THREE.Group();rig.add(orient);rig.scale.setScalar(route.size/size.x);
 const host=new THREE.Group();host.name='blue_whale_visitor';host.add(rig);
 const white=new THREE.DataTexture(new Uint8Array([255,255,255,255]),1,1);white.needsUpdate=true;
 const materials=new Map();model.traverse(o=>{
  if(!o.isMesh)return;
  const old=o.material;
  if(!materials.has(old))materials.set(old,new THREE.ShaderMaterial({
   uniforms:withShared({uMap:{value:old.map||white},uBase:{value:old.color?.clone()||new THREE.Color(1,1,1)},uMapped:{value:old.map?1:0}}),
   vertexShader:MARINE_VS,fragmentShader:MARINE_FS,side:THREE.DoubleSide,
  }));
  o.material=materials.get(old);o.frustumCulled=false;
 });
 const state={...route,host,mixer};scene.add(host);
 function update(dt,camera){
  const d2=host.position.distanceToSquared(camera),factor=d2<400?.5:1;
  state.phase+=Math.min(dt,.1)*state.speed*factor;
  const a=state.phase;
  host.position.set(state.x+Math.cos(a)*state.radius,state.y,state.z+Math.sin(a)*state.radius);
  host.rotation.y=Math.atan2(-Math.cos(a),-Math.sin(a));
  host.visible=host.position.distanceToSquared(camera)<240*240;
  if(host.visible)mixer.update(dt*factor);
 }
 host.position.set(route.x+Math.cos(route.phase)*route.radius,route.y,route.z+Math.sin(route.phase)*route.radius);
 return {state,update};
}

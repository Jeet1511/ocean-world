// A single blue-whale encounter in the deeper open water near Azure Span.
// Clearance is sampled against terrain and conservative rock bounds. This is
// deliberately not presented as a continuous collision-certified animal AI.
import {mulberry32} from '../core/noise.js?rev=09';
export function planWhaleRoute(field,colliders=[]){
 const rng=mulberry32(53124);
 for(let attempt=0;attempt<4000;attempt++){
  const a=rng()*Math.PI*2,r=Math.sqrt(rng())*230;
  const x=-480+Math.cos(a)*r,z=-340+Math.sin(a)*r,radius=22+rng()*8;
  let highest=-Infinity;
  for(let k=0;k<24;k++){
   const a=k*Math.PI/12,cx=x+Math.cos(a)*radius,cz=z+Math.sin(a)*radius;
   for(const [u,v] of [[0,0],[12,0],[-12,0],[0,12],[0,-12]])highest=Math.max(highest,field.surfaceHeightAt(cx+u,cz+v));
  }
  if(highest>-100)continue;
  const y=Math.min(-45,highest+28);let safe=true;
  for(let k=0;k<24&&safe;k++){
   const a=k*Math.PI/12,px=x+Math.cos(a)*radius,pz=z+Math.sin(a)*radius;
   if(colliders.some(c=>{const b=c.visualBounds,m=12;return b&&px>b.min[0]-m&&px<b.max[0]+m&&y>b.min[1]-m&&y<b.max[1]+m&&pz>b.min[2]-m&&pz<b.max[2]+m;}))safe=false;
  }
  if(safe)return {kind:'blue_whale',place:'azurespan',x,y,z,radius,size:22,phase:1.0,speed:.05};
 }
 return null;
}

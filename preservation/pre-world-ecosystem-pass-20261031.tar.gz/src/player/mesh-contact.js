// Narrow-phase sphere/triangle resolution for authored closed walls and arches.
// Geometry has baked world coordinates and is shared among analytic broad-phase
// colliders. The surface, not the approximate cylinder/capsule, sets contact.
import * as THREE from '../../vendor/three.module.js';

export function createMeshContactGuard(geometry, {surfaceOnly = false} = {}) {
  const pos=geometry.attributes.position, index=geometry.index;
  const count=index ? index.count : pos.count;
  const triangles=[];
  for(let i=0;i+2<count;i+=3){
    const get=k=>index?index.getX(i+k):i+k;
    const a=new THREE.Vector3().fromBufferAttribute(pos,get(0));
    const b=new THREE.Vector3().fromBufferAttribute(pos,get(1));
    const c=new THREE.Vector3().fromBufferAttribute(pos,get(2));
    const tri=new THREE.Triangle(a,b,c);
    if(tri.getArea()<1e-10)continue;
    triangles.push({tri,minX:Math.min(a.x,b.x,c.x),minY:Math.min(a.y,b.y,c.y),minZ:Math.min(a.z,b.z,c.z),
      maxX:Math.max(a.x,b.x,c.x),maxY:Math.max(a.y,b.y,c.y),maxZ:Math.max(a.z,b.z,c.z)});
  }
  const temp=new THREE.Vector3(), nearest=new THREE.Vector3(),hit=new THREE.Vector3();
  const ray=new THREE.Ray(new THREE.Vector3(),new THREE.Vector3(.837,.337,.431).normalize());
  function inside(point){
    ray.origin.copy(point);const distances=[];
    for(const t of triangles)if(ray.intersectTriangle(t.tri.a,t.tri.b,t.tri.c,false,hit))distances.push(hit.distanceToSquared(point));
    distances.sort((a,b)=>a-b);let unique=0,last=-Infinity;
    for(const d of distances){if(Math.abs(d-last)>1e-5*Math.max(1,d)){unique++;last=d;}}
    return unique%2===1;
  }
  return {
    triangleCount:triangles.length,
    resolve(point,radius) {
      const r=radius+1e-5;let nearestSq=Infinity, nearestTri=null;
      // Search the actual surface near the swimmer, not the broad-phase shape.
      for(const t of triangles){
        if(point.x+r<t.minX||point.x-r>t.maxX||point.y+r<t.minY||point.y-r>t.maxY||point.z+r<t.minZ||point.z-r>t.maxZ)continue;
        t.tri.closestPointToPoint(point,temp);const d=temp.distanceToSquared(point);
        if(d<nearestSq){nearestSq=d;nearest.copy(temp);nearestTri=t.tri;}
      }
      const isInside=!surfaceOnly && inside(point);
      if(!isInside && nearestSq>=radius*radius)return false;
      if(isInside && nearestSq===Infinity){
        // Recovery for a pose already inside a shell (normal play encounters
        // the surface first). Find the closest actual triangle in the mesh.
        for(const t of triangles){t.tri.closestPointToPoint(point,temp);const d=temp.distanceToSquared(point);
          if(d<nearestSq){nearestSq=d;nearest.copy(temp);nearestTri=t.tri;}}
      }
      if(!nearestTri)return false;
      const distance=Math.sqrt(nearestSq), direction=new THREE.Vector3();
      if(distance>1e-7){direction.copy(point).sub(nearest).multiplyScalar((isInside?-1:1)/distance);}
      else {nearestTri.getNormal(direction);if(isInside)direction.negate();}
      const push=isInside ? distance+radius : radius-distance;
      if(push<=1e-7)return false;
      point.addScaledVector(direction,push+1e-5);return true;
    },
  };
}

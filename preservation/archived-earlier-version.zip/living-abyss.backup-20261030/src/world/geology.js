// -----------------------------------------------------------------------------
// THE LIVING ABYSS — monumental geology
// Everything here is generated as displaced, eroded, stratified rock: no
// cylinders, no boxes, no reused primitives. Towers grow out of the seabed they
// stand on (bases are always buried), arches spring from real rock shoulders,
// shelves overhang real cliffs, and every boulder is a unique noise-sculpted
// body with its own erosion history.
// -----------------------------------------------------------------------------
import * as THREE from '../../vendor/three.module.js';
import { mulberry32, noise3, fbm3, ridged2, clamp, lerp, smoothstep } from '../core/noise.js';
import { WORLD, CANYONS, CHAMBERS } from './geography.js';
import { createRockMaterial } from './rockmat.js';

const tmpN = { x: 0, y: 1, z: 0 };
const smoothstepJS = (e0, e1, x) => {
  const t = Math.max(0, Math.min(1, (x - e0) / (e1 - e0)));
  return t * t * (3 - 2 * t);
};

// ---------------------------------------------------------------------------
// displacement helpers
// ---------------------------------------------------------------------------
function displaceRock(geo, opts) {
  const {
    amp = 1, freq = 0.05, strataFreq = 0.12, strataAmp = 0.25,
    seed = 0, verticalBias = 0.0, sharpen = 1.0,
  } = opts;
  const pos = geo.attributes.position;
  const v = new THREE.Vector3();
  for (let i = 0; i < pos.count; i++) {
    v.fromBufferAttribute(pos, i);
    const px = v.x, py = v.y, pz = v.z;
    const n1 = fbm3(px * freq + seed, py * freq * 0.85 + seed * 0.7, pz * freq + seed * 1.3, 4);
    const n2 = fbm3(px * freq * 3.7 - seed, py * freq * 3.1, pz * freq * 3.7 + seed, 3);
    const strata = Math.sin(py * strataFreq + n1 * 3.4) * strataAmp;
    const r = 1 + (n1 * amp + n2 * amp * 0.32 + strata * 0.5) * sharpen;
    // radial push for lathe-like bodies, vertical shear otherwise
    const rad = Math.hypot(px, pz);
    if (rad > 1e-4 && verticalBias >= 0) {
      const s = r;
      v.x = px * s;
      v.z = pz * s;
    } else {
      v.x += n1 * amp; v.z += n2 * amp;
    }
    v.y += n2 * amp * 0.45 * (0.3 + verticalBias);
    pos.setXYZ(i, v.x, v.y, v.z);
  }
  geo.computeVertexNormals();
  return geo;
}

/** Per-vertex ambient occlusion baked from the shape's own noise + height. */
function bakeRockAO(geo, opts = {}) {
  const pos = geo.attributes.position;
  const ao = new Float32Array(pos.count);
  const { seed = 0, floorDark = 0.55, heightNorm = 1 } = opts;
  const box = new THREE.Box3().setFromBufferAttribute(pos);
  const hMin = box.min.y, hMax = box.max.y;
  for (let i = 0; i < pos.count; i++) {
    const x = pos.getX(i), y = pos.getY(i), z = pos.getZ(i);
    const t = heightNorm > 0 ? clamp((y - hMin) / Math.max(1e-3, hMax - hMin), 0, 1) : 0.5;
    const cav = fbm3(x * 0.22 + seed, y * 0.22, z * 0.22 - seed, 3);
    let a = floorDark + (1 - floorDark) * (0.35 + 0.65 * Math.pow(t, 0.7));
    a *= 0.68 + 0.42 * cav;
    ao[i] = clamp(a, 0.15, 1);
  }
  geo.setAttribute('aAO', new THREE.BufferAttribute(ao, 1));
  return geo;
}

// ---------------------------------------------------------------------------
// A natural rock tower: fluted, stratified, eroded, with buttresses and a
// broken crown. Built from a lathe of noise, never a cylinder.
// ---------------------------------------------------------------------------
function makeTower(rng, opts) {
  const height = opts.height;
  const rBase = opts.radius;
  const radial = 30, rings = 46;
  const seed = rng() * 100;

  // radius profile along height: bulges, pinches, overhang shoulders
  const profile = [];
  let p = 1.0;
  for (let i = 0; i <= rings; i++) {
    const t = i / rings;
    const bulge = 0.24 * Math.sin(t * 6.1 + seed) + 0.16 * Math.sin(t * 13.7 - seed * 2.1);
    const taper = 1.0 - 0.42 * Math.pow(t, 0.85);
    const overhang = t > 0.55 ? 0.22 * Math.pow((t - 0.55) / 0.45, 1.6) : 0;
    p = Math.max(0.16, taper * (1 + bulge) - overhang * 0.55);
    profile.push(p);
  }

  const posArr = [], idxArr = [], uvArr = [];
  const leanX = (rng() - 0.5) * 0.30, leanZ = (rng() - 0.5) * 0.30;
  for (let i = 0; i <= rings; i++) {
    const t = i / rings;
    const y = t * height;
    const prof = profile[i];
    for (let j = 0; j <= radial; j++) {
      const a = (j / radial) * Math.PI * 2;
      const ca = Math.cos(a), sa = Math.sin(a);
      // fluting: erosion channels down the face
      const flute = 1 + 0.085 * Math.sin(a * 7 + seed) + 0.05 * Math.sin(a * 13 - seed * 1.7);
      const nx = ca * prof * flute, nz = sa * prof * flute;
      const wx = nx * rBase + leanX * height * Math.pow(t, 1.7);
      const wz = nz * rBase + leanZ * height * Math.pow(t, 1.7);
      const wy = y + Math.sin(a * 3 + seed) * rBase * 0.06;
      // geological noise displacement (world-scale detail added by the shader)
      const n = fbm3(wx * 0.035 + seed, wy * 0.028, wz * 0.035 - seed, 3) * rBase * 0.30
              + fbm3(wx * 0.11, wy * 0.09, wz * 0.11, 3) * rBase * 0.10;
      const rr = 1 + n / Math.max(rBase, 1);
      posArr.push(wx * rr, wy, wz * rr);
      uvArr.push(j / radial, t);
    }
  }
  // broken, jagged top (no flat cap): fan to an off-centre peak with notches
  const topStart = posArr.length / 3;
  for (let j = 0; j < radial; j++) {
    const a0 = (j / radial) * Math.PI * 2, a1 = ((j + 1) / radial) * Math.PI * 2;
    const notch0 = 0.55 + 0.45 * Math.abs(Math.sin(a0 * 3.7 + seed));
    const notch1 = 0.55 + 0.45 * Math.abs(Math.sin(a1 * 3.7 + seed));
    const peak = height + rBase * (0.35 + 0.5 * Math.abs(Math.sin(j * 1.7 + seed)));
    const r0 = profile[rings] * rBase * (1 + 0.06 * Math.sin(a0 * 7));
    const r1 = profile[rings] * rBase * (1 + 0.06 * Math.sin(a1 * 7));
    const i0 = rings * (radial + 1) + j;
    const i1 = rings * (radial + 1) + j + 1;
    const cIdx = topStart + j;
    posArr.push(
      r0 * Math.cos(a0) * 0.35 + leanX * height,
      height + (peak - height) * notch0 * 0.35,
      r0 * Math.sin(a0) * 0.35 + leanZ * height
    );
    idxArr.push(i0, cIdx, i1);
  }
  for (let i = 0; i < rings; i++) {
    for (let j = 0; j < radial; j++) {
      const a = i * (radial + 1) + j;
      const b = a + 1;
      const c = a + radial + 1;
      const d = c + 1;
      idxArr.push(a, c, b, b, c, d);
    }
  }
  const geo = new THREE.BufferGeometry();
  geo.setAttribute('position', new THREE.Float32BufferAttribute(posArr, 3));
  geo.setIndex(idxArr);
  geo.computeVertexNormals();
  bakeRockAO(geo, { seed, floorDark: 0.42 });
  return geo;
}

// ---------------------------------------------------------------------------
// A natural arch: two feet, a sweeping span, variable thickness, eroded.
// ---------------------------------------------------------------------------
function makeArch(spec, field) {
  const { x1, z1, x2, z2, thickness, seed = 1 } = spec;
  const y1 = field.heightAt(x1, z1);
  const y2 = field.heightAt(x2, z2);

  // Sample the ground the arch must clear: a bridge that sits on the valley
  // floor is a hill, not an arch. The crown is lifted until there is real
  // negative space beneath the span.
  let hMax = -1e9;
  const N = 24;
  for (let i = 1; i < N; i++) {
    const t = i / N;
    const hx = lerp(x1, x2, t), hz = lerp(z1, z2, t);
    const hh = field.heightAt(hx, hz);
    if (hh > hMax) hMax = hh;
  }
  const clearance = 26 + thickness * 0.9;
  const crownY = Math.min(-12, hMax + clearance);
  const crownRise = crownY - Math.max(y1, y2);
  const apex = Math.max(spec.apex || 0, crownRise);

  // ---- span curve: steep piers, long flat crown (a real natural bridge) ----
  const pts = [];
  const SEG = 24;
  for (let i = 0; i <= SEG; i++) {
    const t = i / SEG;
    const x = lerp(x1, x2, t);
    const z = lerp(z1, z2, t);
    const baseY = lerp(y1, y2, t);
    const rise = smoothstepJS(0.0, 0.17, t) * smoothstepJS(0.0, 0.17, 1 - t);
    const y = baseY + (crownY - baseY) * rise;
    // piers plunge far below ground: never floating, never a seam
    const into = Math.max(0, 1 - Math.min(t, 1 - t) * 6.0);
    pts.push(new THREE.Vector3(x, y - into * (26 + thickness * 1.6), z));
  }
  const curve = new THREE.CatmullRomCurve3(pts, false, 'catmullrom', 0.25);
  const segs = 84, radial = 22;
  const pos = [], idx = [], uvs = [];
  const frames = curve.computeFrenetFrames(segs, false);
  const seedN = seed * 13.7;
  const spanDX = x2 - x1, spanDZ = z2 - z1;
  const spanLen = Math.hypot(spanDX, spanDZ) || 1;

  for (let i = 0; i <= segs; i++) {
    const t = i / segs;
    const P = curve.getPointAt(t);
    const Nf = frames.normals[Math.min(i, segs)];
    const Bf = frames.binormals[Math.min(i, segs)];
    // piers are fat and round; the deck is a broad, flat slab
    const pier = Math.pow(Math.abs(t - 0.5) * 2, 3.0);
    const deckHalfWidth = thickness * (1.15 + 1.45 * (1 - pier));   // horizontal
    const deckHalfThick = thickness * (0.55 + 0.85 * pier);         // vertical

    for (let j = 0; j <= radial; j++) {
      const a = (j / radial) * Math.PI * 2;
      const ca = Math.cos(a), sa = Math.sin(a);
      // superellipse: flat top and flat soffit, rounded shoulders
      const e = 2.6;
      const sx = Math.sign(ca) * Math.pow(Math.abs(ca), 2 / e);
      const sy = Math.sign(sa) * Math.pow(Math.abs(sa), 2 / e);
      const flute = 1 + 0.10 * Math.sin(a * 6 + t * 13 + seedN) + 0.05 * Math.sin(a * 11 - t * 5);
      const x = P.x + (Nf.x * sx * deckHalfWidth + Bf.x * sy * deckHalfThick) * flute;
      const y = P.y + (Nf.y * sx * deckHalfWidth + Bf.y * sy * deckHalfThick) * flute;
      const z = P.z + (Nf.z * sx * deckHalfWidth + Bf.z * sy * deckHalfThick) * flute;
      const n = fbm3(x * 0.026 + seedN, y * 0.022, z * 0.026, 3) * thickness * 0.42
              + fbm3(x * 0.09, y * 0.08, z * 0.09, 3) * thickness * 0.20
              + fbm3(x * 0.28, y * 0.24, z * 0.28, 2) * thickness * 0.075;
      pos.push(x + n * sx * 0.8, y + n * sy * 0.7, z + n * sx * 0.8);
      uvs.push(j / radial, t);
    }
  }
  for (let i = 0; i < segs; i++) {
    for (let j = 0; j < radial; j++) {
      const a = i * (radial + 1) + j, b = a + 1;
      const c = a + radial + 1, d = c + 1;
      idx.push(a, c, b, b, c, d);
    }
  }
  const geo = new THREE.BufferGeometry();
  geo.setAttribute('position', new THREE.Float32BufferAttribute(pos, 3));
  geo.setAttribute('uv', new THREE.Float32BufferAttribute(uvs, 2));
  geo.setIndex(idx);
  geo.computeVertexNormals();
  bakeRockAO(geo, { seed: seedN, floorDark: 0.48, heightNorm: 1 });
  return { geo, curve, y1, y2 };
}

/** Derive arch placements from the canyon network so every span crosses a
 *  genuine valley. Feet land on the rims; the crown clears the channel. */
function canyonArchSpecs(field, rng) {
  const specs = [];
  const picks = [
    [0, 0.18], [0, 0.36], [0, 0.58], [0, 0.80],
    [1, 0.30], [1, 0.62],
    [2, 0.22], [2, 0.55], [2, 0.85],
    [5, 0.45],
  ];
  for (const [ci, frac] of picks) {
    const c = CANYONS[ci];
    if (!c) continue;
    const seg = Math.min(c.pts.length - 2, Math.floor(frac * (c.pts.length - 1)));
    const a = c.pts[seg], b = c.pts[seg + 1];
    const dx = b[0] - a[0], dz = b[1] - a[1];
    const len = Math.hypot(dx, dz) || 1;
    const nx = -dz / len, nz = dx / len;
    const t = (frac * (c.pts.length - 1)) - seg;
    const cx = a[0] + dx * t, cz = a[1] + dz * t;
    const halfSpan = (c.width[0] + c.width[1]) * 0.62;
    const f1x = cx + nx * halfSpan, f1z = cz + nz * halfSpan;
    const f2x = cx - nx * halfSpan, f2z = cz - nz * halfSpan;
    specs.push({
      x1: f1x, z1: f1z, x2: f2x, z2: f2z,
      apex: 90 + rng() * 110,
      thickness: 20 + rng() * 16,
      seed: 3 + rng() * 40,
    });
  }
  return specs;
}

// ---------------------------------------------------------------------------
// An overhanging rock shelf: broad, irregular, thick where it meets the cliff
// and thin at the weathered lip.
// ---------------------------------------------------------------------------
function makeShelf(rng, opts) {
  const { length = 160, width = 120, thickness = 14 } = opts;
  const nx = 26, nz = 20;
  const pos = [], idx = [], uvs = [];
  const seed = rng() * 50;
  const top = [], bottom = [];
  for (let j = 0; j <= nz; j++) {
    for (let i = 0; i <= nx; i++) {
      const u = i / nx - 0.5, v = j / nz - 0.5;
      const x = u * width;
      const z = v * length;
      // irregular, lobed outline — never a rectangle
      const edge = 1 + 0.22 * Math.sin(u * 5.1 + seed) + 0.16 * Math.cos(v * 6.7 - seed);
      const px = x * edge;
      const pz = z * edge;
      const lip = Math.pow(Math.abs(v) * 2, 2.0);
      const th = thickness * (1.05 - 0.75 * lip);
      const n = fbm3(px * 0.03 + seed, 0, pz * 0.03, 3) * 5.5;
      top.push(px, th * 0.35 + n, pz);
      bottom.push(px, -th * 0.65 + n * 0.7 + 1.5, pz);
      uvs.push(i / nx, j / nz);
    }
  }
  const n = (nx + 1) * (nz + 1);
  for (let k = 0; k < n; k++) pos.push(top[k * 3], top[k * 3 + 1], top[k * 3 + 2]);
  for (let k = 0; k < n; k++) pos.push(bottom[k * 3], bottom[k * 3 + 1], bottom[k * 3 + 2]);
  for (let j = 0; j < nz; j++) {
    for (let i = 0; i < nx; i++) {
      const a = j * (nx + 1) + i, b = a + 1, c = a + nx + 1, d = c + 1;
      idx.push(a, c, b, b, c, d);                       // top
      idx.push(a + n, b + n, c + n, b + n, d + n, c + n); // bottom
    }
  }
  // rim
  const rimIndex = (i, j) => j * (nx + 1) + i;
  for (let i = 0; i < nx; i++) {
    const a = rimIndex(i, 0), b = rimIndex(i + 1, 0);
    idx.push(a, b, a + n, b, b + n, a + n);
    const c = rimIndex(i, nz), d = rimIndex(i + 1, nz);
    idx.push(c, d, c + n, d, d + n, c + n);
  }
  for (let j = 0; j < nz; j++) {
    const a = rimIndex(0, j), b = rimIndex(0, j + 1);
    idx.push(a, b, a + n, b, b + n, a + n);
    const c = rimIndex(nx, j), d = rimIndex(nx, j + 1);
    idx.push(c, d, c + n, d, d + n, c + n);
  }
  const geo = new THREE.BufferGeometry();
  geo.setAttribute('position', new THREE.Float32BufferAttribute(pos, 3));
  geo.setAttribute('uv', new THREE.Float32BufferAttribute(uvs, 2));
  geo.setIndex(idx);
  geo.computeVertexNormals();
  bakeRockAO(geo, { seed, floorDark: 0.35, heightNorm: 0 });
  return geo;
}

// ---------------------------------------------------------------------------
// A boulder: subdivided icosahedron pushed around by noise, three variants.
// ---------------------------------------------------------------------------
function makeBoulderGeo(seed, detail = 2) {
  const geo = new THREE.IcosahedronGeometry(1, detail);
  const pos = geo.attributes.position;
  const v = new THREE.Vector3();
  for (let i = 0; i < pos.count; i++) {
    v.fromBufferAttribute(pos, i);
    const n1 = fbm3(v.x * 1.6 + seed, v.y * 1.6, v.z * 1.6 - seed, 4);
    const n2 = fbm3(v.x * 4.2 - seed, v.y * 4.2, v.z * 4.2, 3);
    const cave = ridged2(v.x * 2.2 + seed, v.z * 2.2, 3) * 0.12;
    const r = 1 + n1 * 0.34 + n2 * 0.13 + cave;
    v.multiplyScalar(r);
    v.y *= 0.72 + 0.2 * Math.sin(seed);
    pos.setXYZ(i, v.x, v.y, v.z);
  }
  geo.computeVertexNormals();
  bakeRockAO(geo, { seed, floorDark: 0.5, heightNorm: 0 });
  return geo;
}

// ---------------------------------------------------------------------------
// Placement data — authored, art-directed, then procedurally varied.
// ---------------------------------------------------------------------------
const TOWER_SITES = [
  // DROWNED CATHEDRAL — the world's landmark skyline
  { x: -300, z: 300, h: 148, r: 34 }, { x: -140, z: 190, h: 120, r: 27 },
  { x: -430, z: 90, h: 165, r: 41 }, { x: -210, z: -30, h: 96, r: 23 },
  { x: 30, z: 120, h: 132, r: 30 }, { x: 130, z: 320, h: 84, r: 21 },
  { x: -560, z: 220, h: 110, r: 25 }, { x: -680, z: 60, h: 138, r: 33 },
  { x: -80, z: 420, h: 76, r: 19 }, { x: -380, z: 470, h: 92, r: 24 },
  { x: 260, z: -60, h: 118, r: 28 }, { x: -820, z: 300, h: 88, r: 22 },
  // GREAT ARCHWAYS — buttresses between the terraces
  { x: -700, z: -300, h: 120, r: 30 }, { x: 120, z: -350, h: 140, r: 36 },
  { x: -60, z: -620, h: 105, r: 26 }, { x: -900, z: -560, h: 132, r: 34 },
  { x: 420, z: -520, h: 96, r: 24 }, { x: -320, z: -880, h: 118, r: 28 },
  // AZURE CANYON rims and pinnacles
  { x: 260, z: -760, h: 92, r: 22 }, { x: -1020, z: -820, h: 104, r: 25 },
  { x: -180, z: -1150, h: 88, r: 21 },
  // CRYSTAL ABYSS — colossal deep silhouettes
  { x: -520, z: -1400, h: 210, r: 52 }, { x: -150, z: -1520, h: 180, r: 44 },
  { x: -900, z: -1300, h: 165, r: 40 }, { x: 180, z: -1350, h: 150, r: 36 },
  // ETERNAL BLUE
  { x: -700, z: -1700, h: 240, r: 58 }, { x: -1050, z: -1650, h: 195, r: 46 },
  // sunlit shelf outcrops (small, eroded, weathered)
  { x: -760, z: 1120, h: 26, r: 13 }, { x: -380, z: 980, h: 22, r: 11 },
  { x: -980, z: 700, h: 34, r: 16 }, { x: -1500, z: 260, h: 40, r: 18 },
];

const ARCH_SPECS = [
  // DROWNED CATHEDRAL approach
  { x1: -430, z1: 330, x2: -180, z2: 240, apex: 96, thickness: 20, seed: 3 },
  { x1: -700, z1: 100, x2: -430, z2: 30, apex: 88, thickness: 18, seed: 5 },
  // GREAT ARCHWAYS — colossal spans over the canyon and between terraces
  { x1: -420, z1: -180, x2: -60, z2: -260, apex: 150, thickness: 32, seed: 7 },
  { x1: 60, z1: -320, x2: -300, z2: -420, apex: 165, thickness: 36, seed: 9 },
  { x1: -760, z1: -280, x2: -420, z2: -180, apex: 130, thickness: 28, seed: 11 },
  { x1: -180, z1: -560, x2: 180, z2: -640, apex: 175, thickness: 38, seed: 13 },
  { x1: -620, z1: -660, x2: -260, z2: -560, apex: 140, thickness: 30, seed: 15 },
  { x1: 420, z1: -420, x2: 140, z2: -300, apex: 120, thickness: 26, seed: 17 },
  { x1: -900, z1: -560, x2: -620, z2: -680, apex: 145, thickness: 30, seed: 19 },
  // AZURE CANYON and the abyss
  { x1: -300, z1: -900, x2: 40, z2: -1000, apex: 160, thickness: 34, seed: 21 },
  { x1: -560, z1: -1180, x2: -220, z2: -1280, apex: 180, thickness: 36, seed: 23 },
  { x1: -520, z1: -1400, x2: -160, z2: -1500, apex: 200, thickness: 40, seed: 25 },
  { x1: 180, z1: -1350, x2: -60, z2: -1460, apex: 170, thickness: 34, seed: 27 },
];

export function buildGeology(field, controller) {
  const group = new THREE.Group();
  group.name = 'geology';
  const rng = mulberry32(20240613);
  const mat = createRockMaterial({ detail: 1.0 });
  const colliders = controller ? controller.colliders : [];

  // ---------------- towers ----------------
  const towerGeos = [];
  for (const site of TOWER_SITES) {
    const baseY = field.heightAt(site.x, site.z);
    const depth = -baseY;
    // a rock spire may approach the surface but never break it
    const h = Math.min(site.h, Math.max(12, depth - 10));
    const siteH = h;
    site.h = siteH;
    const geo = makeTower(rng, { height: siteH, radius: site.r });
    geo.translate(site.x, baseY - siteH * 0.10, site.z);  // buried bases
    towerGeos.push(geo);
    if (colliders) {
      // colliders follow the actual silhouette: stacked cylinders
      const steps = 4;
      for (let s = 0; s < steps; s++) {
        const t0 = s / steps, t1 = (s + 1) / steps;
        const rAvg = site.r * (1.05 - 0.42 * Math.pow((t0 + t1) * 0.5, 0.85));
        colliders.push({
          type: 'cyl', x: site.x, z: site.z,
          yBase: baseY - siteH * 0.10 + siteH * t0,
          yTop: baseY - siteH * 0.10 + siteH * t1,
          r: rAvg * 0.92,
        });
      }
    }
  }
  // merge towers into a handful of meshes for draw-call economy
  const towerMesh = new THREE.Mesh(mergeGeos(towerGeos), mat);
  towerMesh.name = 'cathedral_towers';
  group.add(towerMesh);

  // ---------------- arches ----------------
  const archGeos = [];
  const archInfo = [];
  const allArchSpecs = ARCH_SPECS.concat(canyonArchSpecs(field, rng));
  for (const spec of allArchSpecs) {
    // never let an arch intersect the ground it spans: lift apex if needed
    const local = { ...spec };
    const { geo, curve } = makeArch(local, field);
    archGeos.push(geo);
    archInfo.push({
      p0: curve.getPointAt(0.5).toArray(),
      p25: curve.getPointAt(0.25).toArray(),
      p75: curve.getPointAt(0.75).toArray(),
      crown: curve.getPointAt(0.5).y,
      span: Math.hypot(spec.x2 - spec.x1, spec.z2 - spec.z1),
      thickness: spec.thickness,
    });
    if (controller) {
      // capsule colliders along the span so you cannot swim through rock
      const steps = 10;
      for (let s = 0; s < steps; s++) {
        const a = curve.getPointAt(s / steps);
        const b = curve.getPointAt((s + 1) / steps);
        controller.colliders.push({
          type: 'cap', x1: a.x, y1: a.y, z1: a.z, x2: b.x, y2: b.y, z2: b.z,
          r: spec.thickness * 0.9,
        });
      }
    }
  }
  const archMesh = new THREE.Mesh(mergeGeos(archGeos), mat);
  archMesh.name = 'great_arches';
  group.add(archMesh);

  // ---------------- overhanging shelves on the great terraces ----------------
  const shelfGeos = [];
  const SHELVES = [
    { x: -640, z: -380, yOff: 26, len: 260, wid: 210, th: 20 },
    { x: -180, z: -700, yOff: 30, len: 300, wid: 230, th: 24 },
    { x: 500, z: -430, yOff: 22, len: 200, wid: 180, th: 16 },
    { x: -1050, z: -640, yOff: 28, len: 240, wid: 200, th: 20 },
    { x: -420, z: -1180, yOff: 34, len: 260, wid: 210, th: 22 },
    { x: 260, z: -1020, yOff: 24, len: 200, wid: 180, th: 18 },
    { x: -1400, z: 380, yOff: 20, len: 180, wid: 150, th: 14 },
    { x: 700, z: 260, yOff: 18, len: 170, wid: 150, th: 14 },
    { x: -300, z: 190, yOff: 40, len: 220, wid: 190, th: 18 },
  ];
  for (const s of SHELVES) {
    const base = field.heightAt(s.x, s.z);
    const geo = makeShelf(rng, { length: s.len, width: s.wid, thickness: s.th });
    geo.rotateY(rng() * Math.PI * 2);
    geo.translate(s.x, base + s.yOff, s.z);
    shelfGeos.push(geo);
    if (controller) {
      controller.colliders.push({
        type: 'cyl', x: s.x, z: s.z,
        yBase: base + s.yOff - s.th, yTop: base + s.yOff + s.th * 0.5,
        r: Math.min(s.wid, s.len) * 0.44,
      });
    }
  }
  const shelfMesh = new THREE.Mesh(mergeGeos(shelfGeos), mat);
  shelfMesh.name = 'shelves';
  group.add(shelfMesh);

  // ---------------- boulders & scree ----------------
  const boulderGeos = [];
  for (let i = 0; i < 4; i++) boulderGeos.push(makeBoulderGeo(rng() * 50 + i * 7, 2));
  const boulderMat = mat;
  const BOULDER_TOTAL = 2600;
  const variants = boulderGeos.map(g => ({ geo: g, list: [] }));

  const placeBoulder = (x, z, size, sink) => {
    const y = field.heightAt(x, z);
    const v = variants[Math.floor(rng() * variants.length)];
    v.list.push({ x, y: y + size * sink, z, size, rot: rng() * Math.PI * 2, tilt: (rng() - 0.5) * 0.5 });
  };

  // region-weighted scattering: dense on rocky ground, sparse on open sand
  for (let i = 0; i < BOULDER_TOTAL * 3 && variants.reduce((a, v) => a + v.list.length, 0) < BOULDER_TOTAL; i++) {
    const x = WORLD.minX + rng() * (WORLD.maxX - WORLD.minX);
    const z = WORLD.minZ + rng() * (WORLD.maxZ - WORLD.minZ);
    const y = field.heightAt(x, z);
    const depth = -y;
    const slope = field.steepness(x, z);
    // probability: high in rocky/deep terrain, low on the sunlit sand plain
    let p = 0.16 + slope * 0.7;
    if (depth < 26) p *= 0.5;                 // keep the shelf sand open
    if (depth > 300) p *= 0.55;
    p *= 0.6 + 0.8 * (fbm3(x * 0.004, 0.5, z * 0.004, 3) * 0.5 + 0.5);
    if (rng() > p) continue;
    const size = 1.2 + Math.pow(rng(), 2.6) * (5 + Math.min(28, depth * 0.06));
    placeBoulder(x, z, size, -0.25);
  }

  for (const v of variants) {
    if (!v.list.length) continue;
    const inst = new THREE.InstancedMesh(v.geo, boulderMat, v.list.length);
    const m = new THREE.Matrix4();
    const q = new THREE.Quaternion();
    const e = new THREE.Euler();
    const s = new THREE.Vector3();
    v.list.forEach((b, i) => {
      e.set(b.tilt, b.rot, b.tilt * 0.6);
      q.setFromEuler(e);
      s.set(b.size * (0.8 + 0.5 * rng()), b.size * (0.7 + 0.4 * rng()), b.size * (0.8 + 0.5 * rng()));
      m.compose(new THREE.Vector3(b.x, b.y, b.z), q, s);
      inst.setMatrixAt(i, m);
    });
    inst.instanceMatrix.needsUpdate = true;
    inst.frustumCulled = false;
    inst.name = 'boulders';
    group.add(inst);
  }

  // ---------------- canyon-rim pinnacles & debris ridges ----------------
  for (const cn of CANYONS) {
    for (let k = 0; k < cn.pts.length - 1; k++) {
      const a = cn.pts[k], b = cn.pts[k + 1];
      const dx = b[0] - a[0], dz = b[1] - a[1];
      const len = Math.hypot(dx, dz);
      const nx = -dz / len, nz = dx / len;
      const count = Math.max(1, Math.round(len / 120));
      for (let i = 0; i < count; i++) {
        const t = (i + 0.5) / count;
        const side = rng() > 0.5 ? 1 : -1;
        const off = cn.width[1] * (1.05 + rng() * 0.55) * side;
        const x = a[0] + dx * t + nx * off;
        const z = a[1] + dz * t + nz * off;
        if (x < WORLD.minX + 40 || x > WORLD.maxX - 40 || z < WORLD.minZ + 40 || z > WORLD.maxZ - 40) continue;
        if (rng() > 0.55) continue;
        const h = 18 + rng() * 46;
        const r = 6 + rng() * 13;
        const baseY = field.heightAt(x, z);
        const geo = makeTower(rng, { height: h, radius: r });
        geo.translate(x, baseY - h * 0.2, z);
        const mesh = new THREE.Mesh(geo, mat);
        mesh.frustumCulled = true;
        group.add(mesh);
        if (controller) {
          controller.colliders.push({ type: 'cyl', x, z, yBase: baseY - h * 0.2, yTop: baseY + h, r: r * 0.85 });
        }
      }
    }
  }

  group.userData.update = () => {};
  group.userData.material = mat;
  group.userData.arches = archInfo;
  group.userData.towers = TOWER_SITES.filter(t => t.h > 40).map(t => ({
    x: t.x, z: t.z, y: field.heightAt(t.x, t.z), h: t.h, r: t.r,
  }));
  return group;
}

/** Merge many BufferGeometries that share the same attributes. */
function mergeGeos(geos) {
  let vCount = 0, iCount = 0;
  for (const g of geos) {
    vCount += g.attributes.position.count;
    iCount += g.index ? g.index.count : 0;
  }
  const pos = new Float32Array(vCount * 3);
  const nrm = new Float32Array(vCount * 3);
  const ao = new Float32Array(vCount);
  const uv = new Float32Array(vCount * 2);
  const idx = new Uint32Array(iCount);
  let vo = 0, io = 0;
  for (const g of geos) {
    const p = g.attributes.position, n = g.attributes.normal;
    const a = g.attributes.aAO, t = g.attributes.uv;
    pos.set(p.array, vo * 3);
    if (n) nrm.set(n.array, vo * 3);
    if (a) ao.set(a.array, vo); else ao.fill(0.8, vo, vo + p.count);
    if (t) uv.set(t.array, vo * 2);
    const gi = g.index;
    if (gi) {
      for (let i = 0; i < gi.count; i++) idx[io + i] = gi.getX(i) + vo;
      io += gi.count;
    }
    vo += p.count;
    g.dispose?.();
  }
  const geo = new THREE.BufferGeometry();
  geo.setAttribute('position', new THREE.BufferAttribute(pos, 3));
  geo.setAttribute('normal', new THREE.BufferAttribute(nrm, 3));
  geo.setAttribute('aAO', new THREE.BufferAttribute(ao, 1));
  geo.setAttribute('uv', new THREE.BufferAttribute(uv, 2));
  geo.setIndex(new THREE.BufferAttribute(idx, 1));
  geo.computeBoundingSphere();
  return geo;
}

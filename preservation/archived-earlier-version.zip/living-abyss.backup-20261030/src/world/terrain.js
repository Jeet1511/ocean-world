// -----------------------------------------------------------------------------
// THE LIVING ABYSS — seabed geometry
// Built from the single geography field, split into frustum-culled chunks, with
// baked horizon occlusion so cliffs read with real depth. Plus a coarse outer
// apron so the horizon never shows the edge of the world.
// -----------------------------------------------------------------------------
import * as THREE from '../../vendor/three.module.js';
import { WORLD, CHAMBERS } from './geography.js';
import { GLSL_HEADER, GLSL_MEDIUM, withShared, shared } from '../shaders/common.js';

export const TERRAIN_VS = /* glsl */`
attribute float aAO;
varying vec3 vWorld;
varying vec3 vNrm;
varying float vAO;
void main(){
  vec4 wp = modelMatrix * vec4(position, 1.0);
  vWorld = wp.xyz;
  vNrm = normalize(mat3(modelMatrix) * vec3(normal));
  vAO = aAO;
  gl_Position = projectionMatrix * viewMatrix * wp;
}
`;

export const TERRAIN_FS = GLSL_HEADER + /* glsl */`
uniform float uDetail;
varying vec3 vWorld;
varying vec3 vNrm;
varying float vAO;

void main(){
  vec3 N = normalize(vNrm);
  float detailH;
  float dist = length(uCamPos - vWorld);
  float nearF = 1.0 - smoothstep(30.0, 220.0, dist);
  vec3 albedo = rockAlbedo(vWorld, N, 1.0, nearF, detailH);

  N = sandRippleNormal(vWorld, N, nearF);

  // procedural bump: coarse geological relief always, fine grain up close
  N = perturbNormal(vWorld, N, 0.34, uDetail * (0.70 + 0.5 * nearF));
  if (nearF > 0.02) {
    N = perturbNormal(vWorld, N, 1.6, uDetail * 0.42 * nearF);
    N = perturbNormal(vWorld, N, 6.0, uDetail * 0.22 * nearF);
  }

  float ao = clamp(vAO, 0.0, 1.0);
  vec3 col = litSurface(albedo, N, vWorld, 0.66, 0.35 + 0.65 * ao, 1.0);

  // Suspended sediment glow near the seabed in the shallows (adds air/water body)
  float seabedProx = smoothstep(14.0, 0.0, dist);
  col += waterAmbient(vWorld.y) * 0.10 * seabedProx;

  col = applyWater(col, vWorld);
  gl_FragColor = vec4(col, 1.0);
}
`;

const smoothstepLocal = (e0, e1, x) => {
  const t = Math.max(0, Math.min(1, (x - e0) / (e1 - e0)));
  return t * t * (3 - 2 * t);
};

const CHUNKS_X = 8;
const CHUNKS_Z = 6;

/** Bake approximate sky/water occlusion per vertex from the height grid. */
function bakeAO(field) {
  const { vx, vz, heights } = field;
  const ao = new Float32Array(vx * vz);
  const dirs = 8;
  const radii = [26, 70, 160];
  const H = heights;
  for (let j = 0; j < vz; j++) {
    for (let i = 0; i < vx; i++) {
      const h0 = H[j * vx + i];
      let horizon = 0;
      for (let d = 0; d < dirs; d++) {
        const a = (d / dirs) * Math.PI * 2;
        const dx = Math.cos(a), dz = Math.sin(a);
        let maxTan = 0;
        for (let r = 0; r < radii.length; r++) {
          const rr = radii[r];
          const si = i + Math.round(dx * rr / field.cell);
          const sj = j + Math.round(dz * rr / field.cell);
          if (si < 0 || si >= vx || sj < 0 || sj >= vz) continue;
          const dh = H[sj * vx + si] - h0;
          const t = dh / rr;
          if (t > maxTan) maxTan = t;
        }
        horizon += maxTan > 0 ? Math.min(1, maxTan * 1.8) : 0;
      }
      horizon /= dirs;
      // cavity term: convex bumps get more light, hollows less
      let lap = 0, n = 0;
      if (i > 1 && i < vx - 2 && j > 1 && j < vz - 2) {
        lap = (H[j * vx + i - 2] + H[j * vx + i + 2] + H[(j - 2) * vx + i] + H[(j + 2) * vx + i]) * 0.25 - h0;
        n = 1;
      }
      const cavity = n ? Math.max(0, Math.min(1, 0.5 + lap * 0.10)) : 0.6;
      let a = Math.max(0.18, Math.min(1, (1 - horizon * 0.85) * (0.55 + 0.45 * cavity)));
      // flooded halls sit in permanent shade: darken the seabed under each vault,
      // letting light back in along the gate direction
      const wx = WORLD.minX + i * field.cell, wz = WORLD.minZ + j * field.cell;
      for (let k = 0; k < CHAMBERS.length; k++) {
        const ch = CHAMBERS[k];
        const dx = wx - ch.x, dz = wz - ch.z;
        const d = Math.hypot(dx, dz);
        if (d > ch.r * 1.5) continue;
        const inside = 1 - smoothstepLocal(ch.r * 0.55, ch.r * 1.45, d);
        let da = Math.atan2(dz, dx) - ch.gateAngle;
        da = Math.atan2(Math.sin(da), Math.cos(da));
        const gateLight = Math.max(0, 1 - Math.abs(da) / 1.1);
        const shade = 1 - inside * (0.78 - 0.55 * gateLight);
        a *= shade;
      }
      ao[j * vx + i] = a;
    }
  }
  return ao;
}

export function buildTerrain(field) {
  const material = new THREE.ShaderMaterial({
    uniforms: withShared({ uDetail: { value: 1.0 } }),
    vertexShader: TERRAIN_VS,
    fragmentShader: TERRAIN_FS,
    side: THREE.FrontSide,
  });

  const ao = bakeAO(field);
  const group = new THREE.Group();
  group.name = 'seabed';

  const { vx, heights, cell } = field;
  const cx = field.nx / CHUNKS_X;   // cells per chunk
  const cz = field.nz / CHUNKS_Z;

  const nrm = { x: 0, y: 1, z: 0 };

  for (let cj = 0; cj < CHUNKS_Z; cj++) {
    for (let ci = 0; ci < CHUNKS_X; ci++) {
      const i0 = ci * cx, j0 = cj * cz;
      const w = cx + 1, h = cz + 1;
      const pos = new Float32Array(w * h * 3);
      const nor = new Float32Array(w * h * 3);
      const aoA = new Float32Array(w * h);
      const idx = new Uint32Array(cx * cz * 6);

      for (let j = 0; j < h; j++) {
        for (let i = 0; i < w; i++) {
          const gi = i0 + i, gj = j0 + j;
          const k = j * w + i;
          const x = WORLD.minX + gi * cell;
          const z = WORLD.minZ + gj * cell;
          pos[k * 3] = x;
          pos[k * 3 + 1] = heights[gj * vx + gi];
          pos[k * 3 + 2] = z;
          // analytic normal from the grid (identical across chunk borders)
          const hl = heights[gj * vx + Math.max(0, gi - 1)];
          const hr = heights[gj * vx + Math.min(vx - 1, gi + 1)];
          const hd = heights[Math.max(0, gj - 1) * vx + gi];
          const hu = heights[Math.min(field.vz - 1, gj + 1) * vx + gi];
          nrm.x = hl - hr; nrm.y = 2 * cell; nrm.z = hd - hu;
          const l = Math.hypot(nrm.x, nrm.y, nrm.z) || 1;
          nor[k * 3] = nrm.x / l; nor[k * 3 + 1] = nrm.y / l; nor[k * 3 + 2] = nrm.z / l;
          aoA[k] = ao[gj * vx + gi];
        }
      }
      let o = 0;
      for (let j = 0; j < cz; j++) {
        for (let i = 0; i < cx; i++) {
          const a = j * w + i, b = a + 1, c = a + w, d = c + 1;
          idx[o++] = a; idx[o++] = c; idx[o++] = b;
          idx[o++] = b; idx[o++] = c; idx[o++] = d;
        }
      }
      const geo = new THREE.BufferGeometry();
      geo.setAttribute('position', new THREE.BufferAttribute(pos, 3));
      geo.setAttribute('normal', new THREE.BufferAttribute(nor, 3));
      geo.setAttribute('aAO', new THREE.BufferAttribute(aoA, 1));
      geo.setIndex(new THREE.BufferAttribute(idx, 1));
      geo.computeBoundingSphere();
      // generous bounds so big formations never pop at the frustum edge
      geo.boundingSphere.radius *= 1.3;

      const mesh = new THREE.Mesh(geo, material);
      mesh.name = `seabed_${ci}_${cj}`;
      mesh.matrixAutoUpdate = false;
      group.add(mesh);
    }
  }
  group.userData.material = material;
  return group;
}

const APRON_VS = /* glsl */`
varying vec3 vWorld;
void main(){
  vec4 wp = modelMatrix * vec4(position, 1.0);
  vWorld = wp.xyz;
  gl_Position = projectionMatrix * viewMatrix * wp;
}
`;

const APRON_FS = GLSL_MEDIUM + /* glsl */`
varying vec3 vWorld;
void main(){
  vec3 col = waterAmbient(vWorld.y) * 0.94;
  col *= 0.86 + 0.14 * smoothstep(-260.0, -10.0, vWorld.y);
  col = applyWater(col, vWorld);
  gl_FragColor = vec4(col, 1.0);
}
`;

/**
 * Coarse apron beyond the charted world: the same geological function sampled
 * sparsely, overlapped inward and sunk slightly, so there is never a visible
 * edge or void — the ocean floor simply continues into the haze.
 */
export function buildApron(field) {
  const OUT = 3200;                    // metres beyond the world bounds
  const STEP = 110;
  const x0 = WORLD.minX - OUT, x1 = WORLD.maxX + OUT;
  const z0 = WORLD.minZ - OUT, z1 = WORLD.maxZ + OUT;
  const nx = Math.ceil((x1 - x0) / STEP), nz = Math.ceil((z1 - z0) / STEP);

  const pos = [], nor = [], aoA = [], idx = [];
  const n = { x: 0, y: 1, z: 0 };
  const map = [];
  for (let j = 0; j <= nz; j++) {
    for (let i = 0; i <= nx; i++) {
      let x = x0 + i * STEP, z = z0 + j * STEP;
      // overlap inward so the coarse mesh never reveals a crack
      const insideX = x > WORLD.minX && x < WORLD.maxX;
      const insideZ = z > WORLD.minZ && z < WORLD.maxZ;
      let y;
      if (insideX && insideZ) {
        // Inside the core the apron is buried, but it must stay buried: a
        // single sample is not enough over a canyon wall, so take the local
        // minimum over the cell and sink well below it.
        let mn = 1e9;
        for (let a = -1; a <= 1; a++) {
          for (let b = -1; b <= 1; b++) {
            mn = Math.min(mn, field.heightAt(x + a * 55, z + b * 55));
          }
        }
        y = mn - 18;
      } else {
        // outside: fade into a deeper distant basin so it reads as open ocean floor
        const ex = Math.max(0, Math.max(WORLD.minX - x, x - WORLD.maxX));
        const ez = Math.max(0, Math.max(WORLD.minZ - z, z - WORLD.maxZ));
        const e = Math.hypot(ex, ez);
        const h = field.heightAt(Math.min(Math.max(x, WORLD.minX), WORLD.maxX),
                                 Math.min(Math.max(z, WORLD.minZ), WORLD.maxZ));
        y = h - 18 - e * 0.09;
      }
      pos.push(x, y, z);
      map.push(idx.length / 3);
      // cheap normals
      const e = 30;
      const hx = field.heightAt(x + e, z) - field.heightAt(x - e, z);
      const hz = field.heightAt(x, z + e) - field.heightAt(x, z - e);
      const nxv = -hx, nzv = -hz, nyv = 2 * e;
      const l = Math.hypot(nxv, nyv, nzv) || 1;
      nor.push(nxv / l, nyv / l, nzv / l);
      aoA.push(0.62);
    }
  }
  const w = nx + 1;
  for (let j = 0; j < nz; j++) {
    for (let i = 0; i < nx; i++) {
      const a = j * w + i, b = a + 1, c = a + w, d = c + 1;
      idx.push(a, c, b, b, c, d);
    }
  }
  const geo = new THREE.BufferGeometry();
  geo.setAttribute('position', new THREE.Float32BufferAttribute(pos, 3));
  geo.setAttribute('normal', new THREE.Float32BufferAttribute(nor, 3));
  geo.setAttribute('aAO', new THREE.Float32BufferAttribute(aoA, 1));
  geo.setIndex(idx);
  geo.computeBoundingSphere();

  // The apron exists only to hide the edge of the charted world. Shaded like
  // rock it read as a hard dark band lying across the horizon; here it simply
  // dissolves into the water column it lives in.
  const mat = new THREE.ShaderMaterial({
    uniforms: withShared({}),
    vertexShader: APRON_VS,
    fragmentShader: APRON_FS,
    side: THREE.FrontSide,
  });
  const mesh = new THREE.Mesh(geo, mat);
  mesh.name = 'distant_seabed';
  mesh.matrixAutoUpdate = false;
  return mesh;
}

// -----------------------------------------------------------------------------
// THE LIVING ABYSS — MASTER GEOGRAPHY
// A single continuous 4.8 km x 3.6 km ocean basin, sea level at y = 0,
// descending to ~1150 m. One coherent coordinate system, no seams, no islands.
//
// This file is the world's "geological truth": the terrain grid, the canyon
// network, the cave system, and the elevations every other system samples from.
// -----------------------------------------------------------------------------

import {
  fbm2, ridged2, sampleTrack, terrace, distToPolyline, clamp, clamp01,
  lerp, smoothstep, smoothstep as ss, blob,
} from '../core/noise.js';

export const WORLD = {
  minX: -2400, maxX: 2400,
  minZ: -1800, maxZ: 1800,
  cell: 6.25,           // metres per terrain cell
  seaLevel: 0,
  maxDepth: 1150,
};

WORLD.nx = Math.round((WORLD.maxX - WORLD.minX) / WORLD.cell); // 768 cells
WORLD.nz = Math.round((WORLD.maxZ - WORLD.minZ) / WORLD.cell); // 576 cells

// -----------------------------------------------------------------------------
// Regional identity — used for HUD, map, discovery, and art-direction gating.
// -----------------------------------------------------------------------------
export const REGIONS = [
  {
    id: 'surface', name: 'ZONE 00 · THE OPEN OCEAN', short: 'Open Ocean',
    anchor: [-600, 1620], radius: 900, depth: [0, -10],
    tone: '#9fe8ef',
    blurb: 'Sky, swell and sun. The roof of the world.',
  },
  {
    id: 'shelf', name: 'ZONE 01 · SUNLIT SHELF', short: 'Sunlit Shelf',
    anchor: [-700, 1250], radius: 780, depth: [-4, -20],
    tone: '#7ff3d8',
    blurb: 'Pale sand, limestone outcrops and moving caustics.',
  },
  {
    id: 'coral', name: 'ZONE 02 · THE CORAL GARDEN', short: 'Coral Garden',
    anchor: [-950, 880], radius: 560, depth: [-8, -32],
    tone: '#ffb08a',
    blurb: 'Layered limestone reef, coral families, sand channels.',
  },
  {
    id: 'kelp', name: 'ZONE 03 · THE KELP FOREST', short: 'Kelp Forest',
    anchor: [-1800, 800], radius: 720, depth: [-14, -48],
    tone: '#a8d96b',
    blurb: 'A submerged woodland of light and shadow.',
  },
  {
    id: 'cathedral', name: 'ZONE 04 · THE DROWNED CATHEDRAL', short: 'Drowned Cathedral',
    anchor: [-350, 210], radius: 620, depth: [-30, -150],
    tone: '#c9b6ff',
    blurb: 'Monumental rock towers rising from a drowned plateau.',
  },
  {
    id: 'archways', name: 'ZONE 05 · THE GREAT NATURAL ARCHWAYS', short: 'Great Archways',
    anchor: [-250, -230], radius: 820, depth: [-90, -300],
    tone: '#8fb8ff',
    blurb: 'Colossal bridges and terraced shelves stacked into blue.',
  },
  {
    id: 'canyon', name: 'ZONE 06 · AZURE CANYON', short: 'Azure Canyon',
    anchor: [-320, -720], radius: 780, depth: [-200, -620],
    tone: '#5f8cff',
    blurb: 'Winding passages descending out of the light.',
  },
  {
    id: 'caverns', name: 'ZONE 07 · THE VEILED CAVERNS', short: 'Veiled Caverns',
    anchor: [1180, 480], radius: 700, depth: [-20, -220],
    tone: '#7fd4c8',
    blurb: 'Enclosed chambers, flooded halls, shafts of stray light.',
  },
  {
    id: 'abyss', name: 'ZONE 08 · THE CRYSTAL ABYSS', short: 'Crystal Abyss',
    anchor: [-480, -1330], radius: 850, depth: [-450, -900],
    tone: '#3f63c9',
    blurb: 'Cliffs, fractures and mineral veins in failing light.',
  },
  {
    id: 'eternal', name: 'ZONE 09 · ETERNAL BLUE', short: 'Eternal Blue',
    anchor: [-700, -1680], radius: 650, depth: [-760, -1160],
    tone: '#2a3f86',
    blurb: 'The floor of the world. Silence, scale, and blue-black water.',
  },
];

// -----------------------------------------------------------------------------
// Canyon network — authored polylines, climbing the staircase down to the basin.
// Every branch is swimmable and reconnects; nothing dead-ends inside rock.
// -----------------------------------------------------------------------------
export const CANYONS = [
  { // AZURE CANYON — the main artery: archways -> abyss -> eternal blue
    pts: [[120, -240], [40, -420], [-90, -600], [-190, -760], [-60, -920],
      [-230, -1060], [-380, -1190], [-300, -1350], [-480, -1480], [-640, -1610], [-760, -1740]],
    width: [110, 250], depth: [55, 180], wall: 0.42,
  },
  { // eastern artery: cavern ridge down past the archways into the basin
    pts: [[900, -120], [930, -330], [800, -520], [960, -700], [840, -900], [700, -1100], [560, -1300], [460, -1520]],
    width: [85, 190], depth: [45, 150], wall: 0.4,
  },
  { // western artery: kelp shelf edge -> cathedral -> abyss
    pts: [[-1500, 260], [-1420, 20], [-1300, -240], [-1380, -470], [-1200, -700], [-1260, -940], [-1090, -1180], [-960, -1400], [-900, -1620]],
    width: [75, 175], depth: [40, 135], wall: 0.38,
  },
  { // a tight side slot off the main artery — dramatic, narrow, chamber-linked
    pts: [[-190, -760], [-390, -800], [-540, -740], [-620, -850], [-570, -980]],
    width: [45, 90], depth: [30, 90], wall: 0.5,
  },
  { // eastern connector: cavern ridge back into the azure gate
    pts: [[1180, 300], [1050, 120], [980, -80], [930, -330], [900, -120]],
    width: [55, 130], depth: [35, 100], wall: 0.44,
  },
  { // cross-link between the main and eastern arteries (alternative routes)
    pts: [[-90, -600], [180, -660], [430, -720], [800, -520]],
    width: [50, 115], depth: [30, 85], wall: 0.46,
  },
  { // trench mouth: the artery opens into the Eternal Blue basin
    pts: [[-760, -1740], [-780, -1600], [-800, -1470]],
    width: [250, 400], depth: [130, 220], wall: 0.35,
  },
];

// Cave chambers: not tunnels hidden behind a wall — sunken halls carved into the
// seabed, each with a carved entrance channel (a real gate you can swim through).
export const CHAMBERS = [
  // eastern ridge complex — shallow enough to catch stray daylight
  { x: 1080, z: 620, r: 150, depth: 105, roofFrom: 44, gateAngle: 2.5, elong: 1.5, name: 'The Flooded Nave' },
  { x: 1420, z: 470, r: 125, depth: 130, roofFrom: 38, gateAngle: 3.3, elong: 1.7, name: 'The Sunken Gallery' },
  { x: 1240, z: 240, r: 105, depth: 110, roofFrom: 40, gateAngle: 2.0, elong: 1.6, name: 'The Whispering Vault' },
  { x: 900, z: 700, r: 115, depth: 85, roofFrom: 46, gateAngle: 1.1, elong: 1.4, name: 'The Green Hall' },
  // cathedral crypts
  { x: -520, z: 340, r: 130, depth: 95, roofFrom: 50, gateAngle: -1.5, elong: 1.5, name: 'The Cathedral Crypt' },
  { x: -760, z: 120, r: 110, depth: 115, roofFrom: 40, gateAngle: 0.5, elong: 1.6, name: 'The Lower Reliquary' },
  // canyon side chambers
  { x: -540, z: -740, r: 95, depth: 110, roofFrom: 34, gateAngle: 2.1, elong: 1.8, name: 'The Narrow Chapel' },
  { x: 800, z: -520, r: 140, depth: 125, roofFrom: 42, gateAngle: -0.4, elong: 1.5, name: 'The Deep Sanctum' },
];

// -----------------------------------------------------------------------------
// THE STAIRCASE PROFILE — the world's spine.
// The seabed is not a smooth ramp: it is a stack of enormous treads separated by
// sharp risers. Treads = the wide shelves of the reference art; risers = the
// colossal cliff walls that arches span and canyons cut through.
// s = axial distance travelled north from the shallow shelf (metres).
// y = tread elevation, w = riser width (smaller = more vertical).
// -----------------------------------------------------------------------------
const TREADS = [
  { s: -400, y: -5.5, w: 70 },     // sunlit shelf sand
  { s: 130, y: -9.0, w: 55 },
  { s: 270, y: -16.0, w: 42 },     // reef rise — coral garden
  { s: 400, y: -23.0, w: 46 },
  { s: 560, y: -31.0, w: 40 },     // kelp forest floor
  { s: 690, y: -46.0, w: 24 },     // kelp edge
  { s: 800, y: -105.0, w: 20 },    // THE SHELF BREAK — 60 m wall
  { s: 980, y: -126.0, w: 58 },    // drowned cathedral plateau (broad)
  { s: 1150, y: -216.0, w: 26 },   // cathedral rim — 90 m wall
  { s: 1350, y: -242.0, w: 72 },   // archway shelf 1 (broad)
  { s: 1530, y: -334.0, w: 26 },   // archway wall 2
  { s: 1730, y: -364.0, w: 78 },   // archway shelf 2
  { s: 1910, y: -452.0, w: 28 },   // canyon lip
  { s: 2110, y: -482.0, w: 84 },   // canyon plateau
  { s: 2330, y: -562.0, w: 32 },   // canyon shelf
  { s: 2570, y: -614.0, w: 94 },
  { s: 2870, y: -704.0, w: 40 },
  { s: 3170, y: -792.0, w: 106 },  // crystal abyss shoulder
  { s: 3490, y: -882.0, w: 50 },
  { s: 3830, y: -962.0, w: 122 },  // abyssal plain
  { s: 4200, y: -1048.0, w: 58 },
  { s: 4700, y: -1140.0, w: 90 },  // eternal blue floor
];

// z (metres) -> axial distance along the descent
const AXIAL = [
  [1800, 0], [1400, 90], [1150, 210], [900, 400], [700, 540],
  [520, 660], [360, 780], [200, 900], [40, 1060], [-140, 1240],
  [-340, 1430], [-560, 1660], [-800, 1980], [-1050, 2380],
  [-1300, 2860], [-1550, 3400], [-1800, 3980],
];
function axialS(z) {
  const n = AXIAL.length;
  if (z >= AXIAL[0][0]) return 0;
  if (z <= AXIAL[n - 1][0]) return AXIAL[n - 1][1];
  for (let i = 0; i < n - 1; i++) {
    const a = AXIAL[i], b = AXIAL[i + 1];
    if (z <= a[0] && z >= b[0]) {
      const u = (a[0] - z) / (a[0] - b[0]);
      return lerp(a[1], b[1], u);
    }
  }
  return AXIAL[n - 1][1];
}

function staircase(s) {
  // piecewise smoothstep between successive treads => flat treads, sharp risers
  if (s <= TREADS[0].s) return TREADS[0].y;
  for (let i = 1; i < TREADS.length; i++) {
    const a = TREADS[i - 1], b = TREADS[i];
    if (s < b.s) {
      const u = smoothstep(a.s + (a.w || 40) * 0.5, b.s - (b.w || 40) * 0.5, s);
      return lerp(a.y, b.y, u);
    }
  }
  return TREADS[TREADS.length - 1].y;
}

/** Local canyon carve: depth removed, 0 when outside any channel. */
function canyonField(x, z) {
  let carve = 0, depth = 0, wsum = 0;
  for (let c = 0; c < CANYONS.length; c++) {
    const cn = CANYONS[c];
    const d = distToPolyline(x, z, cn.pts);
    const w = cn.width[0] + (cn.width[1] - cn.width[0]) * 0.6;
    if (d > w * 1.4) continue;
    let f = 1 - smoothstep(w * 0.35, w * 1.05, d);
    f = Math.pow(f, 0.85 + cn.wall * 1.6);
    if (f > carve) {
      carve = f;
      depth = cn.depth[1] * (0.3 + 0.7 * f);
      wsum = w;
    }
  }
  return { carve, depth, width: wsum };
}

/** The macro/geological elevation field, before fine seabed detail. */
function macroHeight(x, z) {
  // --- axial coordinate: warped so no riser is a straight line
  const warpA = fbm2(x * 0.00052 + 3.1, z * 0.00052 - 7.7, 3) * 240
              + fbm2(x * 0.0018 - 11.3, z * 0.0018 + 2.9, 3) * 95
              + Math.sin(x * 0.00121 + 1.4) * 130;
  const warpB = fbm2(x * 0.00027 + 19.4, z * 0.00027 + 6.2, 2) * 330;  // long-wave meander
  // axial distance: non-linear so the shelf, reef and forest get real area
  // before the world plunges into the canyon country
  const s = clamp(axialS(z + warpA + warpB), -400, 5000);

  let h = staircase(s);

  // --- tread surface relief: gentle on the shelf, dramatic in the deep
  const depth = -h;
  const treadAmp = 1.6 + depth * 0.030;
  h += fbm2(x * 0.0022 + 4.7, z * 0.0022 - 9.4, 4) * treadAmp;
  h += fbm2(x * 0.0068 - 2.2, z * 0.0068 + 12.6, 3) * treadAmp * 0.5;
  // long geological swells (folds, not noise mush)
  h += fbm2(x * 0.00072 - 21.0, z * 0.00072 + 8.4, 2) * (5 + depth * 0.060);
  h += ridged2(x * 0.0017 + 6.6, z * 0.0017 - 14.2, 4) * (2 + depth * 0.045);

  // --- risers are not planes: cut steps, undercuts and buttresses into them
  const riserMask = clamp01(Math.abs(1 / (1 + Math.abs(dFbm(x, z))) - 0.0) * 0); // placeholder (unused)
  // stratification: fine terraces everywhere, strongest on steep ground
  const stratStep = 3.2 + 5.0 * clamp01(depth / 500);
  h = lerp(h, terrace(h, stratStep, 0.55), 0.35);

  // --- THE SHELF BREAK gets an undercut ledge (a place to swim beneath rock)
  const breakMask = Math.exp(-Math.pow((s - 880) / 110, 2));
  if (breakMask > 0.01) {
    h -= 9 * breakMask * clamp01(0.5 + fbm2(x * 0.004, z * 0.004, 2) * 2.0);
  }

  // --- authored massifs: hero rock islands standing on the treads
  const MASSIFS = [
    // x, z, rx, rz, height, rot
    [-1680, 520, 430, 330, 40, 0.4],
    [-980, 300, 300, 240, 26, -0.7],
    [720, 320, 380, 300, 44, 1.1],
    [1520, 40, 360, 300, 34, 0.2],
    [-260, 260, 470, 320, 30, -0.35],
    [240, -180, 380, 260, 24, 0.8],
    [-1180, -430, 340, 300, 30, 0.15],
    [520, -880, 330, 260, 26, -0.9],
    [-1420, -1150, 380, 300, 34, 0.5],
    [880, -1320, 340, 280, 28, 0.9],
    [-300, -720, 260, 210, 22, -0.4],
    [1260, -260, 300, 240, 26, 0.6],
  ];
  for (let i = 0; i < MASSIFS.length; i++) {
    const m = MASSIFS[i];
    const ca = Math.cos(m[5]), sa = Math.sin(m[5]);
    const dx = x - m[0], dz = z - m[1];
    const rx = dx * ca - dz * sa, rz = dx * sa + dz * ca;
    // noisy radial edge so massifs never read as ellipses
    const edge = 0.72 + 0.55 * (fbm2(x * 0.0035 + i * 5.1, z * 0.0035 - i * 2.7, 3) * 0.5 + 0.5);
    const b = blob(rx, rz, m[2] * edge, m[3] * edge);
    if (b > 0) {
      const top = terrace(m[4] * b, 7 + 9 * b, 0.5);
      h += top * (0.6 + 0.4 * (fbm2(x * 0.0041 + i, z * 0.0041 - i, 3) * 0.5 + 0.5));
    }
  }

  // --- canyon carving happens last so channels cut through treads & massifs
  const cf = canyonField(x, z);
  if (cf.carve > 0.002) {
    const floorY = h - cf.depth;
    h = lerp(h, floorY, cf.carve);
    // canyon floors collect sediment and boulder fields; gentle, no rings
    h += fbm2(x * 0.0045 + cf.width, z * 0.0045, 3) * 4.0 * cf.carve;
  }

  // --- VEILED CAVERNS: sunken halls with noisy, non-circular walls + real gates
  for (let i = 0; i < CHAMBERS.length; i++) {
    const c = CHAMBERS[i];
    const dx = x - c.x, dz = z - c.z;
    const ang = Math.atan2(dz, dx);
    const lobe = 1 + 0.3 * Math.sin(ang * 3 + i * 1.7) + 0.2 * Math.cos(ang * 5 - i);
    // stretch each hall along its gate axis -> slots and halls, never circles
    const ca = Math.cos(c.gateAngle), sa = Math.sin(c.gateAngle);
    const ex = (dx * ca + dz * sa) * c.elong, ez = (-dx * sa + dz * ca);
    const dd = Math.hypot(ex, ez) / lobe
             + fbm2(x * 0.0085 + i * 3.3, z * 0.0085 - i * 1.9, 3) * c.r * 0.55;
    if (dd > c.r * 2.2) continue;
    const bowl = 1 - smoothstep(c.r * 0.28, c.r * 1.5, dd);
    h -= c.depth * Math.pow(clamp01(bowl), 1.3);
    // entrance channel: carved outward so every chamber has a swimmable gate
    const gx = c.x + Math.cos(c.gateAngle) * c.r, gz = c.z + Math.sin(c.gateAngle) * c.r;
    const gd = distToPolyline(x, z, [[c.x, c.z], [gx, gz],
      [gx + Math.cos(c.gateAngle) * 150, gz + Math.sin(c.gateAngle) * 150]]);
    const gw = 1 - smoothstep(24, 78, gd);
    if (gw > 0) h -= c.depth * 0.5 * gw * (1 - smoothstep(c.r * 1.2, c.r * 2.6, dd));
  }

  // --- ETERNAL BLUE: abyssal basin + encircling trench, the deepest ground
  const basin = blob(x + 780, z + 1640, 900, 560);
  if (basin > 0) h -= 130 * Math.pow(basin, 1.2);
  const trench = Math.exp(-Math.pow(distToPolyline(x, z, [[-200, -1160], [-480, -1340], [-740, -1500], [-980, -1680]]) / 420, 2));
  h -= 70 * trench;

  // --- never break the surface: this is a submerged world
  h = Math.min(h, -4.5);
  h = Math.max(h, -1160);
  return h;
}

// tiny helper kept for future asymmetry work
function dFbm(x, z) { return fbm2(x * 0.005, z * 0.005, 2); }

/** Fine seabed detail layered on the macro field, scaled by depth. */
function detailHeight(x, z, base) {
  const d = -base;
  const amp = 0.5 + Math.min(7.0, d * 0.026);
  let n = fbm2(x * 0.0115 + 4.4, z * 0.0115 - 2.2, 4) * amp;
  n += fbm2(x * 0.028 - 1.1, z * 0.028 + 5.5, 3) * amp * 0.38;
  n += ridged2(x * 0.0058 + 8.8, z * 0.0058 - 6.6, 3) * amp * 0.5;
  return n;
}

// -----------------------------------------------------------------------------
// TerrainField: baked grid + fast queries used by EVERY system
// (rendering, collision, scattering, map). One source of truth = no seams.
// -----------------------------------------------------------------------------
export class TerrainField {
  constructor() {
    this.nx = WORLD.nx; this.nz = WORLD.nz;
    this.vx = this.nx + 1; this.vz = this.nz + 1;   // vertex counts
    this.cell = WORLD.cell;
    this.heights = new Float32Array(this.vx * this.vz);
  }

  xAt(i) { return WORLD.minX + i * this.cell; }
  zAt(j) { return WORLD.minZ + j * this.cell; }

  /** Build the full height grid. Returns generation stats. */
  build() {
    const t0 = (typeof performance !== 'undefined' ? performance.now() : Date.now());
    const { vx, vz, heights, cell } = this;
    for (let j = 0; j < vz; j++) {
      const z = WORLD.minZ + j * cell;
      for (let i = 0; i < vx; i++) {
        const x = WORLD.minX + i * cell;
        const m = macroHeight(x, z);
        heights[j * vx + i] = m + detailHeight(x, z, m);
      }
    }
    this.buildTime = (typeof performance !== 'undefined' ? performance.now() : Date.now()) - t0;
    // cache max/min
    let mn = 1e9, mx = -1e9;
    for (let k = 0; k < heights.length; k++) { const v = heights[k]; if (v < mn) mn = v; if (v > mx) mx = v; }
    this.minY = mn; this.maxY = mx;
    return this;
  }

  /** Bilinear height sample in world space (matches the rendered mesh exactly). */
  heightAt(x, z) {
    const fx = (x - WORLD.minX) / this.cell;
    const fz = (z - WORLD.minZ) / this.cell;
    let i = Math.floor(fx), j = Math.floor(fz);
    if (i < 0) i = 0; else if (i > this.nx - 1) i = this.nx - 1;
    if (j < 0) j = 0; else if (j > this.nz - 1) j = this.nz - 1;
    const tx = clamp01(fx - i), tz = clamp01(fz - j);
    const vx = this.vx;
    const h = this.heights;
    const h00 = h[j * vx + i], h10 = h[j * vx + i + 1];
    const h01 = h[(j + 1) * vx + i], h11 = h[(j + 1) * vx + i + 1];
    const a = h00 + (h10 - h00) * tx;
    const b = h01 + (h11 - h01) * tx;
    return a + (b - a) * tz;
  }

  /** Surface normal at a world position. */
  normalAt(x, z, out = { x: 0, y: 1, z: 0 }) {
    const e = this.cell;
    const hl = this.heightAt(x - e, z), hr = this.heightAt(x + e, z);
    const hd = this.heightAt(x, z - e), hu = this.heightAt(x, z + e);
    const nx = hl - hr, ny = 2 * e, nz = hd - hu;
    const len = Math.hypot(nx, ny, nz) || 1;
    out.x = nx / len; out.y = ny / len; out.z = nz / len;
    return out;
  }

  slopeAt(x, z) {
    const n = this.normalAt(x, z);
    return Math.acos(clamp(n.y, -1, 1));
  }

  /** 0..1 steepness. */
  steepness(x, z) {
    return 1 - this.normalAt(x, z).y;
  }

  /** Which region is the player in? Depth-aware, not just nearest-anchor. */
  regionAt(x, y, z) {
    let best = null, bestScore = 1e18;
    for (const r of REGIONS) {
      if (r.id === 'surface' && y < -12) continue;
      const d = Math.hypot(x - r.anchor[0], z - r.anchor[1]);
      const inDepth = y <= r.depth[0] + 14 && y >= r.depth[1] - 60;
      const score = d / r.radius + (inDepth ? 0 : 0.9);
      if (score < bestScore) { bestScore = score; best = r; }
    }
    return best || REGIONS[0];
  }

  depthAt(x, z) { return -this.heightAt(x, z); }
}

// -----------------------------------------------------------------------------
// Named landmarks for the map + navigation waypoints (positions in the
// continuous world — selecting one sets a waypoint, it never teleports).
// -----------------------------------------------------------------------------
export const LANDMARKS = [
  { name: 'Shelf Shallows', x: -700, z: 1290, y: -9, region: 'shelf' },
  { name: 'The Coral Terraces', x: -950, z: 880, y: -20, region: 'coral' },
  { name: 'Kelp Cathedral', x: -1800, z: 800, y: -24, region: 'kelp' },
  { name: 'The First Pillar', x: -350, z: 380, y: -60, region: 'cathedral' },
  { name: 'The Great Span', x: -250, z: -230, y: -150, region: 'archways' },
  { name: 'Azure Gate', x: -60, z: -560, y: -260, region: 'canyon' },
  { name: 'The Flooded Nave', x: 1080, z: 620, y: -120, region: 'caverns' },
  { name: 'Crystal Ridge', x: -480, z: -1330, y: -700, region: 'abyss' },
  { name: 'Eternal Blue Floor', x: -700, z: -1680, y: -1000, region: 'eternal' },
];

export const START_POSE = { x: -1000, y: -14, z: 1180, yaw: 0.12, pitch: -0.04 };

// -----------------------------------------------------------------------------
// THE LIVING ABYSS — marine ecology
// Seagrass meadows, kelp forest, and six coral families. Every plant and colony
// is procedurally grown geometry with per-vertex animation weights, dithered
// tint, and real grounding — nothing is a billboard or an extruded triangle.
// -----------------------------------------------------------------------------
import * as THREE from '../../vendor/three.module.js';
import { mulberry32, noise2, noise3, fbm2, fbm3, clamp, lerp, smoothstep } from '../core/noise.js';
import { WORLD, REGIONS } from './geography.js';
import { GLSL_HEADER, withShared, shared } from '../shaders/common.js';

// ---------------------------------------------------------------------------
// Materials
// ---------------------------------------------------------------------------
const PLANT_VS = /* glsl */`
attribute float aH;       // 0 base .. 1 tip
attribute float aPhase;
attribute float aStiff;
attribute vec3 aTint;
uniform float uTime;
uniform float uSwayAmp;
varying vec3 vWorld;
varying vec3 vNrm;
varying float vH;
varying vec3 vTint;

void main(){
  vec3 p = position;
  float t = uTime;
  float bend = pow(clamp(aH, 0.0, 1.0), 1.65) * aStiff;
  float w = sin(t * 0.42 + aPhase + p.y * 0.055) * 0.60
          + sin(t * 0.19 + aPhase * 2.3 + p.y * 0.021) * 0.40;
  float turb = sin(t * 0.85 + aPhase * 3.1 + p.y * 0.11) * 0.22;
  p.x += (w + turb) * bend * uSwayAmp;
  p.z += (w * 0.72 - turb * 0.58) * bend * uSwayAmp;
  // high-frequency flutter along fronds and blades
  p.x += sin(t * 2.1 + p.y * 0.85 + aPhase) * 0.05 * aH * aStiff;
  p.z += cos(t * 1.85 + p.y * 0.75 + aPhase) * 0.05 * aH * aStiff;

  vec4 wp = instanceMatrix * vec4(p, 1.0);
  wp = modelMatrix * wp;
  vWorld = wp.xyz;
  vNrm = normalize(mat3(modelMatrix) * mat3(instanceMatrix) * normal);
  vH = aH;
  vTint = aTint;
  gl_Position = projectionMatrix * viewMatrix * wp;
}
`;

const PLANT_FS = GLSL_HEADER + /* glsl */`
uniform vec3 uColorA;
uniform vec3 uColorB;
uniform float uTranslucency;
uniform float uSpecular;
varying vec3 vWorld;
varying vec3 vNrm;
varying float vH;
varying vec3 vTint;

void main(){
  vec3 N = normalize(vNrm);
  if (!gl_FrontFacing) N = -N;

  vec3 albedo = mix(uColorA, uColorB, clamp(vTint.x, 0.0, 1.0));
  albedo *= 0.78 + 0.44 * vTint.y;
  albedo = mix(albedo * 0.62, albedo, smoothstep(0.0, 0.55, vH));

  vec3 sun = sunlightAt(vWorld.y);
  float ndl = clamp(dot(N, uSunDir), 0.0, 1.0);
  // light passing THROUGH the blade — the thing that makes kelp glow
  float back = clamp(dot(-N, uSunDir), 0.0, 1.0);
  float trans = pow(back, 2.2) * uTranslucency;
  vec3 amb = ambientLight(vWorld.y) * 0.85 * (0.55 + 0.45 * clamp(N.y * 0.5 + 0.5, 0.0, 1.0));

  vec3 col = albedo * (sun * (ndl * 0.55 + trans * 1.35 + 0.12) + amb * 1.05);
  // wet sheen along the blade
  vec3 V = normalize(uCamPos - vWorld);
  vec3 H = normalize(uSunDir + V);
  col += sun * pow(clamp(dot(N, H), 0.0, 1.0), 26.0) * uSpecular;

  col = applyWater(col, vWorld);
  gl_FragColor = vec4(col, 1.0);
}
`;

function plantMaterial(opts = {}) {
  return new THREE.ShaderMaterial({
    uniforms: withShared({
      uSwayAmp: { value: opts.sway ?? 1.0 },
      uColorA: { value: new THREE.Vector3(...(opts.colorA || [0.14, 0.26, 0.10])) },
      uColorB: { value: new THREE.Vector3(...(opts.colorB || [0.36, 0.44, 0.14])) },
      uTranslucency: { value: opts.translucent ?? 0.8 },
      uSpecular: { value: opts.spec ?? 0.25 },
    }),
    vertexShader: PLANT_VS,
    fragmentShader: PLANT_FS,
    side: THREE.DoubleSide,
  });
}

// ---------------------------------------------------------------------------
// Geometry growth helpers
// ---------------------------------------------------------------------------
class GeoBuilder {
  constructor() { this.pos = []; this.nrm = []; this.h = []; this.phase = []; this.stiff = []; this.tint = []; this.idx = []; }
  get count() { return this.pos.length / 3; }
  /** Add a ribbon strip following a list of {p, side} centerline samples. */
  ribbon(samples, widthFn, phase, stiff, tint, twistPhase = 0) {
    const base = this.count;
    for (let i = 0; i < samples.length; i++) {
      const s = samples[i];
      const t = i / (samples.length - 1);
      const w = widthFn(t);
      for (let k = -1; k <= 1; k += 2) {
        const px = s.p.x + s.side.x * w * k * 0.5;
        const py = s.p.y + s.side.y * w * k * 0.5;
        const pz = s.p.z + s.side.z * w * k * 0.5;
        this.pos.push(px, py, pz);
        this.nrm.push(0, 1, 0);
        this.h.push(t);
        this.phase.push(phase);
        this.stiff.push(stiff);
        this.tint.push(tint[0], tint[1], 0);
      }
    }
    for (let i = 0; i < samples.length - 1; i++) {
      const a = base + i * 2, b = a + 1, c = a + 2, d = a + 3;
      this.idx.push(a, c, b, b, c, d);
    }
  }
  /** Add a tapered tube along a polyline (stipes, branches, sponge walls). */
  tube(pts, radiusFn, radial, phase, stiff, tint, capTop = false) {
    const base = this.count;
    const up = new THREE.Vector3(0, 1, 0);
    for (let i = 0; i < pts.length; i++) {
      const t = i / (pts.length - 1);
      const p = pts[i];
      const next = pts[Math.min(pts.length - 1, i + 1)];
      const prev = pts[Math.max(0, i - 1)];
      const dir = new THREE.Vector3().subVectors(next, prev).normalize();
      const side = new THREE.Vector3().crossVectors(dir, up);
      if (side.lengthSq() < 1e-5) side.set(1, 0, 0);
      side.normalize();
      const fwd = new THREE.Vector3().crossVectors(side, dir).normalize();
      const r = radiusFn(t);
      for (let j = 0; j <= radial; j++) {
        const a = (j / radial) * Math.PI * 2;
        const ca = Math.cos(a), sa = Math.sin(a);
        this.pos.push(
          p.x + side.x * ca * r + fwd.x * sa * r,
          p.y + side.y * ca * r + fwd.y * sa * r,
          p.z + side.z * ca * r + fwd.z * sa * r
        );
        this.nrm.push(side.x * ca + fwd.x * sa, side.y * ca + fwd.y * sa, side.z * ca + fwd.z * sa);
        this.h.push(t);
        this.phase.push(phase);
        this.stiff.push(stiff);
        this.tint.push(tint[0], tint[1], 0);
      }
    }
    for (let i = 0; i < pts.length - 1; i++) {
      for (let j = 0; j < radial; j++) {
        const a = base + i * (radial + 1) + j, b = a + 1;
        const c = a + radial + 1, d = c + 1;
        this.idx.push(a, c, b, b, c, d);
      }
    }
    if (capTop) {
      const cIdx = this.count;
      const last = base + (pts.length - 1) * (radial + 1);
      const p = pts[pts.length - 1];
      this.pos.push(p.x, p.y, p.z);
      this.nrm.push(0, 1, 0);
      this.h.push(1); this.phase.push(phase); this.stiff.push(stiff); this.tint.push(tint[0], tint[1], 0);
      for (let j = 0; j < radial; j++) this.idx.push(last + j, cIdx, last + j + 1);
    }
  }
  build() {
    const g = new THREE.BufferGeometry();
    g.setAttribute('position', new THREE.Float32BufferAttribute(this.pos, 3));
    g.setAttribute('normal', new THREE.Float32BufferAttribute(this.nrm, 3));
    g.setAttribute('aH', new THREE.Float32BufferAttribute(this.h, 1));
    g.setAttribute('aPhase', new THREE.Float32BufferAttribute(this.phase, 1));
    g.setAttribute('aStiff', new THREE.Float32BufferAttribute(this.stiff, 1));
    g.setAttribute('aTint', new THREE.Float32BufferAttribute(this.tint, 3));
    g.setIndex(this.idx);
    g.computeVertexNormals();
    return g;
  }
}

// ---------------------------------------------------------------------------
// KELP: a stipe carrying many long fronds, tallest plants 45 m
// ---------------------------------------------------------------------------
function makeKelp(rng, height) {
  const b = new GeoBuilder();
  const phase = rng() * 6.283;
  const twist = rng() * 6.283;
  const stipePts = [];
  const segs = 16;
  const lean = (rng() - 0.5) * 0.14;
  const lean2 = (rng() - 0.5) * 0.14;
  for (let i = 0; i <= segs; i++) {
    const t = i / segs;
    stipePts.push(new THREE.Vector3(
      lean * height * t * t + Math.sin(t * 3 + phase) * 0.4,
      t * height,
      lean2 * height * t * t + Math.cos(t * 2.4 + phase) * 0.4
    ));
  }
  // slim, flexible stipe
  b.tube(stipePts, (t) => (0.045 + 0.035 * (1 - t)) * (0.8 + height / 60), 5,
    phase, 0.22, [0.1 + rng() * 0.2, 0.5]);

  // long blades spiralling up the upper stipe: the actual forest
  const fronds = 34 + Math.floor(rng() * 16);
  for (let f = 0; f < fronds; f++) {
    const t0 = 0.10 + (f / fronds) * 0.88 + rng() * 0.02;
    const baseIdx = Math.min(segs, Math.floor(t0 * segs));
    const origin = stipePts[baseIdx].clone();
    const ang = twist + f * 2.399 + rng() * 0.4;
    // blades get longer toward the canopy
    const len = height * (0.30 + 0.46 * Math.pow(t0, 0.7)) * (0.75 + rng() * 0.55);
    const droop = 0.30 + rng() * 0.55;
    const samples = [];
    const nSeg = 9;
    const rise = 0.42 + t0 * 0.40;
    let prev = origin.clone();
    for (let i = 0; i <= nSeg; i++) {
      const u = i / nSeg;
      const r = len * u;
      const x = origin.x + Math.cos(ang) * r * (0.9 - droop * u * 0.5) + Math.sin(u * 4 + f) * len * 0.06;
      const z = origin.z + Math.sin(ang) * r * (0.9 - droop * u * 0.5) + Math.cos(u * 4.4 + f) * len * 0.06;
      const y = origin.y + len * (rise * u - droop * u * u * 1.15) + Math.sin(u * 5 + f * 2) * len * 0.04;
      const p = new THREE.Vector3(x, y, z);
      const dir = new THREE.Vector3().subVectors(p, prev);
      if (dir.lengthSq() < 1e-6) dir.set(0, 1, 0);
      const side = new THREE.Vector3().crossVectors(dir.normalize(), new THREE.Vector3(0, 1, 0));
      if (side.lengthSq() < 1e-5) side.set(1, 0, 0);
      side.normalize();
      samples.push({ p, side });
      prev = p;
    }
    // blade: narrow strap, widest in the middle, serrated silhouette
    const w0 = (0.23 + rng() * 0.17) * (height / 26 + 0.5);
    b.ribbon(samples, (t) => w0 * Math.sin(Math.pow(t, 0.5) * Math.PI) * (1 - 0.15 * t),
      phase + rng() * 2.0, 0.95 + rng() * 0.6,
      [rng(), 0.45 + rng() * 0.55]);
  }
  // floating canopy blades at the very top
  const topPts = 5 + Math.floor(rng() * 4);
  for (let f = 0; f < topPts; f++) {
    const origin = stipePts[segs].clone();
    const ang = twist + f * 1.7 + rng();
    const len = height * (0.10 + rng() * 0.14);
    const samples = [];
    for (let i = 0; i <= 7; i++) {
      const u = i / 7;
      const p = new THREE.Vector3(
        origin.x + Math.cos(ang) * len * u,
        origin.y + len * (0.25 * u - 0.5 * u * u),
        origin.z + Math.sin(ang) * len * u
      );
      samples.push({ p, side: new THREE.Vector3(-Math.sin(ang), 0, Math.cos(ang)) });
    }
    b.ribbon(samples, (t) => (0.22 + rng() * 0.12) * Math.sin(t * Math.PI) * (height / 26 + 0.5),
      phase + rng(), 1.1, [rng(), 0.6]);
  }
  return b.build();
}

// ---------------------------------------------------------------------------
// SEAGRASS clump: 7-13 curved blades
// ---------------------------------------------------------------------------
function makeGrassClump(rng) {
  const b = new GeoBuilder();
  const blades = 11 + Math.floor(rng() * 9);
  const phase = rng() * 6.283;
  for (let i = 0; i < blades; i++) {
    const ang = (i / blades) * 6.283 + rng() * 0.6;
    const len = 0.30 + rng() * 0.85;
    const lean = 0.35 + rng() * 0.6;
    const samples = [];
    const n = 5;
    for (let k = 0; k <= n; k++) {
      const u = k / n;
      const p = new THREE.Vector3(
        Math.cos(ang) * len * lean * u * u,
        len * u * (1 - 0.18 * u * u),
        Math.sin(ang) * len * lean * u * u
      );
      const side = new THREE.Vector3(-Math.sin(ang), 0, Math.cos(ang));
      samples.push({ p, side });
    }
    const w = 0.030 + rng() * 0.035;
    b.ribbon(samples, (t) => w * (1 - 0.85 * t * t), phase + rng(), 0.85,
      [rng(), 0.35 + rng() * 0.6]);
  }
  return b.build();
}

// ---------------------------------------------------------------------------
// CORAL families
// ---------------------------------------------------------------------------
function makeBranchingCoral(rng, scale = 1) {
  const b = new GeoBuilder();
  const phase = rng() * 6.283;
  const grow = (origin, dir, len, rad, depth) => {
    const pts = [];
    let p = origin.clone();
    const d = dir.clone();
    const segs = 4;
    for (let i = 0; i <= segs; i++) {
      pts.push(p.clone());
      d.x += (rng() - 0.5) * 0.45; d.z += (rng() - 0.5) * 0.45; d.y += 0.12;
      d.normalize();
      p = p.clone().addScaledVector(d, len / segs);
    }
    b.tube(pts, (t) => rad * (1 - 0.55 * t), 5, phase, 0.22,
      [rng(), 0.5 + rng() * 0.5]);
    if (depth > 0) {
      const branches = 2 + Math.floor(rng() * 2);
      for (let i = 0; i < branches; i++) {
        const start = pts[Math.floor(segs * (0.4 + rng() * 0.5))].clone();
        const nd = d.clone();
        const axis = new THREE.Vector3(rng() - 0.5, 0.3 + rng() * 0.7, rng() - 0.5).normalize();
        nd.lerp(axis, 0.55 + rng() * 0.35).normalize();
        grow(start, nd, len * (0.55 + rng() * 0.3), rad * 0.66, depth - 1);
      }
    }
  };
  const trunks = 3 + Math.floor(rng() * 4);
  for (let i = 0; i < trunks; i++) {
    const a = rng() * 6.283;
    const o = new THREE.Vector3(Math.cos(a) * rng() * 0.22 * scale, 0, Math.sin(a) * rng() * 0.22 * scale);
    const d = new THREE.Vector3(Math.cos(a) * 0.35, 1, Math.sin(a) * 0.35).normalize();
    grow(o, d, (0.55 + rng() * 0.6) * scale, 0.075 * scale, 3);
  }
  return b.build();
}

function makePlateCoral(rng, scale = 1) {
  const b = new GeoBuilder();
  const phase = rng() * 6.283;
  const tiers = 2 + Math.floor(rng() * 3);
  for (let t = 0; t < tiers; t++) {
    const y = 0.12 + t * 0.30 * scale;
    const rad = (0.75 - t * 0.16) * scale * (0.8 + rng() * 0.4);
    const a0 = rng() * 6.283;
    const samples = [];
    const rings = 4;
    for (let r = 0; r <= rings; r++) {
      const rr = (r / rings) * rad;
      const wobble = 1 + 0.14 * Math.sin(r * 2.1 + t);
      const pts = [];
      const seg = 22;
      for (let i = 0; i <= seg; i++) {
        const a = a0 + (i / seg) * 6.283 + t * 0.4;
        const ripple = 1 + 0.10 * Math.sin(a * 5 + t * 2);
        pts.push(new THREE.Vector3(
          Math.cos(a) * rr * ripple * wobble,
          y + rr * rr * 0.28 - r * 0.01,
          Math.sin(a) * rr * ripple * wobble
        ));
      }
      samples.push(pts);
    }
    const base = b.count;
    for (const ring of samples) {
      for (const p of ring) {
        const u = clamp(p.length() / (rad + 1e-4), 0, 1);
        b.pos.push(p.x, p.y, p.z);
        b.nrm.push(0, 1, 0);
        b.h.push(0.4 + t * 0.3);
        b.phase.push(phase);
        b.stiff.push(0.12);
        b.tint.push(rng() * 0.25 + u * 0.3, 0.4 + rng() * 0.5, 0);
      }
    }
    for (let r = 0; r < rings; r++) {
      for (let i = 0; i < 22; i++) {
        const a = base + r * 23 + i, bb = a + 1;
        const c = a + 23, d = c + 1;
        b.idx.push(a, c, bb, bb, c, d);
      }
    }
  }
  return b.build();
}

function makeFanCoral(rng, scale = 1) {
  const b = new GeoBuilder();
  const phase = rng() * 6.283;
  const h = (1.3 + rng() * 1.1) * scale;
  const ribs = 7 + Math.floor(rng() * 6);
  for (let i = 0; i < ribs; i++) {
    const t = i / (ribs - 1);
    const ang = -0.9 + t * 1.8;
    const pts = [];
    const seg = 6;
    for (let k = 0; k <= seg; k++) {
      const u = k / seg;
      pts.push(new THREE.Vector3(
        Math.sin(ang) * h * u * 0.85,
        h * u * (0.9 - 0.25 * u),
        Math.cos(ang) * h * u * 0.06 + Math.sin(u * 3 + i) * 0.03
      ));
    }
    b.tube(pts, (r) => (0.028 + 0.02 * (1 - t)) * scale * (1 - 0.4 * r), 4, phase,
      0.35, [rng() * 0.4, 0.5]);
    // webbing between ribs
    if (i < ribs - 1) {
      const ang2 = -0.9 + ((i + 1) / (ribs - 1)) * 1.8;
      const samples = [];
      for (let k = 1; k <= seg; k++) {
        const u = k / seg;
        const mx = (Math.sin(ang) + Math.sin(ang2)) * 0.5 * h * u * 0.85;
        const my = h * u * (0.9 - 0.25 * u);
        const mz = Math.cos((ang + ang2) * 0.5) * h * u * 0.06;
        samples.push({
          p: new THREE.Vector3(mx, my, mz),
          side: new THREE.Vector3(Math.cos((ang + ang2) * 0.5), 0, -Math.sin((ang + ang2) * 0.5)),
        });
      }
      b.ribbon(samples, (u) => (0.10 + 0.13 * (1 - u)) * scale, phase, 0.3,
        [rng() * 0.3, 0.6]);
    }
  }
  return b.build();
}

function makeSoftCoral(rng, scale = 1) {
  const b = new GeoBuilder();
  const phase = rng() * 6.283;
  const lobes = 3 + Math.floor(rng() * 4);
  for (let i = 0; i < lobes; i++) {
    const a = rng() * 6.283;
    const pts = [];
    const seg = 5;
    const lean = 0.3 + rng() * 0.5;
    for (let k = 0; k <= seg; k++) {
      const u = k / seg;
      pts.push(new THREE.Vector3(
        Math.cos(a) * lean * scale * u * u + Math.sin(u * 5 + i) * 0.06,
        u * (0.8 + rng() * 0.2) * scale,
        Math.sin(a) * lean * scale * u * u + Math.cos(u * 4 + i) * 0.06
      ));
    }
    b.tube(pts, (t) => (0.13 + 0.06 * Math.sin(t * 3 + i)) * scale * (1 + 0.35 * t), 7,
      phase, 0.9 + rng() * 0.4, [rng() * 0.5, 0.5 + rng() * 0.5], true);
  }
  return b.build();
}

function makeTubeSponge(rng, scale = 1) {
  const b = new GeoBuilder();
  const phase = rng() * 6.283;
  const tubes = 3 + Math.floor(rng() * 6);
  for (let i = 0; i < tubes; i++) {
    const a = rng() * 6.283;
    const rad = rng() * 0.4 * scale;
    const x = Math.cos(a) * rad, z = Math.sin(a) * rad;
    const h = (0.5 + rng() * 1.1) * scale;
    const r0 = (0.10 + rng() * 0.10) * scale;
    const pts = [];
    for (let k = 0; k <= 5; k++) {
      const u = k / 5;
      pts.push(new THREE.Vector3(
        x + Math.sin(u * 3 + i) * 0.05 * scale,
        u * h,
        z + Math.cos(u * 3.4 + i) * 0.05 * scale
      ));
    }
    b.tube(pts, (t) => r0 * (1 + 0.55 * t), 9, phase, 0.25, [rng() * 0.4, 0.6 + rng() * 0.4]);
    // rim ring to suggest a hollow mouth
    const top = pts[pts.length - 1];
    const rr = r0 * 1.55, inner = r0 * 1.05;
    const base = b.count;
    for (let j = 0; j <= 9; j++) {
      const ang = (j / 9) * 6.283;
      b.pos.push(top.x + Math.cos(ang) * rr, top.y, top.z + Math.sin(ang) * rr);
      b.nrm.push(0, 1, 0); b.h.push(1); b.phase.push(phase); b.stiff.push(0.25);
      b.tint.push(0.3, 0.9);
      b.pos.push(top.x + Math.cos(ang) * inner, top.y - r0 * 0.5, top.z + Math.sin(ang) * inner);
      b.nrm.push(0, 1, 0); b.h.push(1); b.phase.push(phase); b.stiff.push(0.25);
      b.tint.push(0.1, 0.5);
    }
    for (let j = 0; j < 9; j++) {
      const a2 = base + j * 2, b2 = a2 + 1, c2 = a2 + 2, d2 = a2 + 3;
      b.idx.push(a2, c2, b2, b2, c2, d2);
    }
  }
  return b.build();
}

function makeMassiveCoral(rng, scale = 1) {
  const b = new GeoBuilder();
  const phase = rng() * 6.283;
  const geo = new THREE.IcosahedronGeometry(0.62 * scale, 3);
  const pos = geo.attributes.position;
  const v = new THREE.Vector3();
  const seed = rng() * 90;
  for (let i = 0; i < pos.count; i++) {
    v.fromBufferAttribute(pos, i);
    const n = fbm3(v.x * 2.4 + seed, v.y * 2.4, v.z * 2.4, 4);
    const n2 = fbm3(v.x * 7.1, v.y * 7.1 + seed, v.z * 7.1, 3);
    // lobed, brain-like growth with deep grooves
    const groove = Math.abs(Math.sin(v.x * 6 + v.y * 4 + n * 6));
    v.multiplyScalar(1 + n * 0.42 - groove * 0.10 + n2 * 0.05);
    v.y = Math.max(-0.15 * scale, v.y * 0.72);
    pos.setXYZ(i, v.x, v.y, v.z);
  }
  geo.computeVertexNormals();
  const p = geo.attributes.position;
  for (let i = 0; i < p.count; i++) {
    b.pos.push(p.getX(i), p.getY(i), p.getZ(i));
    b.nrm.push(0, 1, 0);
    b.h.push(clamp(p.getY(i) / scale + 0.5, 0, 1));
    b.phase.push(phase);
    b.stiff.push(0.05);
    b.tint.push(rng() * 0.5, 0.35 + rng() * 0.5);
  }
  if (geo.index) {
    for (let i = 0; i < geo.index.count; i++) b.idx.push(geo.index.getX(i));
  } else {
    for (let i = 0; i < p.count; i++) b.idx.push(i);
  }
  return b.build();
}

// ---------------------------------------------------------------------------
// Scatter helper: group instances into spatial cells so culling works
// ---------------------------------------------------------------------------
function scatterInstanced(items, geo, material, cellSize, name) {
  const group = new THREE.Group();
  group.name = name;
  const cells = new Map();
  for (const it of items) {
    const cx = Math.floor((it.x - WORLD.minX) / cellSize);
    const cz = Math.floor((it.z - WORLD.minZ) / cellSize);
    const k = cx + ',' + cz;
    if (!cells.has(k)) cells.set(k, []);
    cells.get(k).push(it);
  }
  const m = new THREE.Matrix4();
  const q = new THREE.Quaternion();
  const e = new THREE.Euler();
  const sv = new THREE.Vector3();
  const pv = new THREE.Vector3();
  const meshes = [];
  for (const [, list] of cells) {
    const inst = new THREE.InstancedMesh(geo, material, list.length);
    const tint = new Float32Array(list.length * 3);
    list.forEach((it, i) => {
      e.set(it.tilt || 0, it.rot || 0, it.roll || 0);
      q.setFromEuler(e);
      sv.set(it.sx, it.sy, it.sz);
      pv.set(it.x, it.y, it.z);
      m.compose(pv, q, sv);
      inst.setMatrixAt(i, m);
      tint[i * 3] = it.t0;
      tint[i * 3 + 1] = it.t1;
      tint[i * 3 + 2] = 0;
    });
    geo.setAttribute('aTint', new THREE.InstancedBufferAttribute(tint, 3));
    // per-instance tint overrides the geometry's baked attribute
    inst.instanceMatrix.needsUpdate = true;
    inst.frustumCulled = true;
    meshes.push(inst);
    group.add(inst);
  }
  return { group, meshes };
}

// Because aTint lives on the geometry (shared), each cell needs its own clone.
function instancedGroup(items, geoFactory, material, cellSize, name) {
  const cells = new Map();
  for (const it of items) {
    const cx = Math.floor((it.x - WORLD.minX) / cellSize);
    const cz = Math.floor((it.z - WORLD.minZ) / cellSize);
    const k = cx + ',' + cz;
    if (!cells.has(k)) cells.set(k, []);
    cells.get(k).push(it);
  }
  const group = new THREE.Group();
  group.name = name;
  const m = new THREE.Matrix4();
  const q = new THREE.Quaternion();
  const e = new THREE.Euler();
  const sv = new THREE.Vector3();
  const pv = new THREE.Vector3();
  for (const [, list] of cells) {
    const geo = geoFactory.clone();
    const baseTint = geo.getAttribute('aTint');
    const tint = new Float32Array(list.length * 3);
    list.forEach((it, i) => {
      // bake this instance's tint into its own slot of the cloned attribute map
      tint[i * 3] = it.t0; tint[i * 3 + 1] = it.t1; tint[i * 3 + 2] = 0;
    });
    geo.setAttribute('aTint', new THREE.InstancedBufferAttribute(tint, 3));
    const inst = new THREE.InstancedMesh(geo, material, list.length);
    list.forEach((it, i) => {
      e.set(it.tilt || 0, it.rot || 0, it.roll || 0);
      q.setFromEuler(e);
      sv.set(it.sx || 1, it.sy || 1, it.sz || 1);
      pv.set(it.x, it.y, it.z);
      m.compose(pv, q, sv);
      inst.setMatrixAt(i, m);
    });
    inst.instanceMatrix.needsUpdate = true;
    inst.frustumCulled = true;
    group.add(inst);
  }
  return group;
}

// ---------------------------------------------------------------------------
// Build the ecology
// ---------------------------------------------------------------------------
export function buildFlora(field, state) {
  const group = new THREE.Group();
  group.name = 'flora';
  const rng = mulberry32(99001);

  const kelpMat = plantMaterial({
    sway: 2.2, colorA: [0.105, 0.170, 0.058], colorB: [0.29, 0.315, 0.070],
    translucent: 1.85, spec: 0.30,
  });
  const grassMat = plantMaterial({
    sway: 0.42, colorA: [0.10, 0.20, 0.075], colorB: [0.34, 0.40, 0.115],
    translucent: 0.85, spec: 0.14,
  });
  const coralMat = plantMaterial({
    sway: 0.22, colorA: [0.42, 0.20, 0.16], colorB: [0.72, 0.40, 0.26],
    translucent: 0.22, spec: 0.42,
  });
  const softCoralMat = plantMaterial({
    sway: 0.85, colorA: [0.40, 0.16, 0.22], colorB: [0.80, 0.42, 0.44],
    translucent: 0.55, spec: 0.3,
  });
  const spongeMat = plantMaterial({
    sway: 0.35, colorA: [0.20, 0.16, 0.20], colorB: [0.62, 0.32, 0.24],
    translucent: 0.3, spec: 0.35,
  });

  const inRegion = (x, z, cx, cz, rx, rz) => {
    const dx = (x - cx) / rx, dz = (z - cz) / rz;
    return 1 - smoothstep(0.55, 1.0, Math.sqrt(dx * dx + dz * dz));
  };

  // ---------------- seagrass ----------------
  const grassItems = [];
  for (let i = 0; i < 260000 && grassItems.length < 52000; i++) {
    const x = WORLD.minX + rng() * (WORLD.maxX - WORLD.minX);
    const z = WORLD.minZ + rng() * (WORLD.maxZ - WORLD.minZ);
    const y = field.heightAt(x, z);
    const depth = -y;
    if (depth > 34 || depth < 1.5) continue;
    const steep = field.steepness(x, z);
    if (steep > 0.35) continue;
    // patchy meadows, never a uniform carpet
    const patch = fbm2(x * 0.0075 + 4.4, z * 0.0075 - 2.2, 3) * 0.5 + 0.5;
    const p = smoothstep(0.52, 0.84, patch) * (1 - smoothstep(22, 34, depth) * 0.8);
    if (rng() > p) continue;
    const s = 0.55 + rng() * 0.85;
    grassItems.push({
      x, y: y - 0.05, z, rot: rng() * 6.283, sx: s, sy: s * (0.8 + rng() * 0.8), sz: s,
      t0: rng(), t1: 0.4 + rng() * 0.6,
    });
  }
  const grassGeo = makeGrassClump(rng);
  const grass = instancedGroup(grassItems, grassGeo, grassMat, 700, 'seagrass');
  group.add(grass);

  // ---------------- kelp forest ----------------
  const kelpGeos = [];
  const kelpHeights = [];
  for (let i = 0; i < 4; i++) {
    const hgt = 24 + rng() * 22;
    kelpHeights.push(hgt);
    kelpGeos.push(makeKelp(rng, hgt));
  }
  const kelpItems = [[], [], [], []];
  for (let i = 0; i < 260000; i++) {
    const x = WORLD.minX + rng() * (WORLD.maxX - WORLD.minX);
    const z = WORLD.minZ + rng() * (WORLD.maxZ - WORLD.minZ);
    const y = field.heightAt(x, z);
    const depth = -y;
    if (depth < 6 || depth > 62) continue;
    // the forest: strong in the west, thinning to scattered stands elsewhere
    const forest = inRegion(x, z, -1760, 430, 820, 760);
    const shelfEdge = inRegion(x, z, -1100, 640, 900, 520) * 0.5;
    const patch = fbm2(x * 0.0042 - 7.7, z * 0.0042 + 2.1, 3) * 0.5 + 0.5;
    let p = (forest * 1.25 + shelfEdge) * smoothstep(0.38, 0.80, patch);
    p *= 1 - smoothstep(40, 62, depth) * 0.75;
    const steep = field.steepness(x, z);
    if (steep > 0.55) p *= 0.35;
    if (rng() > p * 0.92) continue;
    if (kelpItems[0].length + kelpItems[1].length + kelpItems[2].length + kelpItems[3].length > 10500) break;
    const v = Math.floor(rng() * 4);
    const sc = 0.70 + Math.pow(rng(), 1.4) * 1.05;
    let sy = sc * (0.8 + rng() * 0.6);
    // a plant must never push through the sea surface
    const maxSy = (depth - 1.6) / kelpHeights[v];
    if (maxSy < 0.32) continue;
    sy = Math.min(sy, maxSy);
    kelpItems[v].push({
      x, y: y - 0.4, z, rot: rng() * 6.283, tilt: (rng() - 0.5) * 0.10,
      sx: sc, sy, sz: sc,
      t0: rng() * 0.4, t1: 0.45 + rng() * 0.55,
    });
  }
  kelpGeos.forEach((g, i) => {
    if (!kelpItems[i].length) return;
    group.add(instancedGroup(kelpItems[i], g, kelpMat, 900, 'kelp' + i));
  });

  // ---------------- coral gardens ----------------
  // Reefs are not evenly spread: colonies crowd onto a dozen patch reefs, so a
  // diver meets real walls of coral and then open sand between them.
  const reefPatches = [];
  {
    const pr = mulberry32(4242);
    for (let i = 0; i < 16; i++) {
      const ang = pr() * Math.PI * 2;
      const rad = Math.pow(pr(), 0.65) * 620;
      const px = -950 + Math.cos(ang) * rad;
      const pz = 780 + Math.sin(ang) * rad * 0.85;
      const h = field.heightAt(px, pz);
      if (-h < 2 || -h > 40) continue;
      reefPatches.push({ x: px, z: pz, r: 70 + pr() * 130, w: 0.7 + pr() * 0.6 });
    }
  }
  const patchWeight = (x, z) => {
    let w = 0;
    for (const pch of reefPatches) {
      const d = Math.hypot(x - pch.x, z - pch.z) / pch.r;
      w = Math.max(w, (1 - smoothstep(0.25, 1.0, d)) * pch.w);
    }
    return w;
  };
  const coralFamilies = [
    { geo: makeBranchingCoral(rng, 1.5), mat: coralMat, count: 5200, name: 'coral_branching', w: 0.30 },
    { geo: makePlateCoral(rng, 1.9), mat: coralMat, count: 1500, name: 'coral_plate', w: 0.16 },
    { geo: makeFanCoral(rng, 1.5), mat: softCoralMat, count: 1900, name: 'coral_fan', w: 0.16 },
    { geo: makeSoftCoral(rng, 1.5), mat: softCoralMat, count: 2400, name: 'coral_soft', w: 0.16 },
    { geo: makeTubeSponge(rng, 1.8), mat: spongeMat, count: 1100, name: 'sponge', w: 0.11 },
    { geo: makeMassiveCoral(rng, 2.2), mat: coralMat, count: 1300, name: 'coral_massive', w: 0.11 },
  ];

  for (const fam of coralFamilies) {
    const items = [];
    let guard = 0;
    while (items.length < fam.count && guard < fam.count * 60) {
      guard++;
      const x = WORLD.minX + rng() * (WORLD.maxX - WORLD.minX);
      const z = WORLD.minZ + rng() * (WORLD.maxZ - WORLD.minZ);
      const y = field.heightAt(x, z);
      const depth = -y;
      if (depth > 95 || depth < 2) continue;
      // where reefs are: the coral garden, the cathedral edges, archway shelves
      const garden = inRegion(x, z, -950, 780, 700, 640);
      const cath = inRegion(x, z, -300, 120, 900, 620) * 0.75;
      const arch = inRegion(x, z, -250, -520, 1200, 800) * 0.55;
      const caves = inRegion(x, z, 1180, 60, 620, 620) * 0.6;
      let p = garden * 1.0 + cath + arch + caves;
      p *= 1 - smoothstep(40, 95, depth) * 0.85;
      p = p * 0.34 + patchWeight(x, z) * 1.5;
      // colonies cluster on rock — steepness and noise both drive it
      const steep = field.steepness(x, z);
      const clump = fbm2(x * 0.011 + 8.8, z * 0.011 - 3.3, 3) * 0.5 + 0.5;
      p *= (0.35 + steep * 1.6) * smoothstep(0.30, 0.80, clump);
      if (rng() > p * 0.9) continue;
      const s = 0.65 + Math.pow(rng(), 1.6) * 2.1;
      items.push({
        x, y: y - 0.08, z, rot: rng() * 6.283,
        tilt: (rng() - 0.5) * 0.22, roll: (rng() - 0.5) * 0.22,
        sx: s, sy: s * (0.8 + rng() * 0.5), sz: s,
        t0: rng(), t1: 0.30 + rng() * 0.7,
      });
    }
    group.add(instancedGroup(items, fam.geo, fam.mat, 600, fam.name));
  }

  const meshes = [];
  group.traverse((o) => { if (o.isInstancedMesh) meshes.push(o); });

  group.userData.update = () => {};
  group.userData.setQuality = (q) => {
    const f = q === 'low' ? 0.25 : q === 'medium' ? 0.55 : q === 'ultra' ? 1.0 : 0.85;
    for (const m of meshes) {
      if (!m.userData.fullCount) m.userData.fullCount = m.count;
      m.count = Math.max(1, Math.floor(m.userData.fullCount * f));
    }
  };
  return group;
}

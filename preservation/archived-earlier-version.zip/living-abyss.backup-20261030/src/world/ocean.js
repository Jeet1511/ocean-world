// -----------------------------------------------------------------------------
// THE LIVING ABYSS — sky dome + the ocean surface
// The surface is a single mesh with two different shadings: what you see from
// the air, and what you see from below (Snell's window + total internal
// reflection). One continuous body of water, no separate regions.
// -----------------------------------------------------------------------------
import * as THREE from '../../vendor/three.module.js';
import { SKY_UNIFORMS, GLSL_SKY_FUNCS, SKY_VS, SKY_FS } from '../shaders/sky.js';
import { GLSL_NOISE, GLSL_MEDIUM, GLSL_LIGHT, GLSL_ROCK, withShared } from '../shaders/common.js';

export function buildSky() {
  const geo = new THREE.SphereGeometry(16000, 48, 32);
  const mat = new THREE.ShaderMaterial({
    uniforms: withShared({
      uUnderwater: { value: 0 },
      uWaterFar: { value: new THREE.Vector3(0.05, 0.2, 0.25) },
    }),
    vertexShader: SKY_VS,
    fragmentShader: SKY_FS,
    side: THREE.BackSide,
    depthWrite: false,
    depthTest: false,
  });
  const mesh = new THREE.Mesh(geo, mat);
  mesh.name = 'sky';
  mesh.renderOrder = -100;
  mesh.frustumCulled = false;
  return mesh;
}

// ---------------------------------------------------------------------------
// Ocean surface
// ---------------------------------------------------------------------------
const OCEAN_VS = /* glsl */`
uniform float uTime;
varying vec3 vWorld;
varying vec3 vWaves;

// four directional swells (+ analytic normal)
vec3 swell(vec2 p, vec2 dir, float len, float amp, float speed, float t){
  float k = 6.2831853 / len;
  float a = dot(normalize(dir), p) * k + t * speed * k;
  float h = amp * sin(a);
  float dh = amp * k * cos(a);
  return vec3(h, dh * normalize(dir).x, dh * normalize(dir).y);
}

void main(){
  vec4 wp = modelMatrix * vec4(position, 1.0);
  vec2 p = wp.xz;
  float t = uTime;

  vec3 s = swell(p, vec2(1.0, -0.35), 210.0, 0.62, 0.55, t);
  vec3 s2 = swell(p, vec2(0.55, 1.0), 118.0, 0.34, 0.85, t);
  vec3 s3 = swell(p, vec2(-0.8, -0.6), 57.0, 0.16, 1.25, t);
  vec3 s4 = swell(p, vec2(1.0, 0.85), 26.0, 0.075, 1.9, t);

  wp.y += s.x + s2.x + s3.x + s4.x;

  float dx = s.y + s2.y + s3.y + s4.y;
  float dz = s.z + s2.z + s3.z + s4.z;
  vWaves = vec3(-dx, 1.0, -dz);
  vWorld = wp.xyz;
  gl_Position = projectionMatrix * viewMatrix * wp;
}
`;

const OCEAN_FS_BODY = /* glsl */`
varying vec3 vWorld;
varying vec3 vWaves;

void main(){
  vec3 wp = vWorld;
  vec3 N = normalize(vWaves);
  // high-frequency chop, faded with distance to avoid shimmer
  float dist0 = length(uCamPos - wp);
  float chopFade = 1.0 - smoothstep(120.0, 1400.0, dist0);
  vec3 chopN = vec3(
    vnoise2(wp.xz * 0.55 + uTime * 0.35) - 0.5,
    0.0,
    vnoise2(wp.xz * 0.55 - uTime * 0.31 + 12.7) - 0.5
  ) * 1.4;
  N = normalize(N + chopN * chopFade);

  // Branch on where the eye is, not on triangle winding: at grazing angles the
  // projected winding of a 35 m quad flips and paints black bands on the horizon.
  if (uCamPos.y > 0.0) {
    // ---------------- seen from the air ----------------
    vec3 V = normalize(uCamPos - wp);
    vec3 R = reflect(-V, N);
    R.y = abs(R.y);
    float fres = 0.020 + 0.980 * pow(1.0 - clamp(dot(N, V), 0.0, 1.0), 5.0);
    vec3 sky = skyRadiance(R);
    vec3 deep = vec3(0.0055, 0.052, 0.088);
    vec3 col = mix(deep, sky, clamp(0.22 + 0.78 * fres, 0.0, 1.0));

    // sub-surface glow where the sun passes through thin crests
    float back = pow(max(dot(-V, uSunDir), 0.0), 3.0);
    col += vec3(0.04, 0.28, 0.30) * back * 0.55;

    // glitter path
    float spec = pow(max(dot(R, uSunDir), 0.0), 420.0) * 14.0;
    float glit = pow(max(dot(R, uSunDir), 0.0), 42.0) * 0.9;
    col += uSunColor * (spec + glit) * (0.5 + 0.5 * chopFade + 0.5);

    // aerial perspective toward the horizon
    float hz = smoothstep(2000.0, 15000.0, dist0);
    col = mix(col, skyRadiance(normalize(vec3(R.x, 0.02, R.z))), hz * 0.85);
    gl_FragColor = vec4(col, 1.0);
    return;
  }

  // ---------------- seen from below ----------------
  vec3 rayDir = normalize(wp - uCamPos);   // up toward the surface
  N = normalize(vec3(-N.x, 1.0, -N.z));
  vec3 nUp = normalize(vec3(N.x, -1.0, N.z));
  float cosT = clamp(dot(rayDir, nUp), 0.0, 1.0);
  float sinT = sqrt(max(0.0, 1.0 - cosT * cosT));
  const float IOR = 1.333;
  float critical = 1.0 / IOR;              // 0.75 -> Snell's window edge

  // Snell's window: inside it you see the sky, outside it is a mirror
  float win = 1.0 - smoothstep(critical * 0.90, critical * 1.02, sinT);

  vec3 refr = refract(rayDir, nUp, 1.0 / IOR);
  if (length(refr) < 0.001) refr = nUp;
  vec3 through = skyRadiance(normalize(refr));

  // Total internal reflection: the underside mirrors whatever is below it.
  // Over shallow reefs that mirror is bright sand and sunlit water — never a
  // black lid across the horizon.
  float shallowW = smoothstep(-70.0, -2.0, uCamPos.y);
  vec3 mirrored = mix(waterAmbient(uCamPos.y) * 0.85, waterAmbient(0.0) * 1.25 + vec3(0.16, 0.30, 0.30), shallowW);
  mirrored += vec3(0.10, 0.28, 0.30) * pow(max(dot(rayDir, uSunDir), 0.0), 3.0);
  mirrored *= 0.72 + 0.5 * (0.5 + 0.5 * vnoise2(wp.xz * 0.35 + uTime * 0.2));

  vec3 col = mix(mirrored, through * 0.62, win * (1.0 - 0.55 * pow(sinT, 8.0)));
  col += uSunColor * pow(max(dot(refr, uSunDir), 0.0), 300.0) * 6.0 * win;

  // surface shimmer
  col *= 0.86 + 0.28 * vnoise2(wp.xz * 1.1 + uTime * 0.6);

  // Whatever the far field computes, at range the underside of the surface is
  // just the water column seen edge-on. Clamp it so no distant artefact can
  // paint a dark band across the horizon.
  float farField = smoothstep(110.0, 620.0, dist0);
  col = mix(col, waterAmbient(uCamPos.y), farField);

  // From depth the ceiling of the world is not a black lid: it dissolves into
  // the water column long before the surface itself is reachable by light.
  float deepFade = smoothstep(70.0, 300.0, -uCamPos.y);
  col = max(col, waterAmbient(uCamPos.y) * 0.85);
  col = mix(col, waterAmbient(uCamPos.y) * 0.80, deepFade);

  col = applyWater(col, wp);
  gl_FragColor = vec4(col, 1.0);
}
`;

export function buildOcean() {
  const group = new THREE.Group();
  group.name = 'ocean';

  const size = 5200;
  const geo = new THREE.PlaneGeometry(size, size, 150, 150);
  geo.rotateX(-Math.PI / 2);

  const uniforms = withShared({});

  const mat = new THREE.ShaderMaterial({
    uniforms,
    vertexShader: OCEAN_VS,
    fragmentShader: GLSL_NOISE + GLSL_MEDIUM + GLSL_LIGHT + GLSL_SKY_FUNCS + OCEAN_FS_BODY,
    side: THREE.DoubleSide,
  });
  const mesh = new THREE.Mesh(geo, mat);
  mesh.frustumCulled = false;
  mesh.renderOrder = 10;
  group.add(mesh);

  // Far field. The inner radius MUST stay inside the near plane's smallest
  // half-extent (2600): a ring starting at 3400 left an 800 m annulus of open
  // sky showing through as a hard dark band lying along the horizon.
  const ringGeo = new THREE.RingGeometry(1800, 60000, 120, 12);
  ringGeo.rotateX(-Math.PI / 2);
  const ring = new THREE.Mesh(ringGeo, mat);
  ring.position.y = -0.6;
  ring.frustumCulled = false;
  ring.renderOrder = 10;
  group.add(ring);

  group.userData.material = mat;
  group.userData.follow = true;
  return group;
}

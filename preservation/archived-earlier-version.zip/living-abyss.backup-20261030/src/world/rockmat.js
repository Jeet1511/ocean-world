// -----------------------------------------------------------------------------
// THE LIVING ABYSS — rock material
// One material for every solid geological form in the world: seabed, towers,
// arches, shelves, boulders, cavern roofs. Same shader as the terrain, so a
// pillar and the ground it grows from are literally the same rock.
// -----------------------------------------------------------------------------
import * as THREE from '../../vendor/three.module.js';
import { GLSL_HEADER, withShared } from '../shaders/common.js';

export const ROCK_VS = /* glsl */`
attribute float aAO;
varying vec3 vWorld;
varying vec3 vNrm;
varying float vAO;
void main(){
  vec4 wp = modelMatrix * vec4(position, 1.0);
  vWorld = wp.xyz;
  vNrm = normalize(mat3(modelMatrix) * vec3(normal));
  vAO = aAO;
  gl_Position = projectionMatrix * viewMatrix * wp;
}
`;

export const ROCK_FS = GLSL_HEADER + /* glsl */`
uniform float uDetail;
uniform float uDarken;
uniform float uCaveLit;      // 1 = surface rock, 0 = deep interior rock
varying vec3 vWorld;
varying vec3 vNrm;
varying float vAO;

void main(){
  vec3 N = normalize(vNrm);
  float detailH;
  float dcam = length(uCamPos - vWorld);
  float nf = 1.0 - smoothstep(30.0, 240.0, dcam);
  vec3 albedo = rockAlbedo(vWorld, N, 1.0, nf, detailH);
  N = sandRippleNormal(vWorld, N, nf);

  // interior rock is darker, more mineral, less sediment
  albedo = mix(albedo * vec3(0.72, 0.76, 0.82), albedo, uCaveLit);

  float dist = dcam;
  float nearF = nf;
  N = perturbNormal(vWorld, N, 0.30, uDetail * (0.75 + 0.6 * nearF));
  if (nearF > 0.02) {
    N = perturbNormal(vWorld, N, 1.5, uDetail * 0.45 * nearF);
    N = perturbNormal(vWorld, N, 6.0, uDetail * 0.22 * nearF);
  }

  vec3 col = litSurface(albedo, N, vWorld, 0.7, clamp(vAO, 0.0, 1.0), 1.0);
  col *= uDarken;
  col = applyWater(col, vWorld);
  gl_FragColor = vec4(col, 1.0);
}
`;

export function createRockMaterial(opts = {}) {
  return new THREE.ShaderMaterial({
    uniforms: withShared({
      uDetail: { value: opts.detail ?? 1.0 },
      uDarken: { value: opts.darken ?? 1.0 },
      uCaveLit: { value: opts.caveLit ?? 1.0 },
    }),
    vertexShader: ROCK_VS,
    fragmentShader: ROCK_FS,
    side: opts.side ?? THREE.FrontSide,
    transparent: !!opts.transparent,
  });
}

export const rockMaterial = createRockMaterial({ detail: 1.0 });

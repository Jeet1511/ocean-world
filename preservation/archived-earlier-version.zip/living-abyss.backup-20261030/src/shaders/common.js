// -----------------------------------------------------------------------------
// THE LIVING ABYSS — GLSL library
// One water medium, one lighting model, one rock language. Every material in the
// world includes these chunks, so the whole ocean reads as a single place.
// -----------------------------------------------------------------------------
import * as THREE from '../../vendor/three.module.js';

// ---------------------------------------------------------------------------
// Shared uniforms. The same objects are injected into every material, so one
// update per frame drives the entire world.
// ---------------------------------------------------------------------------
export const shared = {
  uTime: { value: 0 },
  uSunDir: { value: new THREE.Vector3(0.58, 0.60, -0.55).normalize() },
  uSunColor: { value: new THREE.Vector3(1.0, 0.93, 0.82) },
  uCamPos: { value: new THREE.Vector3() },
  uSurfaceY: { value: 0 },
  uFogScale: { value: 1.0 },
  uCausticStrength: { value: 1.0 },
};

// ---------------------------------------------------------------------------
// Noise toolkit (value noise + fbm, all gradients analytic-free)
// ---------------------------------------------------------------------------
export const GLSL_NOISE = /* glsl */`
float hash11(float p){ p = fract(p*0.1031); p *= p + 33.33; return fract(p*p); }
float hash12(vec2 p){ vec3 p3 = fract(vec3(p.xyx)*0.1031); p3 += dot(p3, p3.yzx+33.33); return fract((p3.x+p3.y)*p3.z); }
float hash13(vec3 p3){ p3 = fract(p3*0.1031); p3 += dot(p3, p3.zyx+31.32); return fract((p3.x+p3.y)*p3.z); }

float vnoise3(vec3 x){
  vec3 i = floor(x), f = fract(x);
  f = f*f*(3.0-2.0*f);
  float n000 = hash13(i+vec3(0.0,0.0,0.0)), n100 = hash13(i+vec3(1.0,0.0,0.0));
  float n010 = hash13(i+vec3(0.0,1.0,0.0)), n110 = hash13(i+vec3(1.0,1.0,0.0));
  float n001 = hash13(i+vec3(0.0,0.0,1.0)), n101 = hash13(i+vec3(1.0,0.0,1.0));
  float n011 = hash13(i+vec3(0.0,1.0,1.0)), n111 = hash13(i+vec3(1.0,1.0,1.0));
  return mix(mix(mix(n000,n100,f.x), mix(n010,n110,f.x), f.y),
             mix(mix(n001,n101,f.x), mix(n011,n111,f.x), f.y), f.z);
}
float vnoise2(vec2 x){
  vec2 i = floor(x), f = fract(x);
  f = f*f*(3.0-2.0*f);
  float a = hash12(i), b = hash12(i+vec2(1.0,0.0));
  float c = hash12(i+vec2(0.0,1.0)), d = hash12(i+vec2(1.0,1.0));
  return mix(mix(a,b,f.x), mix(c,d,f.x), f.y);
}
float fbm3(vec3 p, int oct){
  float s = 0.0, a = 0.5, n = 0.0;
  for (int i = 0; i < 6; i++){
    if (i >= oct) break;
    s += a * vnoise3(p); n += a;
    p = p * 2.03 + vec3(1.7, 9.2, 3.4); a *= 0.5;
  }
  return s / max(n, 1e-4);
}
float fbm2(vec2 p, int oct){
  float s = 0.0, a = 0.5, n = 0.0;
  for (int i = 0; i < 6; i++){
    if (i >= oct) break;
    s += a * vnoise2(p); n += a;
    p = p * 2.03 + vec2(3.1, 7.7); a *= 0.5;
  }
  return s / max(n, 1e-4);
}
float ridge3(vec3 p, int oct){
  float s = 0.0, a = 0.5, n = 0.0;
  for (int i = 0; i < 5; i++){
    if (i >= oct) break;
    float v = 1.0 - abs(vnoise3(p)*2.0-1.0);
    s += a * v * v; n += a;
    p = p * 2.11 + vec3(5.2, 1.3, 8.8); a *= 0.5;
  }
  return s / max(n, 1e-4);
}
// 3D gradient (4 taps) — for bump-mapping procedural detail without tangents
vec3 noiseGrad3(vec3 p, float e){
  float c = fbm3(p, 3);
  return vec3(fbm3(p+vec3(e,0.0,0.0),3)-c,
              fbm3(p+vec3(0.0,e,0.0),3)-c,
              fbm3(p+vec3(0.0,0.0,e),3)-c) / e;
}
`;

// ---------------------------------------------------------------------------
// The water medium: wavelength-dependent extinction + depth-graded inscatter.
// This is what makes the shelf turquoise, the archways cobalt and the abyss
// blue-black — one system, continuous over the entire 1.15 km water column.
// ---------------------------------------------------------------------------
export const GLSL_WATER_AMBIENT = /* glsl */`
// Ambient colour of the water body as a function of elevation.
vec3 waterAmbient(float y){
  float d = max(-y, 0.0);
  vec3 c = vec3(0.072, 0.330, 0.408);
  c = mix(c, vec3(0.060, 0.300, 0.420), smoothstep(0.0, 24.0, d));
  c = mix(c, vec3(0.032, 0.180, 0.320), smoothstep(24.0, 70.0, d));
  c = mix(c, vec3(0.026, 0.140, 0.285), smoothstep(70.0, 180.0, d));
  c = mix(c, vec3(0.013, 0.080, 0.185), smoothstep(180.0, 420.0, d));
  c = mix(c, vec3(0.0060, 0.036, 0.098), smoothstep(420.0, 800.0, d));
  c = mix(c, vec3(0.0030, 0.016, 0.048), smoothstep(800.0, 1200.0, d));
  return c;
}

`;

export const GLSL_MEDIUM = GLSL_WATER_AMBIENT + /* glsl */`
uniform float uTime;
uniform vec3 uSunDir;
uniform vec3 uSunColor;
uniform vec3 uCamPos;
uniform float uSurfaceY;
uniform float uFogScale;
uniform float uCausticStrength;

// Extinction coefficients per metre (RGB). Red dies ~4x faster than blue.
const vec3 WATER_SIGMA = vec3(0.0400, 0.0210, 0.0135);

// Diffuse irradiance at elevation y. Deeper water scatters what little light it
// receives in every direction, so the diffuse fill does not fall off as fast as
// the fog colour does — this is what keeps deep rock readable instead of black.
vec3 ambientLight(float y){
  float d = max(-y, 0.0);
  float boost = 1.0 + 1.5 * pow(smoothstep(25.0, 620.0, d), 0.72);
  return waterAmbient(y) * boost;
}

// Direct sunlight remaining at elevation y (colour-shifted, energy falloff).
vec3 sunlightAt(float y){
  float d = max(-y, 0.0);
  vec3 att = exp(-vec3(0.0165, 0.0092, 0.0060) * d);
  // a little extra loss in the abyss so nothing reads as "lit from nowhere"
  att *= 1.0 - 0.38 * smoothstep(400.0, 1100.0, d);
  return uSunColor * att * 0.95;
}

// Medium density grows with depth (suspended sediment + fewer photons)
float fogDensity(float y){
  // Coastal water in the top 30 m is visibly turbid; below the thermocline the
  // water clears again. This is what stops the sea surface from reading as a
  // saturated cyan wall across the horizon at 20 m.
  return uFogScale * (0.74 - 0.32 * smoothstep(12.0, 110.0, -y) + 0.14 * smoothstep(600.0, 1100.0, -y));
}

// The single most important function in the project.
vec3 applyWater(vec3 color, vec3 wp){
  vec3 V = wp - uCamPos;
  float dist = length(V);
  float midY = 0.5 * (wp.y + uCamPos.y);
  vec3 sigma = WATER_SIGMA * fogDensity(midY);
  vec3 T = exp(-sigma * dist);
  vec3 amb = waterAmbient(midY);
  float up = clamp(normalize(V).y * 0.5 + 0.5, 0.0, 1.0);
  // light coming from the surface above: brighter when we look up into it
  vec3 inscat = amb * (0.80 + 0.55 * up * up);
  // a touch of surface glare in the first few metres only
  float shallow = smoothstep(-18.0, -1.0, midY);
  inscat += vec3(0.055, 0.115, 0.125) * shallow * up * up;
  return color * T + inscat * (1.0 - T);
}
`;

// ---------------------------------------------------------------------------
// Lighting: sun + water ambient + procedural caustics + wet specular
// ---------------------------------------------------------------------------
export const GLSL_LIGHT = /* glsl */`
// Classic animated caustic web. Two scales, one direction of motion.
// Self-contained value noise: GLSL_LIGHT is included by materials that do not
// pull in GLSL_NOISE, so this function may not depend on any shared chunk.
float causticHash(vec2 p){
  return fract(sin(dot(p, vec2(127.1, 311.7))) * 43758.5453123);
}
float causticNoise(vec2 p){
  vec2 i = floor(p), f = fract(p);
  vec2 u = f * f * (3.0 - 2.0 * f);
  return mix(mix(causticHash(i), causticHash(i + vec2(1.0, 0.0)), u.x),
             mix(causticHash(i + vec2(0.0, 1.0)), causticHash(i + vec2(1.0, 1.0)), u.x), u.y);
}

float causticPattern(vec2 p, float t){
  // domain-warped interference, ridged into thin bright filaments
  vec2 q = p;
  q += 0.62 * vec2(causticNoise(p * 0.55 + vec2(t * 0.13, 0.0)),
                   causticNoise(p * 0.55 + vec2(0.0, -t * 0.11) + 17.0));
  float a = sin(q.x * 2.55 + t * 0.85) * sin(q.y * 2.30 - t * 0.70);
  float b = sin((q.x + q.y) * 1.85 - t * 1.05) * sin((q.x - q.y) * 2.05 + t * 0.80);
  float r = 1.0 - abs(a * 0.62 + b * 0.52);
  return pow(clamp(r, 0.0, 1.0), 10.0);
}

float causticsAt(vec3 wp, vec3 N){
  float d = -wp.y;
  float fade = 1.0 - smoothstep(8.0, 150.0, d);
  if (fade <= 0.001) return 0.0;
  float facing = clamp(N.y, 0.0, 1.0);
  float c = causticPattern(wp.xz * 0.62, uTime * 0.42);
  c += 0.55 * causticPattern(wp.xz * 0.26 + 7.3, uTime * 0.30);
  c += 0.30 * causticPattern(wp.xz * 1.15 - 3.1, uTime * 0.55);
  return min(c, 1.6) * fade * (0.25 + 0.75 * facing) * uCausticStrength;
}

// Sun + ambient lighting for a rock/sand surface.
vec3 litSurface(vec3 albedo, vec3 N, vec3 wp, float rough, float ao, float causticMul){
  vec3 sun = sunlightAt(wp.y);
  float ndl = clamp(dot(N, uSunDir), 0.0, 1.0);
  float wrap = clamp((dot(N, uSunDir) + 0.45) / 1.45, 0.0, 1.0);
  float caus = causticsAt(wp, N) * causticMul;
  vec3 amb = ambientLight(wp.y) * 1.05 * (0.38 + 0.62 * clamp(N.y * 0.5 + 0.5, 0.0, 1.0));
  vec3 direct = sun * (ndl * 0.92 + wrap * 0.18) * (1.0 + caus * 0.90);
  // extra skylight in the first few metres, where the sun is almost overhead
  float skylight = smoothstep(-30.0, 0.0, wp.y) * 0.09;
  // direct light is occluded hard by crevices, ambient softly
  vec3 col = albedo * (direct * (0.25 + 0.75 * ao) + amb + ambientLight(0.0) * skylight) * (0.32 + 0.68 * ao);

  // wet specular sheen
  vec3 V = normalize(uCamPos - wp);
  vec3 H = normalize(uSunDir + V);
  float a = max(rough * rough, 0.0016);
  float nh = max(dot(N, H), 0.0);
  float D = (a * a) / (3.14159 * pow(nh * nh * (a * a - 1.0) + 1.0, 2.0));
  float F = 0.02 + 0.98 * pow(1.0 - clamp(dot(V, H), 0.0, 1.0), 5.0);
  col += sun * D * F * 0.55 * clamp(dot(N, uSunDir) + 0.2, 0.0, 1.0);

  // forward-scattered rim light: every edge picks up a little of the water's glow
  float rim = pow(1.0 - clamp(dot(N, normalize(uCamPos - wp)), 0.0, 1.0), 3.2);
  col += albedo * ambientLight(wp.y) * rim * 1.25;
  return col;
}
`;

// ---------------------------------------------------------------------------
// Geological surface language — used by the seabed AND every rock mesh, so
// cliffs, arches, pillars and boulders share one continuous material identity.
// ---------------------------------------------------------------------------
export const GLSL_ROCK = /* glsl */`
// Returns albedo. Also writes a detail height used for normal perturbation.
vec3 rockAlbedo(vec3 wp, vec3 N, float detailScale, float detailFade, out float detailH){
  float depth = max(-wp.y, 0.0);

  float n1 = fbm3(wp * 0.016, 4);          // ~60 m geological bodies
  float n2 = fbm3(wp * 0.115, 3);          // ~9 m broken rock
  float n3 = fbm3(wp * 0.85, 2);           // ~1.2 m surface grain
  float rip = fbm3(vec3(wp.x * 0.35, wp.y * 0.9, wp.z * 0.35), 2);

  // stratification: tilted, noise-warped bedding planes
  float bandPhase = wp.y * 0.30 + n1 * 5.0 + wp.x * 0.0035 + wp.z * 0.0022;
  float band = sin(bandPhase);
  float strata = smoothstep(-0.25, 0.85, band);

  float kDeep = smoothstep(-30.0, -320.0, wp.y);   // 0 = shallow, 1 = abyssal
  float kMid  = smoothstep(-8.0, -90.0, wp.y);

  vec3 limestone = mix(vec3(0.475, 0.445, 0.390), vec3(0.360, 0.330, 0.275), n1);
  vec3 reefRock  = mix(vec3(0.395, 0.345, 0.290), vec3(0.280, 0.250, 0.215), n2);
  vec3 basalt    = mix(vec3(0.140, 0.140, 0.152), vec3(0.078, 0.080, 0.093), n2);
  vec3 rock = mix(limestone, reefRock, kMid * 0.75);
  rock = mix(rock, basalt, kDeep * 0.92);
  rock *= 0.80 + 0.40 * strata;

  // sediment: collects on anything facing up, in every zone
  vec3 sandWarm = vec3(0.430, 0.372, 0.258);
  vec3 siltDeep = vec3(0.135, 0.132, 0.138);
  vec3 sediment = mix(sandWarm, siltDeep, smoothstep(-14.0, -190.0, wp.y));
  sediment *= 0.88 + 0.24 * n3;
  float flatMask = smoothstep(0.42, 0.90, N.y);
  float sedimentMask = flatMask * (0.52 + 0.48 * smoothstep(0.30, 0.75, n2));
  vec3 col = mix(rock, sediment, sedimentMask);

  // sand ripples: two interfering trains, warped by the local bed.
  // detailFade kills them before they can alias into moiré at distance.
  vec2 rp = wp.xz;
  float ang = n1 * 6.2831;
  vec2 rd = vec2(cos(ang), sin(ang));
  float ripple = sin(dot(rp, rd) * 2.35 + n2 * 9.0);
  ripple += 0.55 * sin(dot(rp, vec2(rd.y, -rd.x)) * 4.1 + n3 * 6.0);
  float rippleMask = flatMask * (1.0 - kMid) * smoothstep(0.30, 0.62, n2) * detailFade;
  col *= 1.0 + 0.11 * ripple * rippleMask;
  col *= 1.0 + 0.075 * (n3 - 0.5) * flatMask * (0.4 + 0.6 * detailFade);

  // coral-algae crust hint in the photic zone on up-facing reef rock
  float crust = smoothstep(-34.0, -4.0, wp.y) * flatMask * smoothstep(0.35, 0.8, n2);
  col = mix(col, col * vec3(0.90, 0.97, 0.86), crust * 0.28);

  // mineral veins in the abyss — restrained
  float vein = pow(clamp(1.0 - abs(n3 * 2.0 - 1.0), 0.0, 1.0), 22.0);
  col += vec3(0.09, 0.11, 0.15) * vein * kDeep;

  // geological bodies: hundreds-of-metres scale *colour* provinces, so a cliff
  // is never one flat hue — warm sandstone against cool limestone
  float macro = fbm3(wp * 0.0055 + 11.0, 2);
  float macro2 = fbm3(wp * 0.042 - 3.0, 3);
  vec3 warmProv = vec3(1.22, 0.96, 0.74);
  vec3 coolProv = vec3(0.82, 0.96, 1.10);
  vec3 province = mix(coolProv, warmProv, smoothstep(0.35, 0.72, macro));
  col *= province * (0.55 + 0.82 * macro + 0.36 * macro2);
  // light mineral crusts on exposed bedding planes
  float crust2 = smoothstep(0.55, 0.95, macro2) * smoothstep(0.2, 0.8, strata);
  col = mix(col, col * 1.45 + vec3(0.045, 0.042, 0.038), crust2 * 0.35);

  // cavity darkening / fracture shading
  col *= 0.74 + 0.44 * (n3 * 0.6 + n2 * 0.4);

  detailH = (rip * 0.6 + n3 * 0.4) * detailScale;
  return col;
}

// Analytic ripple normals: real shading relief on the sand, faded with distance.
vec3 sandRippleNormal(vec3 wp, vec3 N, float fade){
  float flatMask = smoothstep(0.55, 0.92, N.y);
  if (flatMask * fade < 0.01) return N;
  // two bed directions chosen by very low-frequency variation, then strongly
  // domain-warped so the trains meander instead of spiralling
  float dirSel = fbm3(vec3(wp.xz * 0.0016, 0.0), 2);
  vec2 rd = normalize(vec2(0.82, 0.57) + dirSel * 1.4);
  vec2 q = wp.xz;
  float warp = fbm3(vec3(q * 0.09, 0.0), 3) - 0.5;
  float warp2 = fbm3(vec3(q * 0.34, 3.1), 2) - 0.5;
  float phase = dot(q, rd) * 2.6 + warp * 7.0 + warp2 * 1.6;
  vec2 grad = cos(phase) * 2.6 * rd * 0.045;
  vec3 n = normalize(vec3(-grad.x, 1.0, -grad.y));
  return normalize(mix(N, n, flatMask * fade * 0.9));
}

// Perturb a normal with the procedural detail gradient (no tangents needed).
vec3 perturbNormal(vec3 wp, vec3 N, float scale, float strength){
  float e = 0.35;
  float h0 = fbm3(wp * scale, 3);
  vec3 g = vec3(
    fbm3((wp + vec3(e,0.0,0.0)) * scale, 3) - h0,
    fbm3((wp + vec3(0.0,e,0.0)) * scale, 3) - h0,
    fbm3((wp + vec3(0.0,0.0,e)) * scale, 3) - h0) / e;
  g -= N * dot(g, N);
  return normalize(N - g * strength);
}
`;

// Convenience: concatenation used by most materials
export const GLSL_HEADER = GLSL_NOISE + GLSL_MEDIUM + GLSL_LIGHT + GLSL_ROCK;

/** Attach the shared uniforms to a material's uniform block. */
export function withShared(uniforms) {
  return Object.assign({}, shared, uniforms);
}

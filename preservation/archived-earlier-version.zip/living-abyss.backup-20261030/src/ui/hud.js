// -----------------------------------------------------------------------------
// THE LIVING ABYSS — HUD, bathymetric chart, compass, discovery
// The map is generated from the same height field the world is built from, so
// what you read on the chart is exactly what you swim through.
// -----------------------------------------------------------------------------
import { WORLD, REGIONS, LANDMARKS } from '../world/geography.js';

const el = (id) => document.getElementById(id);

let field = null;
let mapCanvas = null;       // offscreen bathymetry
let mini, miniCtx, big, bigCtx, compass, compassCtx;
let discovered = new Set();
let toastTimer = 0;
let lastRegion = null;
export const waypoint = { x: 0, z: 0, y: 0, active: false, name: '' };

const DEPTH_STOPS = [
  [0.00, [232, 226, 196]],
  [0.04, [188, 214, 168]],
  [0.10, [120, 206, 196]],
  [0.20, [58, 168, 190]],
  [0.34, [30, 112, 168]],
  [0.50, [16, 68, 132]],
  [0.68, [10, 38, 92]],
  [0.84, [6, 20, 56]],
  [1.00, [3, 9, 26]],
];

function depthColor(t) {
  for (let i = 0; i < DEPTH_STOPS.length - 1; i++) {
    const a = DEPTH_STOPS[i], b = DEPTH_STOPS[i + 1];
    if (t >= a[0] && t <= b[0]) {
      const u = (t - a[0]) / (b[0] - a[0]);
      return [a[1][0] + (b[1][0] - a[1][0]) * u,
              a[1][1] + (b[1][1] - a[1][1]) * u,
              a[1][2] + (b[1][2] - a[1][2]) * u];
    }
  }
  return DEPTH_STOPS[DEPTH_STOPS.length - 1][1];
}

/** Render the chart once: depth ramp + hillshade + contour bands. */
function buildBathymetry() {
  const w = field.vx, h = field.vz;
  const cv = document.createElement('canvas');
  cv.width = w; cv.height = h;
  const ctx = cv.getContext('2d');
  const img = ctx.createImageData(w, h);
  const H = field.heights;
  const cell = field.cell;
  const sun = [-0.55, 0.62, -0.56];
  for (let j = 0; j < h; j++) {
    for (let i = 0; i < w; i++) {
      const k = j * w + i;
      const y = H[k];
      const hl = H[k - 1] ?? y, hr = H[k + 1] ?? y;
      const hd = H[k - w] ?? y, hu = H[k + w] ?? y;
      const gx = (hl - hr) / (2 * cell), gz = (hd - hu) / (2 * cell);
      const nl = Math.hypot(gx, gz, 1);
      const shade = Math.max(0, (gx * sun[0] + sun[1] + gz * sun[2]) / nl);
      const t = Math.min(1, Math.max(0, -y / 1150));
      let c = depthColor(t);
      const sh = 0.42 + 0.86 * Math.pow(shade, 1.15);
      // gentle contour banding every 50 m
      const band = ((y % 50) + 50) % 50;
      const contour = band < 1.6 ? 0.72 : 1.0;
      const o = k * 4;
      img.data[o] = Math.min(255, c[0] * sh * contour);
      img.data[o + 1] = Math.min(255, c[1] * sh * contour);
      img.data[o + 2] = Math.min(255, c[2] * sh * contour);
      img.data[o + 3] = 255;
    }
  }
  ctx.putImageData(img, 0, 0);
  return cv;
}

const toMapX = (x, cw) => ((x - WORLD.minX) / (WORLD.maxX - WORLD.minX)) * cw;
const toMapY = (z, ch) => ((z - WORLD.minZ) / (WORLD.maxZ - WORLD.minZ)) * ch;

function drawLandmarks(ctx, cw, ch, scale) {
  ctx.save();
  for (const lm of LANDMARKS) {
    const x = toMapX(lm.x, cw), y = toMapY(lm.z, ch);
    ctx.beginPath();
    ctx.arc(x, y, 2.2 * scale, 0, Math.PI * 2);
    ctx.fillStyle = 'rgba(180,255,240,0.9)';
    ctx.fill();
    if (scale > 1.5) {
      ctx.font = `${9 * scale}px Inter, sans-serif`;
      ctx.fillStyle = 'rgba(200,250,255,0.72)';
      ctx.fillText(lm.name, x + 5 * scale, y + 3 * scale);
    }
  }
  ctx.restore();
}

function drawPlayer(ctx, cw, ch, pos, yaw, scale) {
  const x = toMapX(pos.x, cw), y = toMapY(pos.z, ch);
  ctx.save();
  ctx.translate(x, y);
  // view cone
  ctx.beginPath();
  ctx.moveTo(0, 0);
  // map north (-z) is up; heading yaw 0 looks north
  for (let a = -0.45; a <= 0.45; a += 0.09) {
    const ang = yaw + a;
    ctx.lineTo(-Math.sin(ang) * 22 * scale, -Math.cos(ang) * 22 * scale);
  }
  ctx.closePath();
  ctx.fillStyle = 'rgba(150,255,235,0.16)';
  ctx.fill();
  ctx.beginPath();
  ctx.arc(0, 0, 3.2 * scale, 0, Math.PI * 2);
  ctx.fillStyle = '#eafcff';
  ctx.shadowColor = '#7ff3e4';
  ctx.shadowBlur = 8 * scale;
  ctx.fill();
  ctx.restore();
}

export function initHUD(terrainField) {
  field = terrainField;
  mapCanvas = buildBathymetry();
  mini = el('mapCv'); miniCtx = mini.getContext('2d');
  big = el('bigmapCv'); bigCtx = big.getContext('2d');
  compass = el('compassCv'); compassCtx = compass.getContext('2d');

  // region legend
  const leg = el('bigmapLeg');
  leg.innerHTML = REGIONS.map(r =>
    `<span><i style="background:${r.tone}"></i>${r.name}</span>`).join('');

  // clicking the chart sets a waypoint (it never teleports the player)
  big.addEventListener('click', (e) => {
    const r = big.getBoundingClientRect();
    const x = WORLD.minX + ((e.clientX - r.left) / r.width) * (WORLD.maxX - WORLD.minX);
    const z = WORLD.minZ + ((e.clientY - r.top) / r.height) * (WORLD.maxZ - WORLD.minZ);
    waypoint.x = x; waypoint.z = z; waypoint.active = true;
    waypoint.name = 'Waypoint';
    waypoint.y = field.heightAt(x, z);
    showToast('Waypoint set', `${Math.round(x)} · ${Math.round(z)}`);
  });
}

export function toggleBigMap(force) {
  const node = el('bigmap');
  const on = force !== undefined ? force : !node.classList.contains('on');
  node.classList.toggle('on', on);
  if (on) drawBigMap();
  return on;
}

export function bigMapOpen() {
  return el('bigmap').classList.contains('on');
}

function drawBigMap(state) {
  if (!bigCtx) return;
  const cw = big.width, ch = big.height;
  bigCtx.clearRect(0, 0, cw, ch);
  bigCtx.imageSmoothingEnabled = true;
  bigCtx.drawImage(mapCanvas, 0, 0, cw, ch);
  // region rings
  bigCtx.save();
  for (const r of REGIONS) {
    const x = toMapX(r.anchor[0], cw), y = toMapY(r.anchor[1], ch);
    bigCtx.beginPath();
    bigCtx.arc(x, y, (r.radius / (WORLD.maxX - WORLD.minX)) * cw, 0, Math.PI * 2);
    bigCtx.strokeStyle = r.tone + '55';
    bigCtx.lineWidth = 1.2;
    bigCtx.setLineDash([5, 7]);
    bigCtx.stroke();
    bigCtx.setLineDash([]);
    bigCtx.font = '11px Inter, sans-serif';
    bigCtx.fillStyle = r.tone + 'dd';
    bigCtx.fillText(r.short.toUpperCase(), x - 26, y - (r.radius / (WORLD.maxX - WORLD.minX)) * cw - 6);
  }
  bigCtx.restore();
  drawLandmarks(bigCtx, cw, ch, 2.4);
  if (state) {
    drawPlayer(bigCtx, cw, ch, state.pos, state.yaw, 2.4);
    if (waypoint.active) {
      bigCtx.beginPath();
      bigCtx.arc(toMapX(waypoint.x, cw), toMapY(waypoint.z, ch), 6, 0, Math.PI * 2);
      bigCtx.strokeStyle = '#9ffce8'; bigCtx.lineWidth = 2; bigCtx.stroke();
    }
  }
}

function drawCompass(state) {
  if (!compassCtx) return;
  const cw = compass.width, ch = compass.height;
  compassCtx.clearRect(0, 0, cw, ch);
  const heading = (-state.yaw * 180 / Math.PI + 360) % 360;
  compassCtx.save();
  compassCtx.translate(cw / 2, ch / 2);
  compassCtx.font = '600 11px Inter, sans-serif';
  compassCtx.textAlign = 'center';
  const span = 100;
  for (let d = -span; d <= span; d += 5) {
    const deg = heading + d;
    const x = (d / span) * (cw / 2 - 6);
    const norm = ((deg % 360) + 360) % 360;
    const fade = 1 - Math.abs(d) / span;
    const cardinal = { 0: 'N', 45: 'NE', 90: 'E', 135: 'SE', 180: 'S', 225: 'SW', 270: 'W', 315: 'NW' };
    const card = cardinal[Math.round(norm / 45) * 45 % 360];
    if (card && Math.abs(norm - Math.round(norm / 45) * 45) < 2.5) {
      compassCtx.fillStyle = `rgba(220,252,255,${0.35 + 0.65 * fade})`;
      compassCtx.fillText(card, x, 4);
    } else if (Math.abs(norm % 15) < 1.4) {
      compassCtx.fillStyle = `rgba(150,215,230,${0.12 + 0.4 * fade})`;
      compassCtx.fillRect(x, -4, 1, 8);
    }
  }
  compassCtx.restore();
  // centre marker
  compassCtx.fillStyle = 'rgba(234,252,255,0.95)';
  compassCtx.beginPath();
  compassCtx.moveTo(cw / 2, 3); compassCtx.lineTo(cw / 2 - 4, -5); compassCtx.lineTo(cw / 2 + 4, -5);
  compassCtx.closePath();
  compassCtx.fill();
}

export function showToast(t1, t2, ms = 2600) {
  const t = el('toast');
  t.querySelector('.t1').textContent = t1;
  t.querySelector('.t2').textContent = t2 || '';
  t.classList.add('on');
  toastTimer = ms;
}

export function updateHUD(state, dt) {
  const region = field.regionAt(state.pos.x, state.pos.y, state.pos.z);
  el('regionName').textContent = region.name;
  el('regionBlurb').textContent = region.blurb;

  if (!discovered.has(region.id)) {
    discovered.add(region.id);
    if (lastRegion && discovered.size > 1) {
      showToast('Region discovered', region.name);
    }
    lastRegion = region.id;
  }

  const depth = Math.max(0, -state.pos.y);
  el('depth').textContent = Math.round(depth).toLocaleString();
  el('depthMark').style.left = `${Math.min(100, (depth / 1150) * 100)}%`;
  el('posReadout').textContent = `X ${Math.round(state.pos.x)} · Z ${Math.round(state.pos.z)}`;

  // minimap
  if (miniCtx) {
    const cw = mini.width, ch = mini.height;
    miniCtx.clearRect(0, 0, cw, ch);
    miniCtx.drawImage(mapCanvas, 0, 0, cw, ch);
    drawLandmarks(miniCtx, cw, ch, 1.0);
    drawPlayer(miniCtx, cw, ch, state.pos, state.yaw, 1.6);
    if (waypoint.active) {
      miniCtx.beginPath();
      miniCtx.arc(toMapX(waypoint.x, cw), toMapY(waypoint.z, ch), 4, 0, Math.PI * 2);
      miniCtx.strokeStyle = '#9ffce8'; miniCtx.lineWidth = 1.6; miniCtx.stroke();
    }
  }
  drawCompass(state);

  if (toastTimer > 0) {
    toastTimer -= dt * 1000;
    if (toastTimer <= 0) el('toast').classList.remove('on');
  }

  // waypoint guidance
  const wpEl = el('waypoint');
  if (waypoint.active) {
    const dx = waypoint.x - state.pos.x, dz = waypoint.z - state.pos.z;
    const dist = Math.hypot(dx, dz);
    const bearing = (Math.atan2(dx, -dz) * 180 / Math.PI + 360) % 360;
    const heading = (-state.yaw * 180 / Math.PI + 360) % 360;
    let rel = ((bearing - heading + 540) % 360) - 180;
    const arrow = rel > 12 ? '▸' : rel < -12 ? '◂' : '▴';
    wpEl.textContent = `${arrow} WAYPOINT ${Math.round(dist)} m · ${Math.round(bearing)}°`;
    wpEl.style.opacity = 0.9;
  } else {
    wpEl.style.opacity = 0;
  }
  if (bigMapOpen()) drawBigMap(state);
}

export function setPerf(text) {
  const p = el('perf');
  if (p) p.innerHTML = text;
}

export function hideHUD(force) {
  const hud = el('hud');
  const on = force !== undefined ? !force : hud.style.display !== 'none';
  hud.style.display = on ? 'none' : '';
}

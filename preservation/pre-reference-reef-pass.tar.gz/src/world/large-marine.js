// A small number of non-solid, animated marine visitors. These are bounded
// patrols, not a general-purpose animal AI or a certified navigation system.
// Source / attribution and the modified-asset chain: assets/ASSET_MANIFEST.md.
import * as THREE from '../../vendor/three.module.js';
import { GLTFLoader } from '../../vendor/jsm/loaders/GLTFLoader.js';
import { clone } from '../../vendor/jsm/utils/SkeletonUtils.js';
import { GLSL_MEDIUM, GLSL_LIGHT, withShared } from '../shaders/common.js?rev=09';
import { planMarinePatrols } from './marine-patrols.js?rev=09';

export const MARINE_VS = `
#include <common>
#include <skinning_pars_vertex>
varying vec3 vWorld; varying vec3 vNormal; varying vec2 vUv;
void main(){
 vUv=uv;
 vec3 transformed=vec3(position);
 vec3 objectNormal=vec3(normal);
 #include <skinbase_vertex>
 #include <skinnormal_vertex>
 #include <skinning_vertex>
 vec4 wp=modelMatrix*vec4(transformed,1.0);
 vWorld=wp.xyz; vNormal=normalize(mat3(modelMatrix)*objectNormal);
 gl_Position=projectionMatrix*viewMatrix*wp;
}`;
export const MARINE_FS = GLSL_MEDIUM + GLSL_LIGHT + `
uniform sampler2D uMap; uniform vec3 uBase; uniform float uMapped;
varying vec3 vWorld; varying vec3 vNormal; varying vec2 vUv;
void main(){
 vec3 n=normalize(vNormal); if(!gl_FrontFacing)n=-n;
 vec3 albedo=uBase * mix(vec3(1.0),texture2D(uMap,vUv).rgb,uMapped);
 vec3 color=litSurface(albedo,n,vWorld,0.68,0.88,0.25)+albedo*vec3(.18,.23,.24);
 gl_FragColor=vec4(applyWater(color,vWorld),1.0);
}`;

const defs={manta:{yaw:Math.PI/2},shark:{yaw:Math.PI}}; // source nose to +X

export async function addLargeMarine(scene,field,colliders){
 const loader=new GLTFLoader();
 const names=['manta','shark'];
 const loaded=await Promise.allSettled(names.map(n=>loader.loadAsync(`./assets/models/large_marine/${n}.glb`)));
 const assets={};
 loaded.forEach((result,i)=>{
  if(result.status==='fulfilled')assets[names[i]]=result.value;
  else console.warn('Marine asset unavailable: '+names[i],result.reason);
 });
 const group=new THREE.Group(), animals=[];
 group.name='large_marine_visitors';
 const white=new THREE.DataTexture(new Uint8Array([255,255,255,255]),1,1);
 white.needsUpdate=true;
 const materials=new Map();
 for(const route of planMarinePatrols(field,colliders)){
  const asset=assets[route.kind];
  if(!asset || !asset.animations.length)continue;
  const model=clone(asset.scene);
  const orient=new THREE.Group();orient.rotation.y=defs[route.kind].yaw;orient.add(model);
  const mixer=new THREE.AnimationMixer(model),clip=asset.animations[0];
  mixer.clipAction(clip).play();mixer.update(0);
  orient.updateMatrixWorld(true);
  const box=new THREE.Box3().setFromObject(orient), size=box.getSize(new THREE.Vector3()), center=box.getCenter(new THREE.Vector3());
  if(!Number.isFinite(size.x)||size.x<.001)throw new Error('Invalid marine model bounds: '+route.kind);
  // The source's rest pose has a large root offset in the shark. Normalize the
  // actual skinned bounding box after orienting, then keep bones in that frame.
  orient.position.copy(center).multiplyScalar(-1);
  const rig=new THREE.Group();rig.add(orient);rig.scale.setScalar(route.size/size.x);
  const host=new THREE.Group();host.name=route.kind+'_visitor';host.add(rig);
  model.traverse(o=>{
   if(!o.isSkinnedMesh)return;
   const original=o.material;
   if(!materials.has(original)){
    materials.set(original,new THREE.ShaderMaterial({
     uniforms:withShared({uMap:{value:original.map||white},uBase:{value:original.color?.clone()||new THREE.Color(1,1,1)},uMapped:{value:original.map?1:0}}),
     vertexShader:MARINE_VS,fragmentShader:MARINE_FS,side:THREE.DoubleSide,
    }));
   }
   o.material=materials.get(original);
   // Some source bind-pose bounds do not cover the animation. Explicit
   // distance culling below is safer than a bad per-mesh frustum sphere.
   o.frustumCulled=false;
  });
  mixer.setTime(route.phase/Math.PI*clip.duration);
  group.add(host);animals.push({...route,host,mixer});
 }
 scene.add(group);
 function update(dt,cameraPosition){
  for(const a of animals){
   const dx=cameraPosition.x-a.host.position.x,dy=cameraPosition.y-a.host.position.y,dz=cameraPosition.z-a.host.position.z;
   const dist2=dx*dx+dy*dy+dz*dz;
   // When a swimmer comes close, the animal reduces speed rather than clipping
   // through them on a fixed timer. No collision or combat is introduced.
   const speedFactor=dist2<49?.28:1;
   a.phase+=Math.min(dt,.1)*a.speed*speedFactor;
   const t=a.phase;
   a.host.position.set(a.x+Math.cos(t)*a.radius,a.y,a.z+Math.sin(t)*a.radius);
   // Source points +X; derivative of the circular path gives its heading.
   a.host.rotation.y=Math.atan2(-Math.cos(t),-Math.sin(t));
   a.host.visible=dist2<180*180;
   if(a.host.visible)a.mixer.update(dt*speedFactor);
  }
 }
 // Initialize hosts before the first camera-distance calculation.
 for(const a of animals)a.host.position.set(a.x+Math.cos(a.phase)*a.radius,a.y,a.z+Math.sin(a.phase)*a.radius);
 return {group,animals,update};
}

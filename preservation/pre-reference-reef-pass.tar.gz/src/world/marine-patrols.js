import { mulberry32 } from '../core/noise.js?rev=09';
import { LOCATIONS } from './geography.js?rev=09';

const SPECS = [
 {kind:'manta',place:'glasshorizon',offset:[-20,-130],size:4.1},
 {kind:'manta',place:'roseglass',offset:[55,30],size:4.1},
 {kind:'manta',place:'verdant',offset:[0,0],size:4.1},
 {kind:'shark',place:'glasshorizon',offset:[70,-60],size:3.1},
 {kind:'shark',place:'roseglass',offset:[-45,-45],size:3.1},
 {kind:'shark',place:'aurel',offset:[40,55],size:3.1},
];

// For each route sample the complete circular path and reject proximity to
// approximate large visual bounds. Small rocks and the curved space between
// samples are NOT certified; tests expose precisely what is being checked.
export function planMarinePatrols(field,colliders){
 const random=mulberry32(523472), routes=[];
 for(const spec of SPECS){
  const loc=LOCATIONS.find(l=>l.id===spec.place);
  for(let attempt=0;attempt<500;attempt++){
   const a=random()*Math.PI*2,r=Math.sqrt(random())*85;
   const x=loc.x+spec.offset[0]+Math.cos(a)*r;
   const z=loc.z+spec.offset[1]+Math.sin(a)*r;
   const radius=6+random()*3;
   let highest=-Infinity,lowest=Infinity;
   for(let k=0;k<24;k++){
    const angle=k*Math.PI/12;
    const floor=field.surfaceHeightAt(x+Math.cos(angle)*radius,z+Math.sin(angle)*radius);
    highest=Math.max(highest,floor);lowest=Math.min(lowest,floor);
   }
   // Only coastal and upper-slope water, with space above and below.
   const y=highest+5;
   if(lowest < -100 || highest > -10 || y > -5 || y < -80)continue;
   let safe=true;
   for(let k=0;k<24&&safe;k++){
    const angle=k*Math.PI/12,px=x+Math.cos(angle)*radius,pz=z+Math.sin(angle)*radius;
    if(colliders.some(c=>{const b=c.visualBounds,m=3.5;return b&&px>b.min[0]-m&&px<b.max[0]+m&&y>b.min[1]-m&&y<b.max[1]+m&&pz>b.min[2]-m&&pz<b.max[2]+m;}))safe=false;
   }
   if(!safe || routes.some(q=>Math.hypot(q.x-x,q.z-z)<30))continue;
   routes.push({...spec,x,y,z,radius,phase:random()*Math.PI*2,speed:(spec.kind==='manta'?.10:.15)+random()*.025});
   break;
  }
 }
 return routes;
}


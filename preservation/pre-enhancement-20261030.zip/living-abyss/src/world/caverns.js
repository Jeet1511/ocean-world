// -----------------------------------------------------------------------------
// THE LIVING ABYSS — the Veiled Caverns
// Each hall is a sunken chamber in the seabed roofed by a real rock vault whose
// rim merges into the surrounding ground, with a cut gate so the hall is always
// enterable. Interiors are baked dark, with light bleeding in from the gate.
// -----------------------------------------------------------------------------
import * as THREE from '../../vendor/three.module.js';
import { CHAMBERS } from './geography.js';
import { mulberry32, fbm3, fbm2, noise3, clamp, lerp, smoothstep } from '../core/noise.js';
import { createRockMaterial } from './rockmat.js';

const TAU = Math.PI * 2;

/**
 * A rock vault: a thick, noise-eroded shell arched over a chamber bowl.
 * The outer rim is sampled from the actual terrain so it always meets the
 * ground; one azimuth sector is left open as the gate.
 */
function makeVault(field, chamber, rng, opts) {
  const { x, z, r } = chamber;
  const rimR = r * (opts.rimScale || 1.35);
  const gate = chamber.gateAngle;
  const gateHalf = opts.gateHalf || 0.55;      // radians of open sector
  const squash = opts.squash || 0.55;

  const rings = 22, segs = 64;
  const a0 = gate + gateHalf;
  const a1 = gate + TAU - gateHalf;

  // rim elevation sampled from the terrain all the way round
  const rimY = [];
  for (let j = 0; j <= segs; j++) {
    const a = lerp(a0, a1, j / segs);
    const rx = x + Math.cos(a) * rimR;
    const rz = z + Math.sin(a) * rimR;
    rimY.push(field.heightAt(rx, rz));
  }
  const peak = Math.max(...rimY) + r * squash;

  const top = [], bot = [], idxT = [], idxB = [];
  const aoT = [], aoB = [];
  const seed = rng() * 100;

  const surfY = (i, j, a, radiusFrac) => {
    // blend terrain rim -> arch peak, with noise erosion
    const t = radiusFrac;                        // 0 centre, 1 rim
    const arch = Math.pow(1 - t * t, 0.75);
    const base = lerp(peak, rimY[j], Math.pow(t, 0.85));
    const n = fbm3(
      x + Math.cos(a) * rimR * t, (base - y0) * 0.03, z + Math.sin(a) * rimR * t, 3) * r * 0.10;
    return base + arch * r * 0.06 + n;
  };
  const y0 = Math.min(...rimY);

  for (let i = 0; i <= rings; i++) {
    const t = i / rings;
    const rad = t * rimR;
    for (let j = 0; j <= segs; j++) {
      const a = lerp(a0, a1, j / segs);
      const px = x + Math.cos(a) * rad;
      const pz = z + Math.sin(a) * rad;
      const yTop = surfY(i, j, a, t);
      // thickness: thick over the middle of the hall, thin at the ground rim
      const thick = (opts.thickness || 26) * (0.15 + 0.95 * Math.pow(t, 0.6)) * (1 - Math.pow(t, 6));
      const yBot = yTop - thick;
      top.push(px, yTop, pz);
      bot.push(px, yBot, pz);
      // interior occlusion: dark, brighter near the gate
      const gateDist = Math.min(
        Math.abs(((a - a0) + TAU) % TAU), Math.abs(((a - a1) + TAU) % TAU));
      const lit = smoothstep(0.9, 0.05, gateDist) * (0.35 + 0.65 * t);
      aoB.push(clamp(0.10 + 0.55 * lit, 0.08, 0.8));
      aoT.push(clamp(0.55 + 0.45 * (1 - t), 0.3, 1));
    }
  }
  const stride = segs + 1;
  const n = top.length / 3;
  for (let i = 0; i < rings; i++) {
    for (let j = 0; j < segs; j++) {
      const a = i * stride + j, b = a + 1, c = a + stride, d = c + 1;
      idxT.push(a, b, c, b, d, c);          // top faces up
      idxB.push(a + n, c + n, b + n, b + n, c + n, d + n); // bottom faces down
    }
  }
  // stitch the two cut edges (the gate walls) and the ground rim
  for (let i = 0; i < rings; i++) {
    const a = i * stride, c = a + stride;
    idxT.push(a, a + n, c, c, a + n, c + n);
    const b = i * stride + segs, d = b + stride;
    idxT.push(b, d, b + n, b + n, d, d + n);
  }
  for (let j = 0; j < segs; j++) {
    const a = rings * stride + j, b = a + 1;
    idxT.push(a, b, a + n, b, b + n, a + n);
  }

  const pos = top.concat(bot);
  const ao = aoT.concat(aoB);
  const geo = new THREE.BufferGeometry();
  geo.setAttribute('position', new THREE.Float32BufferAttribute(pos, 3));
  geo.setAttribute('aAO', new THREE.Float32BufferAttribute(ao, 1));
  geo.setIndex(idxT.concat(idxB));
  geo.computeVertexNormals();
  return geo;
}

/** Stalactite / stalagmite: a noise-displaced cone, never a primitive. */
function makeSpike(rng, height, radius, down) {
  const rings = 12, radial = 12;
  const seed = rng() * 60;
  const pos = [], idx = [], ao = [];
  for (let i = 0; i <= rings; i++) {
    const t = i / rings;
    const y = down ? -t * height : t * height;
    const rad = radius * Math.pow(1 - t, 0.55) + 0.03;
    for (let j = 0; j <= radial; j++) {
      const a = (j / radial) * TAU;
      const n = fbm3(Math.cos(a) * rad * 2 + seed, y * 0.3, Math.sin(a) * rad * 2, 3);
      const rr = rad * (1 + n * 0.45);
      pos.push(Math.cos(a) * rr, y, Math.sin(a) * rr);
      ao.push(clamp(0.18 + 0.6 * t, 0.12, 0.9));
    }
  }
  for (let i = 0; i < rings; i++) {
    for (let j = 0; j < radial; j++) {
      const a = i * (radial + 1) + j, b = a + 1, c = a + radial + 1, d = c + 1;
      if (down) idx.push(a, b, c, b, d, c);
      else idx.push(a, c, b, b, c, d);
    }
  }
  const geo = new THREE.BufferGeometry();
  geo.setAttribute('position', new THREE.Float32BufferAttribute(pos, 3));
  geo.setAttribute('aAO', new THREE.Float32BufferAttribute(ao, 1));
  geo.setIndex(idx);
  geo.computeVertexNormals();
  return geo;
}

export function buildCaverns(field, controller) {
  const group = new THREE.Group();
  group.name = 'caverns';
  const rng = mulberry32(555777);
  const exteriorMat = createRockMaterial({ detail: 1.0, caveLit: 1.0 });
  const interiorMat = createRockMaterial({ detail: 1.0, caveLit: 0.0, darken: 0.92 });

  for (const ch of CHAMBERS) {
    const rimR = ch.r * 1.35;
    const geo = makeVault(field, ch, rng, {
      rimScale: 1.35,
      gateHalf: 0.5,
      squash: 0.42,
      thickness: 22 + ch.r * 0.10,
    });
    const vault = new THREE.Mesh(geo, exteriorMat);
    vault.name = 'vault_' + ch.name;
    group.add(vault);

    // interior formations: stalactites from the roof, stalagmites from the floor
    const spikes = [];
    const nSpikes = 12 + Math.floor(rng() * 10);
    for (let i = 0; i < nSpikes; i++) {
      const a = rng() * TAU;
      const rad = rng() * ch.r * 0.75;
      const px = ch.x + Math.cos(a) * rad;
      const pz = ch.z + Math.sin(a) * rad;
      const down = rng() > 0.45;
      const h = 6 + rng() * (ch.r * 0.28);
      const rr = 1.6 + rng() * 4.5;
      const g = makeSpike(rng, h, rr, down);
      const floorY = field.heightAt(px, pz);
      const ceilY = floorY + ch.roofFrom + (ch.depth - ch.roofFrom) * 0.55;
      g.translate(px, down ? ceilY : floorY - 0.2, pz);
      spikes.push(g);
    }
    // merge the spikes into one mesh
    if (spikes.length) {
      const merged = mergeSpikeGeos(spikes);
      const m = new THREE.Mesh(merged, interiorMat);
      m.name = 'formations_' + ch.name;
      group.add(m);
    }

    // ceiling clamps for the swim controller (concentric bands + gate relief)
    if (controller) {
      const floorY = field.heightAt(ch.x, ch.z);
      const peak = floorY + ch.roofFrom + 30;
      controller.ceilings.push({
        x: ch.x, z: ch.z, r: ch.r * 0.45, y: floorY + ch.roofFrom + 34,
        yFloor: floorY - 4, gate: ch.gateAngle, gateHalf: 0.5,
      });
      controller.ceilings.push({
        x: ch.x, z: ch.z, r: ch.r * 0.85, y: floorY + ch.roofFrom + 12,
        yFloor: floorY - 4, gate: ch.gateAngle, gateHalf: 0.5,
      });
      controller.ceilings.push({
        x: ch.x, z: ch.z, r: rimR * 1.05, y: floorY + ch.roofFrom - 4,
        yFloor: floorY - 4, gate: ch.gateAngle, gateHalf: 0.55,
      });
    }
  }
  return group;
}

function mergeSpikeGeos(geos) {
  let vc = 0, ic = 0;
  for (const g of geos) { vc += g.attributes.position.count; ic += g.index.count; }
  const pos = new Float32Array(vc * 3), nrm = new Float32Array(vc * 3), ao = new Float32Array(vc);
  const idx = new Uint32Array(ic);
  let vo = 0, io = 0;
  for (const g of geos) {
    pos.set(g.attributes.position.array, vo * 3);
    nrm.set(g.attributes.normal.array, vo * 3);
    ao.set(g.attributes.aAO.array, vo);
    for (let i = 0; i < g.index.count; i++) idx[io + i] = g.index.getX(i) + vo;
    io += g.index.count; vo += g.attributes.position.count;
  }
  const geo = new THREE.BufferGeometry();
  geo.setAttribute('position', new THREE.BufferAttribute(pos, 3));
  geo.setAttribute('normal', new THREE.BufferAttribute(nrm, 3));
  geo.setAttribute('aAO', new THREE.BufferAttribute(ao, 1));
  geo.setIndex(new THREE.BufferAttribute(idx, 1));
  geo.computeBoundingSphere();
  return geo;
}

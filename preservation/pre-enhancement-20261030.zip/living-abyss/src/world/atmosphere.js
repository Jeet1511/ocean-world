// -----------------------------------------------------------------------------
// THE LIVING ABYSS — atmosphere & marine life
// Suspended particles, volumetric sun shafts in the photic zone and through
// cavern gates, and small schools of fish that orbit their home ground.
// -----------------------------------------------------------------------------
import * as THREE from '../../vendor/three.module.js';
import { GLSL_NOISE, GLSL_MEDIUM, GLSL_LIGHT, withShared } from '../shaders/common.js';
import { mulberry32, fbm2, clamp } from '../core/noise.js';
import { WORLD, CHAMBERS, LOCATIONS } from './geography.js';

// ---------------------------------------------------------------------------
// Marine snow / suspended sediment
// ---------------------------------------------------------------------------
const SNOW_VS = /* glsl */`
uniform float uTime;
uniform vec3 uCamPos;
uniform float uBox;
uniform float uPixelScale;
attribute float aSize;
attribute float aPhase;
varying float vFade;
varying float vDepth;
varying vec3 vWorld;

void main(){
  vec3 p = position;
  // drift + slow settle, wrapped in a box that follows the camera
  p.x += sin(uTime * 0.21 + aPhase) * 2.4;
  p.y += sin(uTime * 0.14 + aPhase * 1.7) * 1.6 - mod(uTime * 0.22 + aPhase * 3.0, uBox);
  p.z += cos(uTime * 0.19 + aPhase * 1.3) * 2.4;

  vec3 rel = p - uCamPos;
  rel.x = mod(rel.x + uBox * 0.5, uBox) - uBox * 0.5;
  rel.y = mod(rel.y + uBox * 0.5, uBox) - uBox * 0.5;
  rel.z = mod(rel.z + uBox * 0.5, uBox) - uBox * 0.5;
  vec3 wp = uCamPos + rel;
  vWorld = wp;
  vDepth = -wp.y;

  vec4 mv = viewMatrix * vec4(wp, 1.0);
  float dist = length(mv.xyz);
  vFade = smoothstep(uBox * 0.5, uBox * 0.12, dist);
  gl_Position = projectionMatrix * mv;
  // aSize is a real diameter in metres
  gl_PointSize = clamp(aSize * uPixelScale / max(dist, 1.0), 0.8, 9.0);
}
`;

const SNOW_FS = /* glsl */`
uniform float uTime;
uniform vec3 uCamPos;
varying float vFade;
varying float vDepth;
varying vec3 vWorld;

void main(){
  vec2 c = gl_PointCoord - 0.5;
  float d = length(c);
  if (d > 0.5) discard;
  float soft = smoothstep(0.5, 0.05, d);

  // particles catch the little light there is; they thin out with depth
  float dens = mix(0.55, 0.16, smoothstep(0.0, 900.0, vDepth));
  vec3 tint = mix(vec3(0.75, 0.95, 1.0), vec3(0.55, 0.75, 1.0), smoothstep(0.0, 600.0, vDepth));
  float lum = (0.25 + 0.75 * (1.0 - smoothstep(0.0, 700.0, vDepth)));
  vec3 col = tint * lum;
  float a = soft * vFade * dens;
  gl_FragColor = vec4(col, a);
}
`;

// ---------------------------------------------------------------------------
// Volumetric sun shafts
// ---------------------------------------------------------------------------
const SHAFT_VS = /* glsl */`
varying vec3 vWorld;
varying vec3 vLocal;
void main(){
  vec4 wp = modelMatrix * vec4(position, 1.0);
  vWorld = wp.xyz;
  vLocal = position;
  gl_Position = projectionMatrix * viewMatrix * wp;
}
`;

const SHAFT_FS = GLSL_NOISE + /* glsl */`
uniform float uTime;
uniform vec3 uCamPos;
uniform vec3 uSunDir;
uniform float uIntensity;
varying vec3 vWorld;
varying vec3 vLocal;

void main(){
  // local y = 0 at the surface, -1 at the bottom of the shaft
  float h = clamp(-vLocal.y, 0.0, 1.0);
  float radial = 1.0 - clamp(length(vLocal.xz) * 2.0, 0.0, 1.0);
  float fade = pow(radial, 1.7) * pow(1.0 - h, 1.35) * smoothstep(0.0, 0.12, h);
  // break the cone into beams with drifting noise
  float n = fbm2(vec2(atan(vLocal.z, vLocal.x) * 1.6 + uTime * 0.05, h * 3.0 - uTime * 0.11), 4);
  fade *= 0.35 + 0.95 * smoothstep(0.25, 0.85, n);
  // never draw over the camera
  float dist = length(vWorld - uCamPos);
  fade *= smoothstep(3.0, 26.0, dist);
  vec3 col = vec3(0.72, 0.92, 1.0) * fade * uIntensity;
  gl_FragColor = vec4(col, 1.0);
}
`;

// ---------------------------------------------------------------------------
// Fish
// ---------------------------------------------------------------------------
const FISH_VS = /* glsl */`
uniform float uTime;
uniform vec3 uCenter;
attribute vec3 aOffset;
attribute float aPhase;
attribute float aRadius;
attribute float aSpeed;
attribute float aScale;
varying vec3 vWorld;
varying vec3 vNrm;
varying float vFade;

void main(){
  float ang = uTime * aSpeed + aPhase;
  vec3 c = uCenter;
  vec3 p = c + vec3(cos(ang) * aRadius + aOffset.x,
                    aOffset.y + sin(uTime * 0.9 + aPhase) * 0.7,
                    sin(ang) * aRadius + aOffset.z);
  vec3 fwd = normalize(vec3(-sin(ang), 0.0, cos(ang)) * aRadius * aSpeed);
  vec3 right = normalize(cross(vec3(0.0, 1.0, 0.0), fwd));
  vec3 up = cross(fwd, right);
  mat3 basis = mat3(fwd, up, right);

  vec3 lp = position * aScale;
  // tail beat
  float tail = clamp(-lp.x * 2.2, 0.0, 1.0);
  lp.z += sin(uTime * 9.0 + aPhase - lp.x * 5.0) * 0.16 * tail * aScale;

  vec3 wp = p + basis * lp;
  vWorld = wp;
  vNrm = normalize(basis * normal);
  float dist = length(wp - cameraPosition);
  vFade = smoothstep(170.0, 20.0, dist);
  gl_Position = projectionMatrix * viewMatrix * vec4(wp, 1.0);
}
`;

const FISH_FS = GLSL_MEDIUM + /* glsl */`
uniform vec3 uBodyCol;
uniform vec3 uBellyCol;
varying vec3 vWorld;
varying vec3 vNrm;
varying float vFade;

void main(){
  vec3 N = normalize(vNrm);
  if (!gl_FrontFacing) N = -N;
  float belly = smoothstep(0.1, -0.7, N.y);
  vec3 albedo = mix(uBodyCol, uBellyCol, belly);
  float fres = pow(1.0 - abs(dot(N, normalize(uCamPos - vWorld))), 2.5);
  vec3 sun = sunlightAt(vWorld.y);
  vec3 col = albedo * (sun * (clamp(dot(N, uSunDir), 0.0, 1.0) * 0.9 + 0.15)
                     + ambientLight(vWorld.y) * 0.8);
  col += vec3(0.55, 0.75, 0.85) * fres * 0.35;
  col = applyWater(col, vWorld);
  gl_FragColor = vec4(col, 1.0);
}
`;

function makeFishGeo() {
  // streamlined body: lathe of a few rings + caudal fin
  const pos = [], idx = [], nrm = [];
  const rings = 7, radial = 7;
  for (let i = 0; i <= rings; i++) {
    const t = i / rings;
    const x = (t - 0.5) * 2.0;                       // -1 tail .. 1 snout
    const r = Math.sin(Math.pow(1 - t, 0.75) * Math.PI) * 0.34 + 0.02;
    for (let j = 0; j <= radial; j++) {
      const a = (j / radial) * Math.PI * 2;
      pos.push(x, Math.cos(a) * r, Math.sin(a) * r * 1.25);
      nrm.push(0, Math.cos(a), Math.sin(a));
    }
  }
  for (let i = 0; i < rings; i++) {
    for (let j = 0; j < radial; j++) {
      const a = i * (radial + 1) + j, b = a + 1, c = a + radial + 1, d = c + 1;
      idx.push(a, c, b, b, c, d);
    }
  }
  // caudal fin
  const base = pos.length / 3;
  const tailX = -1.0;
  pos.push(tailX, 0, 0, tailX - 0.34, 0.30, 0, tailX - 0.26, 0, 0,
           tailX - 0.34, -0.30, 0);
  for (let k = 0; k < 4; k++) nrm.push(0, 1, 0);
  idx.push(base, base + 1, base + 2, base, base + 2, base + 3);
  // dorsal fin
  const b2 = pos.length / 3;
  pos.push(0.1, 0.20, 0, -0.3, 0.34, 0, -0.35, 0.12, 0);
  for (let k = 0; k < 3; k++) nrm.push(0, 1, 0);
  idx.push(b2, b2 + 1, b2 + 2);

  const geo = new THREE.BufferGeometry();
  geo.setAttribute('position', new THREE.Float32BufferAttribute(pos, 3));
  geo.setAttribute('normal', new THREE.Float32BufferAttribute(nrm, 3));
  geo.setIndex(idx);
  geo.computeVertexNormals();
  return geo;
}

// ---------------------------------------------------------------------------
export function buildAtmosphere(field, state) {
  const group = new THREE.Group();
  group.name = 'atmosphere';
  const rng = mulberry32(4242);

  // ---------------- suspended particles ----------------
  const COUNT = 9000;
  const BOX = 150;
  const pos = new Float32Array(COUNT * 3);
  const size = new Float32Array(COUNT);
  const phase = new Float32Array(COUNT);
  for (let i = 0; i < COUNT; i++) {
    pos[i * 3] = (rng() - 0.5) * BOX;
    pos[i * 3 + 1] = (rng() - 0.5) * BOX;
    pos[i * 3 + 2] = (rng() - 0.5) * BOX;
    size[i] = 0.012 + Math.pow(rng(), 2.0) * 0.075;
    phase[i] = rng() * 100;
  }
  const snowGeo = new THREE.BufferGeometry();
  snowGeo.setAttribute('position', new THREE.BufferAttribute(pos, 3));
  snowGeo.setAttribute('aSize', new THREE.BufferAttribute(size, 1));
  snowGeo.setAttribute('aPhase', new THREE.BufferAttribute(phase, 1));
  const snowMat = new THREE.ShaderMaterial({
    uniforms: withShared({ uBox: { value: BOX }, uPixelScale: { value: 520 } }),
    vertexShader: SNOW_VS,
    fragmentShader: SNOW_FS,
    transparent: true,
    depthWrite: false,
    blending: THREE.AdditiveBlending,
  });
  const snow = new THREE.Points(snowGeo, snowMat);
  snow.frustumCulled = false;
  snow.name = 'marine_snow';
  group.add(snow);

  // ---------------- sun shafts ----------------
  const shaftMat = new THREE.ShaderMaterial({
    uniforms: withShared({ uIntensity: { value: 0.5 } }),
    vertexShader: SHAFT_VS,
    fragmentShader: SHAFT_FS,
    transparent: true,
    depthWrite: false,
    blending: THREE.AdditiveBlending,
    side: THREE.DoubleSide,
  });

  const shaftGeo = new THREE.CylinderGeometry(9, 26, 1, 14, 1, true);

  const shafts = new THREE.Group();
  shafts.name = 'light_shafts';
  const SUN_TILT = new THREE.Vector3(-0.55, -1, 0.62).normalize();
  const addShaft = (x, y, z, len, rad, intensity) => {
    const mat = new THREE.ShaderMaterial({
      uniforms: withShared({ uIntensity: { value: intensity } }),
      vertexShader: SHAFT_VS,
      fragmentShader: SHAFT_FS,
      transparent: true,
      depthWrite: false,
      blending: THREE.AdditiveBlending,
      side: THREE.DoubleSide,
    });
    const m = new THREE.Mesh(shaftGeo, mat);
    m.position.set(x, y - len * 0.5, z);
    m.scale.set(rad / 9, len, rad / 26);
    m.quaternion.setFromUnitVectors(new THREE.Vector3(0, -1, 0), SUN_TILT);
    m.frustumCulled = false;
    m.userData.baseIntensity = intensity;
    shafts.add(m);
    return m;
  };

  // Shafts exist only where light can reach: the three photic arenas plus the
  // shallow lips of the archways. Coordinates come from the seven places, never
  // from hard-coded world positions.
  const SHAFT_SITES = [];
  const SHAFT_ARENAS = ['glasshorizon', 'roseglass', 'verdant', 'azurespan'];
  for (const id of SHAFT_ARENAS) {
    const l = LOCATIONS.find((q) => q.id === id);
    if (!l) continue;
    const n = id === 'glasshorizon' ? 16 : 12;
    for (let i = 0; i < n; i++) {
      const a = rng() * Math.PI * 2, r = Math.sqrt(rng()) * 200;
      const x = l.x + Math.cos(a) * r, z = l.z + Math.sin(a) * r;
      const y = field.heightAt(x, z);
      if (-y > 90) continue;
      SHAFT_SITES.push([x, Math.min(-2, y + 6), z, 60 + rng() * 120, 12 + rng() * 26, 0.30 + rng() * 0.45]);
    }
  }
  for (const ch of CHAMBERS) {
    // light bleeding in through each cavern gate
    const gx = ch.x + Math.cos(ch.gateAngle) * ch.r * 1.6;
    const gz = ch.z + Math.sin(ch.gateAngle) * ch.r * 1.6;
    const gy = field.heightAt(gx, gz);
    SHAFT_SITES.push([gx, gy + 26, gz, 70, 26, 0.5]);
  }
  for (const s of SHAFT_SITES) addShaft(...s);
  group.add(shafts);

  // ---------------- fish schools ----------------
  const fishGeo = makeFishGeo();
  const schools = [];
  // Every place gets its own schools, sized to the arena.
  const SCHOOL_SITES = [];
  const SCHOOL_PLAN = {
    glasshorizon: [3, 90, 16], roseglass: [3, 110, 20], verdant: [3, 100, 24],
    aurel: [2, 80, -30], azurespan: [2, 70, -40], floodednave: [2, 60, -20],
    abyssalbowl: [2, 50, -60],
  };
  for (const l of LOCATIONS) {
    const [n, count, lift] = SCHOOL_PLAN[l.id] || [1, 60, 0];
    for (let k = 0; k < n; k++) {
      const a = (k / n) * Math.PI * 2 + 0.7;
      const r = 60 + rng() * 120;
      SCHOOL_SITES.push([l.x + Math.cos(a) * r, l.z + Math.sin(a) * r, lift - rng() * 18, count]);
    }
  }
  for (const s of SCHOOL_SITES) {
    const [sx, sz, sy, count] = s;
    const geo = fishGeo.clone();
    const off = new Float32Array(count * 3);
    const ph = new Float32Array(count);
    const rad = new Float32Array(count);
    const spd = new Float32Array(count);
    const scl = new Float32Array(count);
    for (let i = 0; i < count; i++) {
      off[i * 3] = (rng() - 0.5) * 16;
      off[i * 3 + 1] = (rng() - 0.5) * 8;
      off[i * 3 + 2] = (rng() - 0.5) * 16;
      ph[i] = rng() * 6.283;
      rad[i] = 5 + rng() * 16;
      spd[i] = 0.14 + rng() * 0.2;
      scl[i] = 0.16 + rng() * 0.22;
    }
    geo.setAttribute('aOffset', new THREE.InstancedBufferAttribute(off, 3));
    geo.setAttribute('aPhase', new THREE.InstancedBufferAttribute(ph, 1));
    geo.setAttribute('aRadius', new THREE.InstancedBufferAttribute(rad, 1));
    geo.setAttribute('aSpeed', new THREE.InstancedBufferAttribute(spd, 1));
    geo.setAttribute('aScale', new THREE.InstancedBufferAttribute(scl, 1));
    const mat = new THREE.ShaderMaterial({
      uniforms: withShared({
        uCenter: { value: new THREE.Vector3(sx, -sy, sz) },
        uBodyCol: { value: new THREE.Vector3(0.16, 0.19, 0.24) },
        uBellyCol: { value: new THREE.Vector3(0.46, 0.49, 0.50) },
      }),
      vertexShader: FISH_VS,
      fragmentShader: FISH_FS,
      side: THREE.DoubleSide,
    });
    const mesh = new THREE.InstancedMesh(geo, mat, count);
    const m = new THREE.Matrix4();
    for (let i = 0; i < count; i++) { m.identity(); mesh.setMatrixAt(i, m); }
    mesh.instanceMatrix.needsUpdate = true;
    mesh.frustumCulled = false;
    mesh.name = 'fish_school';
    group.add(mesh);
    schools.push(mesh);
  }

  let quality = state.quality;
  group.userData = {};

  return {
    group,
    setQuality(q) {
      quality = q;
      const f = q === 'low' ? 0.3 : q === 'medium' ? 0.6 : 1.0;
      snow.geometry.setDrawRange(0, Math.floor(COUNT * f));
    },
    update(dt, camera, time) {
      // particles follow the camera so the water always has body
      snowMat.uniforms.uCamPos.value.copy(camera.position);
      snowMat.uniforms.uPixelScale.value = window.innerHeight * 0.82;
      snow.position.copy(camera.position);
      // shafts only make sense while submerged, and fade with depth
      const depth = Math.max(0, -camera.position.y);
      shafts.visible = camera.position.y < 2;
      if (shafts.visible) {
        const fade = 1 - Math.min(1, Math.max(0, (depth - 40) / 160));
        for (const m of shafts.children) {
          m.material.uniforms.uCamPos.value.copy(camera.position);
          m.material.uniforms.uIntensity.value = m.userData.baseIntensity * fade;
        }
      }
      for (const s of schools) s.material.uniforms.uCamPos.value.copy(camera.position);
    },
  };
}

// -----------------------------------------------------------------------------
// THE LIVING ABYSS — rock material family
// One shader, five geological families, chosen per formation. A basalt trench
// wall and a limestone shelf no longer share a single grey value, but they are
// still lit by the same water, so the world stays coherent.
// -----------------------------------------------------------------------------
import * as THREE from '../../vendor/three.module.js';
import { GLSL_HEADER, withShared } from '../shaders/common.js';

export const FAMILY = {
  limestone: 0,
  reef: 1,
  sandstone: 2,
  basalt: 3,
  mineral: 4,
};

export const ROCK_VS = /* glsl */`
attribute float aAO;
varying vec3 vWorld;
varying vec3 vNrm;
varying float vAO;
void main(){
  vec4 wp = modelMatrix * vec4(position, 1.0);
  vWorld = wp.xyz;
  vNrm = normalize(mat3(modelMatrix) * normal);
  vAO = aAO;
  gl_Position = projectionMatrix * viewMatrix * wp;
}
`;

export const ROCK_FS = GLSL_HEADER + /* glsl */`
uniform float uDetail;
uniform float uDarken;
uniform float uCaveLit;      // 1 = surface rock, 0 = deep interior rock
varying vec3 vWorld;
varying vec3 vNrm;
varying float vAO;

void main(){
  vec3 N = normalize(vNrm);
  // procedural detail must not alias into moiré at distance
  float dcam = length(uCamPos - vWorld);
  float nf = 1.0 - smoothstep(24.0, 260.0, dcam);

  float detailH;
  vec3 albedo = rockAlbedo(vWorld, N, 1.0, nf, detailH);
  N = sandRippleNormal(vWorld, N, nf);

  // interior rock is darker and more mineral, with no sediment rain
  albedo = mix(albedo * vec3(0.66, 0.72, 0.80), albedo, uCaveLit);

  N = perturbNormal(vWorld, N, 0.42, uDetail * (0.66 + 0.55 * nf));
  if (nf > 0.02) {
    N = perturbNormal(vWorld, N, 1.8, uDetail * 0.40 * nf);
    N = perturbNormal(vWorld, N, 6.5, uDetail * 0.20 * nf);
  }

  vec3 col = litSurface(albedo, N, vWorld, 0.72, clamp(vAO, 0.0, 1.0), 1.0);
  col *= uDarken;
  col = applyWater(col, vWorld);
  gl_FragColor = vec4(col, 1.0);
}
`;

const cache = new Map();

/**
 * @param {object} opts family: 'limestone'|'reef'|'sandstone'|'basalt'|'mineral'
 */
export function createRockMaterial(opts = {}) {
  const fam = opts.family ?? 'limestone';
  const key = [
    fam, opts.detail ?? 1, opts.darken ?? 1, opts.caveLit ?? 1,
    opts.wetness ?? 0.6, opts.mineral ?? 0, opts.side ?? 'front',
  ].join('|');
  if (!opts.unique && cache.has(key)) return cache.get(key);

  const mat = new THREE.ShaderMaterial({
    uniforms: withShared({
      uDetail: { value: opts.detail ?? 1.0 },
      uDarken: { value: opts.darken ?? 1.0 },
      uCaveLit: { value: opts.caveLit ?? 1.0 },
      uFamily: { value: FAMILY[fam] ?? 0 },
      uWetness: { value: opts.wetness ?? 0.6 },
      uMineral: { value: opts.mineral ?? 0 },
    }),
    vertexShader: ROCK_VS,
    fragmentShader: ROCK_FS,
    side: opts.side === 'double' ? THREE.DoubleSide : THREE.FrontSide,
    transparent: !!opts.transparent,
  });
  mat.name = 'rock_' + fam;
  cache.set(key, mat);
  return mat;
}

export const rockMaterial = createRockMaterial({ family: 'limestone', detail: 1.0 });

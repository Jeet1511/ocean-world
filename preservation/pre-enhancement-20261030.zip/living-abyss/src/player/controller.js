// -----------------------------------------------------------------------------
// THE LIVING ABYSS — swim controller
// One kinematic body used by both exploration modes. Depth-aware damping,
// terrain collision that slides along rock instead of sticking, ceiling
// collision inside chambers, and analytic push-out from hero rock colliders.
// -----------------------------------------------------------------------------
import * as THREE from '../../vendor/three.module.js';
import { WORLD } from '../world/geography.js';

export class SwimController {
  constructor(field) {
    this.field = field;
    this.pos = new THREE.Vector3(-560, -9, 1420);
    this.vel = new THREE.Vector3();
    this.yaw = Math.PI;
    this.pitch = -0.05;
    this.keys = new Set();
    this.colliders = [];        // {type:'cyl'|'ell', ...}
    this.ceilings = [];         // {x,z,r,y}
    this.radius = 1.15;         // body clearance (metres)
    this.speedCap = 13.0;
    this.sprintCap = 30.0;
    this.accel = 26.0;
    this.mode = 'free';         // 'free' | 'dolphin'
    this.breach = 0;            // 0..1 how much we're above water
    this.lastSafe = this.pos.clone();
  }

  setPose(x, y, z, yaw, pitch) {
    this.pos.set(x, y, z);
    this.vel.set(0, 0, 0);
    if (yaw !== undefined) this.yaw = yaw;
    if (pitch !== undefined) this.pitch = pitch;
  }

  addKey(code, down) {
    if (down) this.keys.add(code); else this.keys.delete(code);
  }

  /** Height of the walkable surface at a location (seabed, or chamber floor). */
  floorAt(x, z) {
    const f = this.field.heightAt(x, z);
    // chamber floors are the carved terrain itself — one continuous surface
    return f;
  }

  /** Ceiling clamp: inside a flooded chamber the roof limits how high you go. */
  ceilingAt(x, z, y) {
    // Concentric roof bands: the innermost band that contains the point wins,
    // and the open gate sector is exempt so halls are always enterable.
    let best = Infinity, bestR = Infinity;
    for (let i = 0; i < this.ceilings.length; i++) {
      const c = this.ceilings[i];
      const d = Math.hypot(x - c.x, z - c.z);
      if (d >= c.r) continue;
      if (y > c.y + 2.0) continue;            // above the roof: outside the hall
      if (c.gate !== undefined) {
        let da = Math.atan2(z - c.z, x - c.x) - c.gate;
        da = Math.atan2(Math.sin(da), Math.cos(da));
        if (Math.abs(da) < c.gateHalf) continue;
      }
      if (c.r < bestR) { bestR = c.r; best = c.y; }
    }
    return best;
  }

  /** Resolve penetration against hero rock colliders (pillars, arches, plates). */
  resolveColliders(p) {
    for (let i = 0; i < this.colliders.length; i++) {
      const c = this.colliders[i];
      if (c.type === 'cyl') {
        if (p.y > c.yTop + this.radius || p.y < c.yBase - this.radius) continue;
        const dx = p.x - c.x, dz = p.z - c.z;
        const d = Math.hypot(dx, dz);
        const rr = c.r + this.radius;
        if (d < rr && d > 1e-4) {
          const push = (rr - d);
          p.x += (dx / d) * push;
          p.z += (dz / d) * push;
        }
      } else if (c.type === 'ell') {
        // ellipsoid (towers, boulders, arch feet)
        const dx = (p.x - c.x) / (c.rx + this.radius);
        const dy = (p.y - c.y) / (c.ry + this.radius);
        const dz = (p.z - c.z) / (c.rz + this.radius);
        const d2 = dx * dx + dy * dy + dz * dz;
        if (d2 < 1 && d2 > 1e-6) {
          const d = Math.sqrt(d2);
          const s = (1 - d) / d;
          p.x += dx * s * (c.rx + this.radius) * 0.55;
          p.y += dy * s * (c.ry + this.radius) * 0.35;
          p.z += dz * s * (c.rz + this.radius) * 0.55;
        }
      } else if (c.type === 'cap') {
        // capsule segment (arch spans, bridges)
        const ax = c.x1, ay = c.y1, az = c.z1;
        const bx = c.x2, by = c.y2, bz = c.z2;
        const abx = bx - ax, aby = by - ay, abz = bz - az;
        const apx = p.x - ax, apy = p.y - ay, apz = p.z - az;
        const len2 = abx * abx + aby * aby + abz * abz;
        let t = len2 > 0 ? (apx * abx + apy * aby + apz * abz) / len2 : 0;
        t = Math.max(0, Math.min(1, t));
        const cx = ax + abx * t, cy = ay + aby * t, cz = az + abz * t;
        const dx = p.x - cx, dy = p.y - cy, dz = p.z - cz;
        const d = Math.hypot(dx, dy, dz);
        const rr = c.r + this.radius;
        if (d < rr && d > 1e-4) {
          const push = rr - d;
          p.x += (dx / d) * push;
          p.y += (dy / d) * push;
          p.z += (dz / d) * push;
        }
      }
    }
  }

  update(dt, camera) {
    const k = this.keys;
    const sprint = k.has('ShiftLeft') || k.has('ShiftRight');
    const fwd = new THREE.Vector3(
      -Math.sin(this.yaw) * Math.cos(this.pitch),
      Math.sin(this.pitch),
      -Math.cos(this.yaw) * Math.cos(this.pitch)
    );
    const right = new THREE.Vector3(Math.cos(this.yaw), 0, -Math.sin(this.yaw));

    const thrust = new THREE.Vector3();
    if (k.has('KeyW')) thrust.add(fwd);
    if (k.has('KeyS')) thrust.sub(fwd);
    if (k.has('KeyQ')) thrust.y -= 1;
    if (k.has('KeyE')) thrust.y += 1;
    // A/D: turn (per the design spec), with a small strafe component for feel
    let turn = 0;
    if (k.has('KeyA')) turn += 1;
    if (k.has('KeyD')) turn -= 1;
    this.yaw += turn * dt * (1.5 + (this.mode === 'dolphin' ? 0.7 : 0));
    if (k.has('KeyZ')) thrust.addScaledVector(right, -0.6);
    if (k.has('KeyC')) thrust.addScaledVector(right, 0.6);

    const cap = sprint ? this.sprintCap : this.speedCap;
    if (thrust.lengthSq() > 0) {
      thrust.normalize();
      this.vel.addScaledVector(thrust, this.accel * dt * (sprint ? 1.8 : 1));
    }

    // water drag — heavy, gliding, never instant
    const drag = Math.pow(0.06, dt);
    this.vel.multiplyScalar(drag * (thrust.lengthSq() > 0 ? 1.0 : 0.92));
    if (this.vel.length() > cap) this.vel.setLength(cap);

    // buoyancy near the surface keeps you from drifting to the sky
    const surf = WORLD.seaLevel;
    if (this.pos.y > surf - 1.2 && this.vel.y > 0) this.vel.y *= 0.55;

    const next = this.pos.clone().addScaledVector(this.vel, dt);

    // --- world bounds (soft wall, never a teleport)
    const m = 60;
    next.x = Math.max(WORLD.minX + m, Math.min(WORLD.maxX - m, next.x));
    next.z = Math.max(WORLD.minZ + m, Math.min(WORLD.maxZ - m, next.z));
    next.y = Math.min(next.y, 220);   // a dolphin may jump, not fly to space

    // --- terrain collision with sliding
    const clearance = this.radius;
    const floor = this.floorAt(next.x, next.z);
    if (next.y < floor + clearance) {
      // try sliding: keep x-only or z-only motion
      const fx = this.floorAt(next.x, this.pos.z);
      const fz = this.floorAt(this.pos.x, next.z);
      if (this.pos.y >= fx + clearance) { next.z = this.pos.z; next.y = Math.max(next.y, fx + clearance); }
      else if (this.pos.y >= fz + clearance) { next.x = this.pos.x; next.y = Math.max(next.y, fz + clearance); }
      else {
        next.x = this.pos.x; next.z = this.pos.z;
        next.y = Math.max(next.y, this.floorAt(next.x, next.z) + clearance);
      }
      this.vel.multiplyScalar(0.55);
      if (next.y < floor + clearance) next.y = floor + clearance;
    }

    // --- chamber ceilings
    const ceil = this.ceilingAt(next.x, next.z, this.pos.y);
    if (next.y + clearance > ceil) {
      next.y = ceil - clearance;
      this.vel.y *= 0.3;
    }

    // --- hero rock colliders
    this.resolveColliders(next);
    const floorAfter = this.floorAt(next.x, next.z);
    if (next.y < floorAfter + clearance) next.y = floorAfter + clearance;

    this.vel.copy(next).sub(this.pos).multiplyScalar(1 / Math.max(dt, 1e-4));
    if (this.vel.length() > cap * 1.5) this.vel.setLength(cap * 1.5);
    this.pos.copy(next);

    this.breach = THREE.MathUtils.clamp(this.pos.y / 1.5, 0, 1);

    // --- camera
    if (camera) {
      const dir = fwd;
      if (this.mode === 'free') {
        camera.position.copy(this.pos);
        camera.lookAt(this.pos.clone().add(dir));
      }
    }
    return this;
  }
}

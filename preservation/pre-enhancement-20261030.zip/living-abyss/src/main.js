// =============================================================================
// THE LIVING ABYSS
// One continuous 4.8 km x 3.6 km ocean world, 0 to -1,150 m, fully swimmable.
// Built in production passes, in the order a real environment team would work:
//   seabed -> distant water -> sky/surface -> geology -> reef -> vegetation ->
//   coral -> caverns -> life -> light & chart.
// =============================================================================
import * as THREE from '../vendor/three.module.js';
import { EffectComposer } from '../vendor/jsm/postprocessing/EffectComposer.js';
import { RenderPass } from '../vendor/jsm/postprocessing/RenderPass.js';
import { UnrealBloomPass } from '../vendor/jsm/postprocessing/UnrealBloomPass.js';
import { ShaderPass } from '../vendor/jsm/postprocessing/ShaderPass.js';
import { OutputPass } from '../vendor/jsm/postprocessing/OutputPass.js';

import { TerrainField, WORLD, START_POSE, REGIONS, LANDMARKS, LOCATIONS, PORTALS } from './world/geography.js';
import { buildTerrain, buildApron } from './world/terrain.js';
import { buildSky, buildOcean } from './world/ocean.js';
import { buildGeology } from './world/geology.js';
import { buildFlora } from './world/flora.js';
import { buildCaverns } from './world/caverns.js';
import { buildAtmosphere } from './world/atmosphere.js';
import { buildPortals } from './world/portals.js';
import { SwimController } from './player/controller.js';
import { Dolphin } from './player/dolphin.js';
import { initHUD, updateHUD, toggleBigMap, bigMapOpen, hideHUD, setPerf, showToast, discoveredCount,
  openTravelDial, closeTravelDial, travelDialOpen, showPortalPrompt, hidePortalPrompt } from './ui/hud.js';
import { shared } from './shaders/common.js';

const $ = (id) => document.getElementById(id);

// ---------------------------------------------------------------------------
// Boot
// ---------------------------------------------------------------------------
const state = {
  quality: 'high',
  ready: false,
  paused: false,
  mode: 'free',
  time: 0,
  fps: 0,
};

const app = $('app');
const renderer = new THREE.WebGLRenderer({
  antialias: true,
  powerPreference: 'high-performance',
  stencil: false,
});
renderer.setPixelRatio(Math.min(window.devicePixelRatio || 1, 1.75));
renderer.setSize(window.innerWidth, window.innerHeight);
renderer.toneMapping = THREE.ACESFilmicToneMapping;
renderer.toneMappingExposure = 0.84;
renderer.outputColorSpace = THREE.SRGBColorSpace;
app.appendChild(renderer.domElement);

// software renderers (headless QC) get a lighter profile automatically
const gl = renderer.getContext();
const dbg = gl.getExtension('WEBGL_debug_renderer_info');
const gpuName = dbg ? gl.getParameter(dbg.UNMASKED_RENDERER_WEBGL) : 'unknown';
const isSoftware = /swiftshader|llvmpipe|software/i.test(gpuName);
if (isSoftware) { state.quality = 'low'; }

const scene = new THREE.Scene();
const camera = new THREE.PerspectiveCamera(62, window.innerWidth / window.innerHeight, 0.2, 40000);

// ---------------------------------------------------------------------------
// Post-processing chain
// ---------------------------------------------------------------------------
const GradeShader = {
  uniforms: {
    tDiffuse: { value: null },
    uVignette: { value: 0.46 },
    uAberration: { value: 0.0016 },
    uGrain: { value: 0.0075 },
    uTime: { value: 0 },
    uSaturation: { value: 1.24 },
    uLift: { value: 0.004 },
    uDepthUnder: { value: 0 },
  },
  vertexShader: /* glsl */`
    varying vec2 vUv;
    void main(){ vUv = uv; gl_Position = projectionMatrix * modelViewMatrix * vec4(position,1.0); }
  `,
  fragmentShader: /* glsl */`
    uniform sampler2D tDiffuse;
    uniform float uVignette, uAberration, uGrain, uTime, uSaturation, uLift, uDepthUnder;
    varying vec2 vUv;
    float hash(vec2 p){ return fract(sin(dot(p, vec2(41.3, 289.1))) * 43758.5453); }
    void main(){
      vec2 uv = vUv;
      vec2 c = uv - 0.5;
      float r2 = dot(c, c);
      // subtle lens aberration, stronger underwater
      float ab = uAberration * (0.5 + 2.0 * r2) * (1.0 + uDepthUnder * 0.6);
      vec3 col;
      col.r = texture2D(tDiffuse, uv + c * ab).r;
      col.g = texture2D(tDiffuse, uv).g;
      col.b = texture2D(tDiffuse, uv - c * ab).b;

      // vignette
      float vig = smoothstep(1.05, 0.28, r2 * 2.0);
      col *= mix(1.0, vig, uVignette);

      // tone curve: water is a low-contrast medium, so the grade has to restore
      // separation between the lit surfaces and the haze behind them
      col = pow(max(col, 0.0), vec3(1.06));
      col = mix(col, col * col * (3.0 - 2.0 * col), 0.42);   // gentle S-curve

      // saturation + lift
      float l = dot(col, vec3(0.2126, 0.7152, 0.0722));
      col = mix(vec3(l), col, uSaturation);
      col += uLift * vec3(0.55, 0.85, 1.0);

      // film grain, finer underwater
      float g = hash(uv * vec2(1920.0, 1080.0) + uTime * 37.0) - 0.5;
      col += g * uGrain * (0.5 + 0.6 * uDepthUnder) * (0.35 + 0.65 * (1.0 - l));

      gl_FragColor = vec4(col, 1.0);
    }
  `,
};

renderer.info.autoReset = false;
const composer = new EffectComposer(renderer);
const renderPass = new RenderPass(scene, camera);
composer.addPass(renderPass);

const bloom = new UnrealBloomPass(
  new THREE.Vector2(window.innerWidth, window.innerHeight), 0.26, 0.9, 1.12);
composer.addPass(bloom);

const grade = new ShaderPass(GradeShader);
composer.addPass(grade);

const output = new OutputPass();
composer.addPass(output);

// ---------------------------------------------------------------------------
// Loading UI helpers
// ---------------------------------------------------------------------------
const passList = [];
function logPass(text) {
  passList.push(text);
  const node = $('pass');
  node.innerHTML = passList.map((t, i) =>
    `<div class="${i === passList.length - 1 ? 'now' : 'done'}">${i === passList.length - 1 ? '▸' : '✓'} ${t}</div>`
  ).slice(-7).join('');
  $('barIn').style.width = `${Math.min(100, (passList.length / 12) * 100)}%`;
}
const nextFrame = () => new Promise((r) => requestAnimationFrame(() => r()));
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));

// ---------------------------------------------------------------------------
// World build
// ---------------------------------------------------------------------------
let field, controller, dolphin, ocean, sky, terrainGroup, geologyGroup, floraGroup, cavernsGroup, atm, portalGroup, apronGroup;

async function buildWorld() {
  const t0 = performance.now();

  logPass('Baking master bathymetry — 4.8 × 3.6 km continuous seabed');
  await nextFrame(); await nextFrame();
  field = new TerrainField().build();
  window.ABYSS.field = field;

  logPass('Forming terraced shelves, archways and abyssal trenches');
  await nextFrame();
  terrainGroup = buildTerrain(field);
  scene.add(terrainGroup);
  const apron = buildApron(field);
  scene.add(apron);
  apronGroup = apron;
  await nextFrame();

  logPass('Raising the sky dome and the sea surface');
  sky = buildSky();
  scene.add(sky);
  ocean = buildOcean();
  scene.add(ocean);
  await nextFrame();

  logPass('Sculpting monumental geology — sealed towers, shelves, arches, walls');
  geologyGroup = buildGeology(field, controller = new SwimController(field));
  scene.add(geologyGroup);
  await nextFrame();

  logPass('Seeding reef boulders, sediment and seabed debris');
  await nextFrame();

  logPass('Growing four kelp species, seagrass meadows and seven coral families');
  floraGroup = buildFlora(field, state);
  scene.add(floraGroup);
  await nextFrame();

  logPass('Populating the coral gardens');
  await nextFrame();

  logPass('Carving the Veiled Caverns and their connecting passages');
  cavernsGroup = buildCaverns(field, controller);
  scene.add(cavernsGroup);
  await nextFrame();

  logPass('Raising the seven teleporter gates');
  portalGroup = buildPortals(field, controller ? controller.colliders : []);
  scene.add(portalGroup);
  // Clear the apertures: any collision volume that would stand inside a gate is
  // dropped, so a teleporter can always be swum into.
  if (controller) {
    const gates = portalGroup.userData.portals;
    controller.colliders = controller.colliders.filter((c) => !gates.some((g) => {
      const d = Math.hypot(c.x - g.x, c.z - g.z);
      if (c.type === 'cyl') return d < c.r + g.radius + 6 && g.centreY > c.yBase - 8 && g.centreY < c.yTop + 8;
      if (c.type === 'ell') return d < c.rx + g.radius + 6;
      return false;
    }));
  }
  await nextFrame();

  logPass('Releasing marine life and suspended particles');
  atm = buildAtmosphere(field, state);
  scene.add(atm.group);
  await nextFrame();

  logPass('Charting the seven places — bathymetry, depths, portals');
  initHUD(field);
  await nextFrame();

  controller.setPose(START_POSE.x, START_POSE.y, START_POSE.z, START_POSE.yaw, START_POSE.pitch);

  dolphin = new Dolphin(scene, field, controller);
  logPass(`World complete — ${((performance.now() - t0) / 1000).toFixed(1)} s`);

  // final warm-up compile so the first swim never stutters
  renderer.compile(scene, camera);
  state.ready = true;
  window.__READY = true;
  await sleep(260);
  $('loader').classList.add('hidden');
  $('hud').classList.add('on');
  $('startNote').classList.remove('hidden');
  setTimeout(() => showToast('The Living Abyss', 'Swim north into the deep'), 1400);
}

// ---------------------------------------------------------------------------
// Input
// ---------------------------------------------------------------------------
const canvas = renderer.domElement;
let dragging = false;

canvas.addEventListener('mousedown', (e) => {
  if (bigMapOpen()) return;
  dragging = true;
  if (document.pointerLockElement !== canvas && canvas.requestPointerLock) {
    canvas.requestPointerLock();
  }
});
window.addEventListener('mouseup', () => { dragging = false; });
document.addEventListener('pointerlockchange', () => {
  if (document.pointerLockElement === canvas) $('startNote').classList.add('hidden');
});
window.addEventListener('mousemove', (e) => {
  if (document.pointerLockElement !== canvas && !dragging) return;
  const s = 0.0022;
  controller.yaw -= e.movementX * s;
  controller.pitch -= e.movementY * s;
  controller.pitch = Math.max(-1.45, Math.min(1.45, controller.pitch));
  if (document.pointerLockElement !== canvas && dragging) {
    // fallback gently rotates at half rate for trackpads
  }
});

// touch look
let lastTouch = null;
canvas.addEventListener('touchstart', (e) => { lastTouch = e.touches[0]; }, { passive: true });
canvas.addEventListener('touchmove', (e) => {
  const t = e.touches[0];
  if (lastTouch) {
    controller.yaw -= (t.clientX - lastTouch.clientX) * 0.005;
    controller.pitch -= (t.clientY - lastTouch.clientY) * 0.005;
    controller.pitch = Math.max(-1.45, Math.min(1.45, controller.pitch));
  }
  lastTouch = t;
}, { passive: true });

window.addEventListener('keydown', (e) => {
  if (e.code === 'KeyE') { tryTravel(); return; }
  if (e.code === 'KeyM') { toggleBigMap(); return; }
  if (e.code === 'KeyH') { hideHUD(); return; }
  if (e.code === 'KeyF') { toggleMode(); return; }
  if (e.code === 'KeyP') { state.paused = !state.paused; return; }
  if (e.code === 'KeyR') { cycleQuality(); return; }
  if (e.code === 'Escape') { toggleBigMap(false); }
  controller.addKey(e.code, true);
  if (['KeyW','KeyA','KeyS','KeyD','KeyQ','KeyE','ShiftLeft','Space'].includes(e.code)) e.preventDefault();
});
window.addEventListener('keyup', (e) => controller.addKey(e.code, false));

function toggleMode() {
  state.mode = state.mode === 'free' ? 'dolphin' : 'free';
  controller.mode = state.mode;
  dolphin.setActive(state.mode === 'dolphin');
  showToast(state.mode === 'dolphin' ? 'Dolphin' : 'Free swim',
            state.mode === 'dolphin' ? 'Third-person exploration' : 'First-person exploration');
}

// ---------------------------------------------------------------------------
// Portal travel
// ---------------------------------------------------------------------------
const travel = { inside: null, cooldown: 0, busy: false };

function arriveAtPortal(id) {
  const p = portalGroup && portalGroup.userData.portals.find((q) => q.id === id);
  const loc = LOCATIONS.find((q) => q.id === id);
  if (!p || !loc) return;
  // land just inside the arena, 34 m in front of that arena's own ring
  const toCentre = Math.atan2(-loc.z, -loc.x);
  const x = p.x + Math.cos(toCentre) * 30;
  const z = p.z + Math.sin(toCentre) * 30;
  const y = p.centreY + 2;
  controller.setPose(x, y, z, Math.atan2(-Math.cos(toCentre), -Math.sin(toCentre)), -0.02);
  controller.update(0.016, camera);
  travel.cooldown = 1.6;
  showToast(loc.name, 'Arrived through the portal');
}

function tryTravel() {
  if (!travel.inside || travel.busy) return;
  travel.busy = true;
  openTravelDial(travel.inside.id, (id) => {
    arriveAtPortal(id);
    travel.busy = false;
    hidePortalPrompt();
    closeTravelDial();
  });
  const iv = setInterval(() => {
    if (!travelDialOpen()) { travel.busy = false; clearInterval(iv); }
  }, 250);
}

function cycleQuality() {
  const order = ['low', 'medium', 'high', 'ultra'];
  const i = order.indexOf(state.quality);
  applyQuality(order[(i + 1) % order.length]);
  showToast('Quality', state.quality.toUpperCase());
}

function applyQuality(q) {
  state.quality = q;
  bloom.enabled = q !== 'low';
  bloom.strength = q === 'ultra' ? 0.34 : 0.26;
  renderer.setPixelRatio(q === 'low' ? 1 : q === 'medium' ? 1.15 : q === 'high' ? Math.min(devicePixelRatio, 1.75) : Math.min(devicePixelRatio, 2));
  if (atm) atm.setQuality(q);
  if (floraGroup) floraGroup.userData.setQuality(q);
}

window.addEventListener('resize', () => {
  camera.aspect = window.innerWidth / window.innerHeight;
  camera.updateProjectionMatrix();
  renderer.setSize(window.innerWidth, window.innerHeight);
  composer.setSize(window.innerWidth, window.innerHeight);
  bloom.resolution.set(window.innerWidth, window.innerHeight);
});

// ---------------------------------------------------------------------------
// Frame loop
// ---------------------------------------------------------------------------
const clock = new THREE.Clock();
let fpsAccum = 0, fpsFrames = 0, camDepth = 0;

function tick() {
  requestAnimationFrame(tick);
  const dt = Math.min(clock.getDelta(), 0.05);
  if (!state.ready) return;
  // sample last frame's cost before we start this one
  fpsAccum += dt; fpsFrames++;
  renderer.info.reset();

  if (!state.paused) state.time += dt;

  // shared medium uniforms
  shared.uTime.value = state.time;
  shared.uCamPos.value.copy(camera.position);
  grade.uniforms.uTime.value = state.time;

  if (!bigMapOpen() && !state.paused) {
    controller.update(dt, camera);
  }

  const y = controller.pos.y;
  camDepth = Math.max(0, -y);
  const underwater = y < 0.4;
  shared.uFogScale.value = (state.fogOverride ?? 1) * (underwater ? 1.0 : 0.34);
  shared.uCausticStrength.value = underwater ? 0.72 : 0.0;
  shared.uShaftStrength.value = underwater ? (camDepth < 320 ? 1.0 : 0.55) : 0.25;
  grade.uniforms.uDepthUnder.value = THREE.MathUtils.clamp(camDepth / 120, 0, 1);
  grade.uniforms.uAberration.value = underwater ? 0.0016 + camDepth * 1.2e-5 : 0.0009;
  renderer.toneMappingExposure = underwater ? 0.84 + Math.min(0.26, camDepth / 3200) : 0.74;

  // keep the sky and the surface centred on the camera so neither ever clips
  if (sky) {
    sky.position.copy(camera.position);
    const m = sky.material.uniforms;
    m.uUnderwater.value = underwater ? 1 : 0;
    // the colour of water at infinity, matching the medium's own falloff
    const d = Math.min(camDepth, 1200);
    const k = 1.0;
    m.uWaterFar.value.set(
      0.095 * Math.exp(-d * 0.0075) * 0.55,
      0.395 * Math.exp(-d * 0.0055) * 0.55,
      0.470 * Math.exp(-d * 0.0042) * 0.60,
    );
  }
  if (ocean) ocean.position.set(camera.position.x, 0, camera.position.z);

  // portals: proximity prompt + travel
  if (portalGroup) {
    if (travel.cooldown > 0) travel.cooldown -= dt;
    const inside = portalGroup.userData.update(dt, state.time, controller.pos);
    travel.inside = inside;
    if (inside && travel.cooldown <= 0 && !travelDialOpen()) {
      showPortalPrompt(inside.loc.name);
      if (!state._autoPrompted) { state._autoPrompted = true; }
    } else if (!inside) {
      hidePortalPrompt();
    }
  }

  if (dolphin) dolphin.update(dt, camera, state.mode === 'dolphin');
  if (atm) atm.update(dt, camera, state.time);
  if (floraGroup) floraGroup.userData.update(dt, state.time, camera);
  if (geologyGroup) geologyGroup.userData.update?.(dt, state.time);

  updateHUD({ pos: controller.pos, yaw: controller.yaw, depth: camDepth, mode: state.mode }, dt);

  // perf readout
  if (fpsAccum > 0.5) {
    state.fps = fpsFrames / fpsAccum;
    const info = renderer.info;
    setPerf(`${state.fps.toFixed(0)} FPS · ${info.render.calls} draws<br>` +
            `${(info.render.triangles / 1e6).toFixed(2)}M tris · ${state.quality}`);
    fpsAccum = 0; fpsFrames = 0;
  }

  composer.render();
}

// ---------------------------------------------------------------------------
// Debug / QC hooks
// ---------------------------------------------------------------------------
window.ABYSS = {
  state, scene, camera, renderer, composer,
  teleport(x, y, z, yaw, pitch) {
    controller.setPose(x, y, z, yaw, pitch);
    controller.update(0.016, camera);
  },
  lookAt(x, y, z) {
    const dx = x - controller.pos.x, dy = y - controller.pos.y, dz = z - controller.pos.z;
    controller.yaw = Math.atan2(-dx, -dz);
    controller.pitch = Math.atan2(dy, Math.hypot(dx, dz));
    controller.update(0.016, camera);
  },
  setMode(m) { state.mode = m; controller.mode = m; dolphin.setActive(m === 'dolphin'); },
  quality(q) { applyQuality(q); },
  get gpu() { return gpuName; },

  pixel(x, y) {
    const gl2 = renderer.getContext();
    const px = new Uint8Array(4);
    gl2.readPixels(x, renderer.domElement.height - y, 1, 1, gl2.RGBA, gl2.UNSIGNED_BYTE, px);
    return Array.from(px);
  },
  frame() { return { fps: state.fps, calls: renderer.info.render.calls, tris: renderer.info.render.triangles }; },
  geology() { return geologyGroup ? geologyGroup.userData : null; },
  pick(nx, ny) {
    // nx, ny in -1..1 clip space; returns the name of the frontmost object
    const rc = new THREE.Raycaster();
    rc.setFromCamera(new THREE.Vector2(nx, ny), camera);
    rc.far = 40000;
    const hits = rc.intersectObjects(scene.children, true);
    return hits.slice(0, 4).map(h => ({
      name: h.object.name || h.object.type,
      parent: h.object.parent ? h.object.parent.name : '',
      dist: Math.round(h.distance),
      y: +h.point.y.toFixed(1),
    }));
  },
  setFog(v) { state.fogOverride = v; },
  counts() {
    let inst = 0, meshes = 0, verts = 0;
    scene.traverse((o) => {
      if (o.isMesh || o.isInstancedMesh) {
        meshes++;
        const g = o.geometry;
        const v = g && g.attributes.position ? g.attributes.position.count : 0;
        verts += v * (o.isInstancedMesh ? o.count : 1);
        if (o.isInstancedMesh) inst += o.count;
      }
    });
    return { meshes, inst, verts };
  },
  regions: REGIONS,
  landmarks: LANDMARKS,
  locations: LOCATIONS,
  world: WORLD,
  /** jump to a named place (QC + debugging; the map itself only sets waypoints) */
  place(id, opts = {}) {
    const l = LOCATIONS.find((q) => q.id === id);
    if (!l) return null;
    const y = l.depth[0] + (opts.drop ?? 6);
    this.teleport(l.x + (opts.dx || 0), y, l.z + (opts.dz || 0), opts.yaw || 0, opts.pitch || 0);
    if (opts.look) this.lookAt(opts.look[0], opts.look[1], opts.look[2]);
    return { id: l.id, name: l.name, x: l.x, y, z: l.z, depth: l.depth };
  },
  stats() {
    return {
      geology: geologyGroup && geologyGroup.userData.stats,
      flora: floraGroup && floraGroup.userData.stats,
      terrain: { minY: field && field.minY, maxY: field && field.maxY, buildMs: field && field.buildTime },
      discovered: discoveredCount(),
      places: LOCATIONS.length,
      fps: state.fps,
    };
  },
  setSun(az, el) {
    shared.uSunDir.value.set(Math.cos(el) * Math.sin(az), Math.sin(el), Math.cos(el) * Math.cos(az)).normalize();
  },
  travel(id) { arriveAtPortal(id); },
  map(on) { toggleBigMap(on); },
  portalInside() { return travel.inside ? travel.inside.id : null; },
  portalProbe() {
    const c = camera.position, p = controller.pos;
    const direct = portalGroup.userData.inside(p);
    return {
      cam: c.toArray().map((v) => +v.toFixed(2)),
      ctrl: p.toArray().map((v) => +v.toFixed(2)),
      direct: direct ? direct.id : null,
      radii: portalGroup.userData.portals.map((q) => [q.id, q.radius, +q.centreY.toFixed(1)]),
      paused: state.paused, time: +state.time.toFixed(2),
    };
  },
  portalDistances() {
    const c = camera.position;
    return (portalGroup ? portalGroup.userData.portals : []).map((p) => ({
      id: p.id, d: +Math.hypot(c.x - p.x, c.z - p.z, c.y - p.centreY).toFixed(2),
    })).sort((a, b) => a.d - b.d).slice(0, 3);
  },
  /** QC/diagnostic: hide individual systems to find an artefact's owner */
  toggle(what, on) {
    if (what === 'bloom') { bloom.enabled = on !== false; return true; }
    if (what === 'grade') { grade.enabled = on !== false; return true; }
    if (what === 'post') { bloom.enabled = on !== false; grade.enabled = on !== false; return true; }
    const map = { terrain: terrainGroup, geology: geologyGroup, flora: floraGroup,
      caverns: cavernsGroup, portals: portalGroup, atm: atm && atm.group, sky, ocean,
      apron: apronGroup };
    const g = map[what];
    if (g && g.visible !== undefined) g.visible = on !== false;
    else if (g && g.mesh) g.mesh.visible = on !== false;
    return !!g;
  },
  hideCard(on) {
    const el = document.getElementById('placeCard');
    if (el) el.style.display = on === false ? '' : 'none';
  },
  portals() {
    const list = portalGroup ? portalGroup.userData.portals : [];
    return list.map((p) => ({ id: p.id, name: p.name, x: p.x, y: p.centreY, z: p.z, radius: p.radius }));
  },
  hideUI(on) {
    for (const id of ['hud', 'startNote', 'loader', 'placeCard']) {
      const el = document.getElementById(id);
      if (el) el.style.display = on === false ? '' : 'none';
    }
  },
};

buildWorld().then(() => {
  applyQuality(state.quality);
  tick();
}).catch((err) => {
  console.error(err);
  $('loadHint').textContent = 'generation error: ' + err.message;
});

window.addEventListener('error', (e) => {
  $('loadHint').textContent = 'error: ' + e.message;
});

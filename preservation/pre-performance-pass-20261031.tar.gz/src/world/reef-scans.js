// Real specimen-derived coral geometry, modified for a game reef. Source scans
// depict dry skeletons; runtime pigment is an artistic treatment, not measured
// living tissue. Habitat-limited, instanced, and non-solid like existing flora.
import * as THREE from '../../vendor/three.module.js';
import { GLTFLoader } from '../../vendor/jsm/loaders/GLTFLoader.js';
import { GLSL_MEDIUM, GLSL_LIGHT, withShared } from '../shaders/common.js?rev=09';
import { planScanColonies } from './reef-scan-plan.js?rev=09';
import { LOCATIONS } from './geography.js?rev=09';

const VS=`
attribute vec3 aPigment;
varying vec3 vWorld;varying vec3 vNormal;varying vec2 vUv;varying vec3 vPigment;
void main(){
 vec4 wp=modelMatrix*instanceMatrix*vec4(position,1.0);vWorld=wp.xyz;vUv=uv;vPigment=aPigment;
 vNormal=normalize(mat3(modelMatrix*instanceMatrix)*normal);
 gl_Position=projectionMatrix*viewMatrix*wp;
}`;
const FS=GLSL_MEDIUM+GLSL_LIGHT+`
uniform sampler2D uMap;uniform sampler2D uNormalMap;uniform sampler2D uAOMap;
varying vec3 vWorld;varying vec3 vNormal;varying vec2 vUv;varying vec3 vPigment;
void main(){
 vec3 n=normalize(vNormal);if(!gl_FrontFacing)n=-n;
 // Cotangent frame from screen derivatives preserves the scan's normal detail
 // without adding a tangent buffer to every repeated coral instance.
 vec3 q1=dFdx(vWorld),q2=dFdy(vWorld);vec2 st1=dFdx(vUv),st2=dFdy(vUv);
 vec3 tangent=q1*st2.y-q2*st1.y,bitangent=-q1*st2.x+q2*st1.x;
 if(dot(tangent,tangent)>.000001&&dot(bitangent,bitangent)>.000001){
  tangent=normalize(tangent);bitangent=normalize(bitangent);
  vec3 mapN=texture2D(uNormalMap,vUv).xyz*2.0-1.0;
  vec3 detail=normalize(mat3(tangent,bitangent,n)*mapN);
  n=normalize(mix(n,detail,uQualityTier<.5?.18:.40));
 }
 vec3 scan=texture2D(uMap,vUv).rgb;
 // The museum specimens are dry skeletons. Retain their photographic value
 // variation, but use art-directed pigment rather than presenting bleached
 // skeletal surfaces as measured living tissue.
 float surfaceDetail=dot(scan,vec3(.24,.66,.10));
 vec3 albedo=mix(scan,vPigment*(.35+surfaceDetail*.90),.72);
 float ao=mix(.65,1.0,texture2D(uAOMap,vUv).r);
 vec3 col;
 if(uQualityTier<.5){
   vec3 sun=sunlightAt(vWorld.y);float ndl=max(dot(n,uSunDir),0.0);
   col=albedo*(sun*(.32+.68*ndl)+ambientLight(vWorld.y)*1.15+vec3(.10))*ao;
 }else col=litSurface(albedo,n,vWorld,.82,ao,.55)+albedo*.08;
 float shallow=1.0-smoothstep(24.0,90.0,-vWorld.y);
 col+=albedo*vec3(.17,.10,.07)*shallow;
 float deep=smoothstep(200.0,450.0,-uCamPos.y)*(1.0-smoothstep(12.0,80.0,length(vWorld-uCamPos)));
 col+=albedo*vec3(.28,.36,.42)*deep;
 gl_FragColor=vec4(applyWater(col,vWorld),1.0);
}`;

export async function addReefScans(scene,field,portals,colliders=[]){
 const plan=planScanColonies(field,portals,colliders),loader=new GLTFLoader();
 const kinds=['branching','boulder','foliose','staghorn','table','deep'],assets={};
 await Promise.all(kinds.map(async kind=>{
  try{
   const gltf=await loader.loadAsync(`./assets/models/coral_scans/${kind}.glb`);gltf.scene.updateMatrixWorld(true);
   let part;gltf.scene.traverse(o=>{if(!part&&o.isMesh&&o.material?.map)part=o;});
   if(!part||!part.material.normalMap||!part.material.aoMap)throw new Error('Expected colour, normal and occlusion maps');
   const geometry=part.geometry.clone().applyMatrix4(part.matrixWorld);geometry.computeBoundingBox();
   const box=geometry.boundingBox,centre=box.getCenter(new THREE.Vector3());
   const width=Math.max(box.max.x-box.min.x,box.max.z-box.min.z);
   if(width<1e-7)throw new Error('Invalid scan bounds');
   geometry.translate(-centre.x,-box.min.y,-centre.z);geometry.scale(1/width,1/width,1/width);
   if(!geometry.attributes.normal)geometry.computeVertexNormals();geometry.computeBoundingSphere();
   assets[kind]={geometry,color:part.material.map,normal:part.material.normalMap,ao:part.material.aoMap};
  }catch(error){console.warn('Coral scan unavailable: '+kind,error);}
 }));
 const group=new THREE.Group();group.name='real_coral_scans';scene.add(group);
 const palettes=[
  [.95,.42,.28],[.92,.62,.32],[.60,.45,.74],[.42,.72,.65],[.86,.75,.57],
 ];
 const meshes=[],counts={},dummy=new THREE.Object3D();
 for(const habitat of ['glasshorizon','roseglass','abyssalbowl'])for(const kind of kinds){
  const asset=assets[kind],points=plan.placements.filter(p=>p.habitat===habitat&&p.kind===kind);
  if(!asset||!points.length)continue;
  const geometry=asset.geometry.clone(),colors=new Float32Array(points.length*3);
  const material=new THREE.ShaderMaterial({uniforms:withShared({uMap:{value:asset.color},uNormalMap:{value:asset.normal},uAOMap:{value:asset.ao}}),
   vertexShader:VS,fragmentShader:FS,side:THREE.DoubleSide});
  const mesh=new THREE.InstancedMesh(geometry,material,points.length);mesh.name=`coral_scan_${kind}_${habitat}`;
  points.forEach((p,i)=>{
   dummy.position.set(p.x,p.y,p.z);dummy.rotation.set(0,p.rotation,0);dummy.scale.setScalar(p.scale);dummy.updateMatrix();mesh.setMatrixAt(i,dummy.matrix);
   colors.set(palettes[p.tint],i*3);
  });
  geometry.setAttribute('aPigment',new THREE.InstancedBufferAttribute(colors,3));mesh.instanceMatrix.needsUpdate=true;mesh.computeBoundingSphere();
  group.add(mesh);meshes.push({mesh,habitat});counts[habitat]=(counts[habitat]||0)+points.length;
 }
 const loaded=Object.keys(assets);
 return {group,counts,loaded,sites:plan.sites,
  update(camera){for(const {mesh,habitat} of meshes){
   const l=LOCATIONS.find(q=>q.id===habitat);mesh.visible=Math.hypot(camera.x-l.x,camera.z-l.z)<240;
  }}
 };
}

// Two shallow, non-solid turtle patrols. These are bounded samples, not a
// continuous swimming-route proof or a model of turtle migration.
import {planArrival} from './arrival-plan.js?rev=09';

export const TURTLE_HABITATS={
 glasshorizon:{minimum:1,maximum:1,depth:7,radius:8,speed:.055,phase:2.7},
 roseglass:{minimum:1,maximum:1,depth:14,radius:9,speed:.045,phase:2.3},
};
export function planTurtlePatrols(field,portals,colliders=[]){
 const routes=[];
 for(const [id,s] of Object.entries(TURTLE_HABITATS)){
  const gate=portals.find(p=>p.id===id);if(!gate)continue;
  const pose=planArrival(gate,field),ux=-Math.sin(pose.yaw),uz=-Math.cos(pose.yaw);
  let found;
  // Start near, but not in, the approach centre; relocate only within the
  // same shallow habitat when a candidate overlaps a coarse geology bound.
  for(const forward of [25,35,45,55,65]){
   for(const side of [14,-14,24,-24,34,-34]){
    const x=pose.x+ux*forward-uz*side,z=pose.z+uz*forward+ux*side,y=-s.depth;
    let clear=true;
    for(let i=0;i<20&&clear;i++){
     const a=i*Math.PI/10,px=x+Math.cos(a)*s.radius,pz=z+Math.sin(a)*s.radius;
     if(field.surfaceHeightAt(px,pz)>y-4 || field.surfaceHeightAt(px,pz)<-55){clear=false;break;}
     for(const c of colliders){const b=c.visualBounds,m=2.5;
      if(b&&px>b.min[0]-m&&px<b.max[0]+m&&y>b.min[1]-m&&y<b.max[1]+m&&pz>b.min[2]-m&&pz<b.max[2]+m){clear=false;break;}
     }
    }
    if(clear){found={habitat:id,x,y,z,radius:s.radius,speed:s.speed,phase:s.phase,size:1.6};break;}
   }
   if(found)break;
  }
  if(found)routes.push(found);
 }
 return routes;
}

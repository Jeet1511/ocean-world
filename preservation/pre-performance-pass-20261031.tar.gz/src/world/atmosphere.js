// -----------------------------------------------------------------------------
// THE LIVING ABYSS — atmosphere & marine life
// Suspended particles, volumetric sun shafts in the photic zone and through
// cavern gates, and small schools of fish that orbit their home ground.
// -----------------------------------------------------------------------------
import * as THREE from '../../vendor/three.module.js';
import { GLSL_NOISE, GLSL_MEDIUM, GLSL_LIGHT, withShared, shared } from '../shaders/common.js?rev=09';
import { mulberry32, fbm2, clamp } from '../core/noise.js?rev=09';
import { WORLD, CHAMBERS, LOCATIONS } from './geography.js?rev=09';
import { SchoolSimulation } from './school-simulation.js?rev=09';
import { HABITATS } from './habitat-profiles.js?rev=09';
import { planSpeciesSchools } from './species-school-plan.js?rev=09';
import { planEcosystem } from './ecosystem-plan.js?rev=09';

// ---------------------------------------------------------------------------
// Marine snow / suspended sediment
// ---------------------------------------------------------------------------
const SNOW_VS = /* glsl */`
uniform float uTime;
uniform vec3 uCamPos;
uniform float uBox;
uniform float uPixelScale;
attribute float aSize;
attribute float aPhase;
varying float vFade;
varying float vDepth;
varying vec3 vWorld;

void main(){
  vec3 p = position;
  // drift + slow settle, wrapped in a box that follows the camera
  p.x += sin(uTime * 0.21 + aPhase) * 2.4;
  p.y += sin(uTime * 0.14 + aPhase * 1.7) * 1.6 - mod(uTime * 0.22 + aPhase * 3.0, uBox);
  p.z += cos(uTime * 0.19 + aPhase * 1.3) * 2.4;

  vec3 rel = p - uCamPos;
  rel.x = mod(rel.x + uBox * 0.5, uBox) - uBox * 0.5;
  rel.y = mod(rel.y + uBox * 0.5, uBox) - uBox * 0.5;
  rel.z = mod(rel.z + uBox * 0.5, uBox) - uBox * 0.5;
  vec3 wp = uCamPos + rel;
  vWorld = wp;
  vDepth = -wp.y;

  vec4 mv = viewMatrix * vec4(wp, 1.0);
  float dist = length(mv.xyz);
  vFade = smoothstep(uBox * 0.5, uBox * 0.12, dist);
  gl_Position = projectionMatrix * mv;
  // aSize is a real diameter in metres
  gl_PointSize = clamp(aSize * uPixelScale / max(dist, 1.0), 0.8, 9.0);
}
`;

const SNOW_FS = /* glsl */`
uniform float uTime;
uniform vec3 uCamPos;
varying float vFade;
varying float vDepth;
varying vec3 vWorld;

void main(){
  vec2 c = gl_PointCoord - 0.5;
  float d = length(c);
  if (d > 0.5) discard;
  float soft = (1.0 - smoothstep(0.05, 0.5, d));

  // particles catch the little light there is; they thin out with depth
  float dens = mix(0.55, 0.16, smoothstep(0.0, 900.0, vDepth));
  vec3 tint = mix(vec3(0.75, 0.95, 1.0), vec3(0.55, 0.75, 1.0), smoothstep(0.0, 600.0, vDepth));
  float lum = (0.25 + 0.75 * (1.0 - smoothstep(0.0, 700.0, vDepth)));
  vec3 col = tint * lum;
  float a = soft * vFade * dens;
  gl_FragColor = vec4(col, a);
}
`;

// ---------------------------------------------------------------------------
// Volumetric sun shafts
// ---------------------------------------------------------------------------
const SHAFT_VS = /* glsl */`
varying vec3 vWorld;
varying vec3 vLocal;
void main(){
  vec4 wp = modelMatrix * vec4(position, 1.0);
  vWorld = wp.xyz;
  vLocal = position;
  gl_Position = projectionMatrix * viewMatrix * wp;
}
`;

const SHAFT_FS = GLSL_NOISE + /* glsl */`
uniform float uTime;
uniform vec3 uCamPos;
uniform vec3 uSunDir;
uniform float uIntensity;
varying vec3 vWorld;
varying vec3 vLocal;

void main(){
  // CylinderGeometry spans -0.5..+0.5 in local Y. The earlier shader
  // treated its radius in metres as a 0..1 coordinate, making radial fade
  // identically zero over nearly the whole mesh. Use the actual angle and
  // height to form a few soft, time-varying curtains of scattered light.
  float h = clamp(0.5 - vLocal.y, 0.0, 1.0);
  float angle = atan(vLocal.z, vLocal.x);
  float stripes = pow(0.5 + 0.5 * sin(angle * 5.0 + h * 3.0 + uTime * .11), 3.2);
  float drift = fbm2(vec2(angle * 2.3 + uTime * .035, h * 3.4 - uTime * .08), 3);
  float fade = pow(1.0 - h, 1.35) * smoothstep(0.01, 0.12, h);
  fade *= (0.16 + 0.84 * stripes) * (0.45 + 0.55 * drift);
  float dist = length(vWorld - uCamPos);
  fade *= smoothstep(5.0, 24.0, dist);
  // A modest additive contribution, not an opaque cone or a white screen.
  vec3 col = vec3(0.36, 0.70, 0.76) * fade * uIntensity * 0.36;
  gl_FragColor = vec4(col, 1.0);
}
`;

// ---------------------------------------------------------------------------
// Fish
// ---------------------------------------------------------------------------
const FISH_VS = /* glsl */`
uniform float uTime;
uniform vec3 uCenter;
attribute vec3 aOffset;
attribute vec3 aPrevious;
attribute vec3 aVelocity;
attribute vec3 aPreviousVelocity;
uniform float uSchoolBlend;
uniform float uSwimStyle;
attribute float aPhase;
attribute float aRadius;
attribute float aSpeed;
attribute float aScale;
varying vec3 vWorld;
varying vec3 vNrm;
varying float vFade;
varying vec2 vFishUv;
varying float vFishPhase;

void main(){
  vFishUv = uv;
  vFishPhase = aPhase;
  // Positions and velocities are computed by the bounded school simulation;
  // interpolate consecutive fixed steps to keep motion smooth at display rate.
  vec3 p = uCenter + mix(aPrevious, aOffset, uSchoolBlend);
  vec3 velocity = mix(aPreviousVelocity, aVelocity, uSchoolBlend);
  vec3 fwd = normalize(vec3(velocity.x, 0.0, velocity.z) + vec3(0.0001,0.0,0.0));
  vec3 right = normalize(cross(vec3(0.0, 1.0, 0.0), fwd));
  vec3 up = cross(fwd, right);
  mat3 basis = mat3(fwd, up, right);

  vec3 lp = position * aScale;
  // Fish swim styles are intentionally distinct. Normal fish use a traveling
  // body/tail wave; upright seahorses flutter subtly; sunfish move their tall
  // dorsal/anal fins; flatfish ripple their edges. These are shader-based
  // approximations, not substitutes for individually authored skeletal rigs.
  float tail = clamp(-position.x * 1.3, 0.0, 1.0);
  if (uSwimStyle > 3.5) {
    lp.y += sin(uTime * 3.6 + aPhase - position.x * 3.2) * abs(position.z) * .12 * aScale;
  } else if (uSwimStyle > 2.5) {
    lp.z += sin(uTime * 2.3 + aPhase - position.y * 1.4) * pow(abs(position.y), 1.5) * .20 * aScale;
  } else if (uSwimStyle > 1.5) {
    lp.z += sin(uTime * 5.0 + aPhase + position.y * 4.0) * .018 * aScale;
  } else {
    lp.z += sin(uTime * 7.0 + aPhase - position.x * 4.0) * (.015 + .13 * tail) * aScale;
  }

  vec3 wp = p + basis * lp;
  vWorld = wp;
  vNrm = normalize(basis * normal);
  float dist = length(wp - cameraPosition);
  vFade = (1.0 - smoothstep(135.0, 205.0, dist));
  gl_Position = projectionMatrix * viewMatrix * vec4(wp, 1.0);
}
`;

const FISH_FS = GLSL_MEDIUM + /* glsl */`
uniform vec3 uBodyCol;
uniform vec3 uBellyCol;
varying vec3 vWorld;
varying vec3 vNrm;
varying float vFade;
varying vec2 vFishUv;
varying float vFishPhase;

void main(){
  // Ordered screen-door fade keeps fish depth-writing and avoids the abrupt
  // school pop that previously occurred at the distance-culling boundary.
  float dither=fract(sin(dot(floor(gl_FragCoord.xy),vec2(12.9898,78.233)))*43758.5453);
  if (vFade < dither) discard;
  vec3 N = normalize(vNrm);
  if (!gl_FrontFacing) N = -N;
  float belly = (1.0 - smoothstep(-0.7, 0.1, N.y));
  vec3 albedo = mix(uBodyCol, uBellyCol, belly);
  // Faint flank pattern and a small eye on either side of the generic fish.
  float pattern = .5 + .5*sin(vFishUv.x*64.0 + sin(vFishUv.y*22.0)*.8 + vFishPhase);
  albedo *= .92 + pattern*.10;
  float eyeL=length((vFishUv-vec2(.84,.25))*vec2(2.0,1.0));
  float eyeR=length((vFishUv-vec2(.84,.75))*vec2(2.0,1.0));
  float eye=min(eyeL,eyeR);
  albedo=mix(albedo,vec3(.012,.019,.022),1.0-smoothstep(.014,.027,eye));
  float fres = pow(1.0 - abs(dot(N, normalize(uCamPos - vWorld))), 2.5);
  vec3 sun = sunlightAt(vWorld.y);
  vec3 col = albedo * (sun * (clamp(dot(N, uSunDir), 0.0, 1.0) * 0.9 + 0.15)
                     + ambientLight(vWorld.y) * 0.8);
  col += vec3(0.55, 0.75, 0.85) * fres * 0.35;
  col = applyWater(col, vWorld);
  gl_FragColor = vec4(col, 1.0);
}
`;

// Textured fish LOD from the CC0 Microsoft/Khronos barramundi asset.
// The base-color texture is from the original asset; the existing water model supplies lighting and haze.
const TEXTURED_FISH_FS = GLSL_MEDIUM + `
uniform sampler2D uFishTexture;
varying vec3 vWorld; varying vec3 vNrm; varying vec2 vFishUv; varying float vFade;
void main(){
 float dither=fract(sin(dot(floor(gl_FragCoord.xy),vec2(12.9898,78.233)))*43758.5453);
 if(vFade<dither)discard;
 vec3 N=normalize(vNrm); if(!gl_FrontFacing)N=-N;
 vec3 albedo=texture2D(uFishTexture,vFishUv).rgb;
 vec3 sun=sunlightAt(vWorld.y);
 float diffuse=clamp(dot(N,uSunDir)*.5+.5,0.0,1.0);
 vec3 col=albedo*(sun*(.30+.72*diffuse)+ambientLight(vWorld.y)*1.2+vec3(.20));
 float edge=pow(1.0-abs(dot(N,normalize(uCamPos-vWorld))),3.0);
 col+=vec3(.22,.30,.32)*edge*.15;
 gl_FragColor=vec4(applyWater(col,vWorld),1.0);
}`;

function makeFishGeo() {
  // streamlined body: lathe of a few rings + caudal fin
  const pos = [], idx = [], nrm = [], uvs = [];
  const rings = 11, radial = 12;
  for (let i = 0; i <= rings; i++) {
    const t = i / rings;
    const x = (t - 0.5) * 2.0;                       // -1 tail .. 1 snout
    const r = Math.sin(Math.pow(1 - t, 0.75) * Math.PI) * 0.34 + 0.02;
    for (let j = 0; j <= radial; j++) {
      const a = (j / radial) * Math.PI * 2;
      pos.push(x, Math.cos(a) * r, Math.sin(a) * r * 1.25);
      nrm.push(0, Math.cos(a), Math.sin(a));
      uvs.push(t, j / radial);
    }
  }
  for (let i = 0; i < rings; i++) {
    for (let j = 0; j < radial; j++) {
      const a = i * (radial + 1) + j, b = a + 1, c = a + radial + 1, d = c + 1;
      idx.push(a, c, b, b, c, d);
    }
  }
  // caudal fin
  const base = pos.length / 3;
  const tailX = -1.0;
  pos.push(tailX, 0, 0, tailX - 0.34, 0.30, 0, tailX - 0.26, 0, 0,
           tailX - 0.34, -0.30, 0);
  for (let k = 0; k < 4; k++) { nrm.push(0, 1, 0); uvs.push(0.02, k / 4); }
  idx.push(base, base + 1, base + 2, base, base + 2, base + 3);
  // dorsal fin
  const b2 = pos.length / 3;
  pos.push(0.1, 0.20, 0, -0.3, 0.34, 0, -0.35, 0.12, 0);
  for (let k = 0; k < 3; k++) { nrm.push(0, 1, 0); uvs.push(.42 + k*.04, 0.0); }
  idx.push(b2, b2 + 1, b2 + 2);
  // Paired pectoral fins and a small ventral fin give the original generic
  // schools a readable silhouette rather than a simple featureless spindle.
  for (const side of [-1,1]) {
    const b=pos.length/3;
    pos.push(.35,-.05,side*.21, .06,-.20,side*.53, -.08,-.09,side*.18);
    for(let k=0;k<3;k++){nrm.push(0,1,0);uvs.push(.58+k*.03,side>0?.25:.75);}
    idx.push(b,b+1,b+2);
  }
  const b3=pos.length/3;
  pos.push(.04,-.18,0,-.33,-.34,0,-.46,-.10,0);
  for(let k=0;k<3;k++){nrm.push(0,1,0);uvs.push(.35+k*.03,.5);}
  idx.push(b3,b3+1,b3+2);

  const geo = new THREE.BufferGeometry();
  geo.setAttribute('position', new THREE.Float32BufferAttribute(pos, 3));
  geo.setAttribute('normal', new THREE.Float32BufferAttribute(nrm, 3));
  geo.setAttribute('uv', new THREE.Float32BufferAttribute(uvs, 2));
  geo.setIndex(idx);
  geo.computeVertexNormals();
  return geo;
}

// ---------------------------------------------------------------------------
export function buildAtmosphere(field, state, colliders = [], schoolAsset = null, portals = [], speciesAssets = {}) {
  const group = new THREE.Group();
  group.name = 'atmosphere';
  const rng = mulberry32(4242);

  // ---------------- suspended particles ----------------
  const COUNT = 9000;
  const BOX = 150;
  const pos = new Float32Array(COUNT * 3);
  const size = new Float32Array(COUNT);
  const phase = new Float32Array(COUNT);
  for (let i = 0; i < COUNT; i++) {
    pos[i * 3] = (rng() - 0.5) * BOX;
    pos[i * 3 + 1] = (rng() - 0.5) * BOX;
    pos[i * 3 + 2] = (rng() - 0.5) * BOX;
    size[i] = 0.012 + Math.pow(rng(), 2.0) * 0.075;
    phase[i] = rng() * 100;
  }
  const snowGeo = new THREE.BufferGeometry();
  snowGeo.setAttribute('position', new THREE.BufferAttribute(pos, 3));
  snowGeo.setAttribute('aSize', new THREE.BufferAttribute(size, 1));
  snowGeo.setAttribute('aPhase', new THREE.BufferAttribute(phase, 1));
  const snowMat = new THREE.ShaderMaterial({
    uniforms: withShared({ uBox: { value: BOX }, uPixelScale: { value: 520 } }),
    vertexShader: SNOW_VS,
    fragmentShader: SNOW_FS,
    transparent: true,
    depthWrite: false,
    blending: THREE.AdditiveBlending,
  });
  const snow = new THREE.Points(snowGeo, snowMat);
  snow.frustumCulled = false;
  snow.name = 'marine_snow';
  group.add(snow);

  // ---------------- sun shafts ----------------
  const shaftGeo = new THREE.CylinderGeometry(0.55, 1.0, 1, 14, 1, true);

  const shafts = new THREE.Group();
  shafts.name = 'light_shafts';
  const SUN_TILT = shared.uSunDir.value.clone().negate();
  const addShaft = (x, y, z, len, rad, intensity, kind = 'ordinary') => {
    const mat = new THREE.ShaderMaterial({
      uniforms: withShared({ uIntensity: { value: intensity } }),
      vertexShader: SHAFT_VS,
      fragmentShader: SHAFT_FS,
      transparent: true,
      depthWrite: false,
      blending: THREE.AdditiveBlending,
      side: THREE.DoubleSide,
    });
    const m = new THREE.Mesh(shaftGeo, mat);
    // The top is the chosen surface source; center follows the light's tilt.
    m.position.set(x + SUN_TILT.x * len * .5, y + SUN_TILT.y * len * .5, z + SUN_TILT.z * len * .5);
    m.scale.set(rad, len, rad);
    m.quaternion.setFromUnitVectors(new THREE.Vector3(0, -1, 0), SUN_TILT);
    m.frustumCulled = true;
    m.userData.baseIntensity = intensity;
    m.userData.kind = kind;
    shafts.add(m);
    return m;
  };

  // Shafts exist only where light can reach: the three photic arenas plus the
  // shallow lips of the archways. Coordinates come from the seven places, never
  // from hard-coded world positions.
  const SHAFT_SITES = [];
  const SHAFT_ARENAS = ['glasshorizon', 'roseglass', 'verdant', 'azurespan'];
  for (const id of SHAFT_ARENAS) {
    const l = LOCATIONS.find((q) => q.id === id);
    if (!l) continue;
    const n = id === 'glasshorizon' ? 16 : 12;
    for (let i = 0; i < n; i++) {
      const a = rng() * Math.PI * 2, r = Math.sqrt(rng()) * 200;
      const x = l.x + Math.cos(a) * r, z = l.z + Math.sin(a) * r;
      const y = field.heightAt(x, z);
      if (-y > 90) continue;
      const originalLen = 60 + rng() * 120, radius = 12 + rng() * 26, intensity = 0.30 + rng() * 0.45;
      SHAFT_SITES.push([x, -0.6, z, Math.min(originalLen, Math.max(18,(-y+15)*1.4)), radius, intensity]);
    }
  }
  for (const ch of CHAMBERS) {
    // light bleeding in through each cavern gate
    const gx = ch.x + Math.cos(ch.gateAngle) * ch.r * 1.6;
    const gz = ch.z + Math.sin(ch.gateAngle) * ch.r * 1.6;
    const gy = field.heightAt(gx, gz);
    // Shallow entrances can receive surface light; deep halls do not get
    // a fictitious overhead sunbeam shining through their ceiling.
    if (gy > -90) SHAFT_SITES.push([gx, -0.6, gz, Math.min(110,(-gy+10)*1.4), 26, 0.35]);
  }
  // A cheap fallback beam follows the true opening's sunlight direction. On
  // medium/high a depth-clipped scattering pass supplies the richer volume.
  const open=shared.uCaveOpening.value, sun=shared.uSunDir.value;
  const rise=(Math.abs(open.y)-.6)/sun.y;
  SHAFT_SITES.push([open.x+sun.x*rise,-.6,open.z+sun.z*rise,125,18,.64,'cave']);
  // A few intentionally composed shafts accompany the shallow approach
  // gardens. They start at the real surface and fade in deeper water.
  for(const portal of portals){
    if(!['glasshorizon','roseglass','verdant'].includes(portal.id))continue;
    const dx=portal.loc.x-portal.x,dz=portal.loc.z-portal.z,d=Math.hypot(dx,dz)||1;
    for(const [forward,side] of [[45,-22],[75,22]]){
      const x=portal.x+dx/d*forward-dz/d*side,z=portal.z+dz/d*forward+dx/d*side;
      const bottom=field.surfaceHeightAt(x,z);
      if(bottom < -65 || bottom > -4)continue;
      SHAFT_SITES.push([x,-.6,z,Math.min(90,(-bottom+12)*1.4),20,.62]);
    }
  }
  for (const s of SHAFT_SITES) addShaft(...s);
  group.add(shafts);

  // ---------------- fish schools ----------------
  const fishGeo = makeFishGeo();
  const schools = [];
  // Every place gets its own schools, sized to the arena.
  const SCHOOL_SITES = [];
  const SCHOOL_PLAN = {
    glasshorizon: [3, 90, 16], roseglass: [3, 110, 20], verdant: [3, 100, 24],
    aurel: [2, 80, -30], azurespan: [2, 70, -40], floodednave: [2, 60, -20],
    abyssalbowl: [2, 50, -60],
  };
  for (const l of LOCATIONS) {
    const [n, count, lift] = SCHOOL_PLAN[l.id] || [1, 60, 0];
    for (let k = 0; k < n; k++) {
      const a = (k / n) * Math.PI * 2 + 0.7;
      const r = 60 + rng() * 120;
      let x = l.x + Math.cos(a) * r, z = l.z + Math.sin(a) * r;
      // One existing school per place is composed along the entrance-to-
      // landmark sightline, instead of all life being arbitrarily far away.
      // Its height and obstacle-safe spawn still use the real local field.
      const gate = portals.find(p => p.id === l.id);
      if (k === 0 && gate) { x = gate.x * .55 + l.x * .45; z = gate.z * .55 + l.z * .45; }
      SCHOOL_SITES.push([x, z, lift - rng() * 18, count, l.id]);
    }
  }
  // Two lightweight supplemental groups per destination fill the long empty
  // gaps around arrivals and landmarks. These are generic fish, not new
  // named species. Original 17 schools and their seeded layouts remain intact.
  for(const l of LOCATIONS){
    const gate=portals.find(p=>p.id===l.id),gx=gate?.x??l.x,gz=gate?.z??l.z;
    const dx=l.x-gx,dz=l.z-gz,d=Math.hypot(dx,dz)||1;
    for(let k=0;k<2;k++){
      const t=k===0?.23:.80,side=k===0?-17:17;
      let x=gx+dx*t-dz/d*side,z=gz+dz*t+dx/d*side;
      // A nearby life encounter at the initial shelf, not only at its gate.
      if(l.id==='glasshorizon'&&k===1){x=8;z=696;}
      SCHOOL_SITES.push([x,z,0,28,l.id,true]);
    }
  }
  // Small, recognisable species groups are separate from the generic schools.
  // If a model failed to load, do not falsely label procedural fallback fish.
  for(const p of planSpeciesSchools(field,colliders)) {
    if(speciesAssets[p.species]?.length) SCHOOL_SITES.push([p.x,p.z,0,p.count,p.habitat,true,p.species]);
  }
  const baselineCounts = {};
  for (const site of SCHOOL_SITES) baselineCounts[site[4]] = (baselineCounts[site[4]] || 0) + site[3];
  const population = planEcosystem(field, portals, colliders, baselineCounts, new Set(Object.keys(speciesAssets)));
  for (const p of population.plans) SCHOOL_SITES.push([p.x,p.z,0,p.count,p.habitat,true,p.species,p]);

  for (const s of SCHOOL_SITES) {
    const [sx, sz, sy, count, habitat, auxiliary=false, species=null, ecology=null] = s;
    // Formerly -sy put all schools with a negative depth plan ABOVE sea level.
    // Place their centre in the water column relative to the local seabed.
    const seabed = field.surfaceHeightAt(sx, sz);
    const depth = Math.max(2, -seabed);
    const lift=auxiliary && habitat==='floodednave' ? Math.min(depth*.25,12) : Math.min(depth*.48,35);
    const centreY = ecology ? ecology.y : Math.min(-3.5, seabed + lift);
    const waterRoom = Math.max(0.25, Math.min(ecology?.bottom ? .45 : 3.0, -centreY - 1.5, centreY - seabed - 1.0));
    const palettes = {
      glasshorizon: [[0.28,0.40,0.45],[0.68,0.70,0.60]],
      roseglass: [[0.57,0.31,0.16],[0.80,0.66,0.39]],
      verdant: [[0.35,0.45,0.23],[0.70,0.70,0.47]],
      aurel: [[0.27,0.38,0.47],[0.55,0.64,0.65]],
      azurespan: [[0.22,0.32,0.44],[0.49,0.56,0.64]],
      floodednave: [[0.21,0.38,0.37],[0.53,0.64,0.58]],
      abyssalbowl: [[0.12,0.22,0.34],[0.34,0.43,0.51]],
    };
    const palette = palettes[habitat] || palettes.aurel;
    // All shallow Glass Horizon schools, including the two newer nearby
    // groups, use the textured coastal LOD rather than featureless placeholders.
    // Use the recognisable surgeonfish asset for a subset of existing reef
    // schools; leave other generic groups generic instead of inventing labels.
    const inferredSpecies = !species && habitat === 'roseglass' && speciesAssets.palette_surgeonfish?.length
      && Math.abs(Math.floor(sx + sz)) % 2 === 0 ? 'palette_surgeonfish' : null;
    const renderedSpecies = species || inferredSpecies;
    const schoolParts = renderedSpecies ? speciesAssets[renderedSpecies]
      : (habitat === 'glasshorizon' && schoolAsset?.length ? schoolAsset : null);
    const geo = schoolParts ? schoolParts[0].geometry.clone() : fishGeo.clone();
    const off = new Float32Array(count * 3);
    const ph = new Float32Array(count);
    const rad = new Float32Array(count);
    const spd = new Float32Array(count);
    const scl = new Float32Array(count);
    for (let i = 0; i < count; i++) {
      const spread=ecology?.spread ?? 16;
      off[i * 3] = (rng() - 0.5) * spread;
      off[i * 3 + 1] = (rng() - 0.5) * 2 * waterRoom;
      off[i * 3 + 2] = (rng() - 0.5) * spread;
      ph[i] = rng() * 6.283;
      rad[i] = 5 + rng() * 16;
      spd[i] = 0.14 + rng() * 0.2;
      // Assets are normalized to length 2. Surgeonfish are ~20–31 cm;
      // tuna are larger and remain a small, open-water group.
      scl[i] = ecology?.scale ? ecology.scale[0]+rng()*(ecology.scale[1]-ecology.scale[0])
        : renderedSpecies==='palette_surgeonfish' ? .105+rng()*.045
        : renderedSpecies==='bluefin_tuna' ? .45+rng()*.25 : 0.16+rng()*0.22;
    }
    const simProfile={...HABITATS[habitat]?.school,...ecology?.swim,activity:true,
      bottomActivity:!!ecology?.bottom};
    const simulation = new SchoolSimulation(field, new THREE.Vector3(sx, centreY, sz), off, ph, rng, colliders, simProfile);
    geo.setAttribute('aOffset', new THREE.InstancedBufferAttribute(off, 3).setUsage(THREE.DynamicDrawUsage));
    geo.setAttribute('aPrevious', new THREE.InstancedBufferAttribute(simulation.previous, 3).setUsage(THREE.DynamicDrawUsage));
    geo.setAttribute('aVelocity', new THREE.InstancedBufferAttribute(simulation.velocities, 3).setUsage(THREE.DynamicDrawUsage));
    geo.setAttribute('aPreviousVelocity', new THREE.InstancedBufferAttribute(simulation.previousVelocities, 3).setUsage(THREE.DynamicDrawUsage));
    geo.setAttribute('aPhase', new THREE.InstancedBufferAttribute(ph, 1));
    geo.setAttribute('aRadius', new THREE.InstancedBufferAttribute(rad, 1));
    geo.setAttribute('aSpeed', new THREE.InstancedBufferAttribute(spd, 1));
    geo.setAttribute('aScale', new THREE.InstancedBufferAttribute(scl, 1));
    const mat = new THREE.ShaderMaterial({
      uniforms: withShared({
        uCenter: { value: new THREE.Vector3(sx, centreY, sz) },
        uSchoolBlend: { value: 1 },
        uSwimStyle: { value: ecology?.style ?? 0 },
        uBodyCol: { value: new THREE.Vector3(...palette[0]) },
        uBellyCol: { value: new THREE.Vector3(...palette[1]) },
        uFishTexture: { value: schoolParts ? schoolParts[0].map : null },
      }),
      vertexShader: FISH_VS,
      fragmentShader: schoolParts ? TEXTURED_FISH_FS : FISH_FS,
      side: THREE.DoubleSide,
    });
    const mesh = new THREE.InstancedMesh(geo, mat, count);
    const m = new THREE.Matrix4();
    for (let i = 0; i < count; i++) { m.identity(); mesh.setMatrixAt(i, m); }
    mesh.instanceMatrix.needsUpdate = true;
    mesh.frustumCulled = false;
    mesh.name = ecology ? 'fish_school_ecosystem' : auxiliary ? 'fish_school_ambient' : 'fish_school';
    mesh.userData.simulation = simulation;
    mesh.userData.habitat = habitat;
    mesh.userData.visual = renderedSpecies ? 'textured_'+renderedSpecies : schoolParts ? 'textured_barramundi_lod' : 'procedural_fish';
    mesh.userData.role = ecology?.role || 'existing school';
    if(renderedSpecies)mesh.userData.species=renderedSpecies;
    if (schoolParts) {
      // If a future model has multiple complementary parts, share simulation
      // attributes so the pieces move in exact lockstep.
      for (const part of schoolParts.slice(1)) {
        const partGeo = part.geometry.clone();
        for (const name of ['aOffset','aPrevious','aVelocity','aPreviousVelocity','aPhase','aRadius','aSpeed','aScale'])
          partGeo.setAttribute(name, geo.getAttribute(name));
        const partMat = mat.clone();
        partMat.uniforms = { ...mat.uniforms, uFishTexture: {value:part.map} };
        const partMesh = new THREE.InstancedMesh(partGeo, partMat, count);
        for (let i=0;i<count;i++) partMesh.setMatrixAt(i,m);
        partMesh.instanceMatrix.needsUpdate = true;
        partMesh.frustumCulled = false;
        partMesh.name = 'fish_school_detail';
        mesh.add(partMesh);
      }
    }
    group.add(mesh);
    schools.push(mesh);
  }

  let quality = state.quality;
  let schoolAccumulator = 0;
  let schoolTick = 0;
  const schoolStep = 0.125;
  group.userData = { populationReports: population.reports };

  return {
    group, populationPlan: population.plans, populationReports: population.reports,
    setQuality(q) {
      quality = q;
      const f = q === 'low' ? 0.3 : q === 'medium' ? 0.6 : 1.0;
      snow.geometry.setDrawRange(0, Math.floor(COUNT * f));
    },
    update(dt, camera, time, predators = []) {
      // particles follow the camera so the water always has body
      snowMat.uniforms.uCamPos.value.copy(camera.position);
      snowMat.uniforms.uPixelScale.value = window.innerHeight * 0.82;
      snow.position.copy(camera.position);
      // shafts only make sense while submerged, and fade with depth
      const depth = Math.max(0, -camera.position.y);
      shafts.visible = camera.position.y < 2;
      if (shafts.visible) {
        const fade = 1 - Math.min(1, Math.max(0, (depth - 40) / 160));
        for (const m of shafts.children) {
          m.visible = m.position.distanceToSquared(camera.position) < 220 * 220;
          m.material.uniforms.uCamPos.value.copy(camera.position);
          m.material.uniforms.uIntensity.value = m.userData.baseIntensity * fade * (m.userData.kind==='cave' && quality!=='low' ? .35 : 1);
        }
      }
      // Fixed update rate bounds CPU work; interpolate on intervening frames.
      // A frame clamp prevents a long stall from triggering unbounded catch-up.
      schoolAccumulator += Math.min(Math.max(dt, 0), 0.1);
      if (schoolAccumulator >= schoolStep) {
        schoolAccumulator -= schoolStep;
        schoolTick++;
        for (let i=0;i<schools.length;i++) {
          const school=schools[i];
          const range=240;
          const near=school.userData.simulation.center.distanceToSquared(camera.position)<range*range;
          // Distant schools still progress but run at half the update rate;
          // alternate groups across ticks and advance twice the step so their
          // simulated time remains close to real time. Each step remains <=.25s.
          if(!near && (schoolTick+i)%2!==0)continue;
          school.userData.simulation.step(near?schoolStep:schoolStep*2, camera.position, predators);
          for (const attr of ['aOffset','aPrevious','aVelocity','aPreviousVelocity']) school.geometry.getAttribute(attr).needsUpdate = true;
        }
      }
      for (const s of schools) {
        // The fish shader's useful visibility range ends at 170 m; a 225 m
        // centre margin accommodates school movement while skipping remote
        // schools before their thousands of vertices reach the GPU.
        const range=240;
        s.visible = s.material.uniforms.uCenter.value.distanceToSquared(camera.position) < range * range;
        s.material.uniforms.uCamPos.value.copy(camera.position);
        s.material.uniforms.uSchoolBlend.value = Math.min(1, schoolAccumulator / schoolStep);
      }
    },
  };
}

// -----------------------------------------------------------------------------
// THE LIVING ABYSS — rock material family
// One shader, five geological families, chosen per formation. A basalt trench
// wall and a limestone shelf no longer share a single grey value, but they are
// still lit by the same water, so the world stays coherent.
// -----------------------------------------------------------------------------
import * as THREE from '../../vendor/three.module.js';
import { GLSL_HEADER, withShared } from '../shaders/common.js?rev=09';

export const FAMILY = {
  limestone: 0,
  reef: 1,
  sandstone: 2,
  basalt: 3,
  mineral: 4,
};

export const ROCK_VS = /* glsl */`
attribute float aAO;
varying vec3 vWorld;
varying vec3 vNrm;
varying float vAO;
void main(){
  vec4 local = vec4(position, 1.0);
  vec3 objectNormal = normal;
  #ifdef USE_INSTANCING
    local = instanceMatrix * local;
    // Correct for the non-uniform instance scales used by boulders/rubble.
    mat3 im = mat3(instanceMatrix);
    objectNormal /= vec3(dot(im[0],im[0]), dot(im[1],im[1]), dot(im[2],im[2]));
    objectNormal = im * objectNormal;
  #endif
  vec4 wp = modelMatrix * local;
  vWorld = wp.xyz;
  vNrm = normalize(mat3(modelMatrix) * objectNormal);
  vAO = aAO;
  gl_Position = projectionMatrix * viewMatrix * wp;
}
`;

export const ROCK_FS = GLSL_HEADER + /* glsl */`
uniform float uDetail;
uniform float uDarken;
uniform float uCaveLit;      // 1 = surface rock, 0 = deep interior rock
uniform sampler2D uRockColorMap;
uniform sampler2D uRockNormalMap;
uniform sampler2D uRockRoughnessMap;
uniform float uRockMapsReady;
varying vec3 vWorld;
varying vec3 vNrm;
varying float vAO;

void main(){
  vec3 N = normalize(vNrm);
  // procedural detail must not alias into moiré at distance
  float dcam = length(uCamPos - vWorld);
  float nf = 1.0 - smoothstep(24.0, 260.0, dcam);

  if(uQualityTier<.5){
    // Keep the scanned texture and geological families on low, but replace
    // the expensive per-pixel Worley/fractal normal stack with one broad noise
    // and one dominant-axis color/normal/roughness sample.
    float n=vnoise2(vWorld.xz*.045+vWorld.y*.014);
    vec3 albedo=mix(vec3(.30,.28,.24),vec3(.46,.42,.35),n);
    if(uFamily>.5&&uFamily<1.5)albedo*=vec3(.91,.80,.73);
    else if(uFamily>1.5&&uFamily<2.5)albedo*=vec3(1.10,.87,.71);
    else if(uFamily>2.5&&uFamily<3.5)albedo*=vec3(.38,.42,.49);
    else if(uFamily>3.5)albedo*=vec3(.72,.82,.90);
    float rough=.72;
    if(uRockMapsReady>.5 && nf>.03 && (uFamily<2.5)){
      vec3 a=abs(N);vec2 uv=a.y>a.x&&a.y>a.z?vWorld.xz:(a.x>a.z?vWorld.yz:vWorld.xy);
      uv*=.48;
      vec3 tex=texture2D(uRockColorMap,uv).rgb;
      albedo*=mix(vec3(1.0),clamp(tex*1.7+.2,.45,1.5),.50*nf);
      rough=mix(.72,texture2D(uRockRoughnessMap,uv).r,.5*nf);
      vec3 t=texture2D(uRockNormalMap,uv).xyz*2.0-1.0;
      vec3 mapN=a.y>a.x&&a.y>a.z?vec3(t.x,t.z*sign(N.y),t.y):
        (a.x>a.z?vec3(t.z*sign(N.x),t.x,t.y):vec3(t.x,t.y,t.z*sign(N.z)));
      N=normalize(mix(N,normalize(mapN),.16*nf));
    }
    albedo=mix(albedo*vec3(.66,.72,.80),albedo,uCaveLit);
    vec3 sun=sunlightAt(vWorld.y);float ndl=max(dot(N,uSunDir),0.0);
    vec3 col=albedo*(sun*(.28+.78*ndl)+ambientLight(vWorld.y)*1.15);
    col+=albedo*sun*caveOpeningLight(vWorld)*.42*max(ndl,.15);
    float depth=max(-vWorld.y,0.0);
    if(depth<100.0){float c=causticPattern(vWorld.xz*.72,uTime*.38)*(1.0-smoothstep(14.0,100.0,depth));col*=1.0+c*.22*uCausticStrength;}
    float deep=smoothstep(120.0,360.0,depth);
    col+=albedo*vec3(.09,.15,.22)*deep;
    col*=uDarken*(.50+.50*clamp(vAO,0.0,1.0));
    gl_FragColor=vec4(applyWater(col,vWorld),1.0);return;
  }

  float detailH;
  vec3 albedo = rockAlbedo(vWorld, N, 1.0, nf, detailH);
  N = sandRippleNormal(vWorld, N, nf);

  // interior rock is darker and more mineral, with no sediment rain
  albedo = mix(albedo * vec3(0.66, 0.72, 0.80), albedo, uCaveLit);

  N = perturbNormal(vWorld, N, 0.42, uDetail * (0.38 + 0.30 * nf));
  if (nf > 0.02) {
    N = perturbNormal(vWorld, N, 1.8, uDetail * 0.16 * nf);
    N = perturbNormal(vWorld, N, 6.5, uDetail * 0.04 * nf);
  }

  float roughness = 0.72;
  // CC0 rock scan used for limestone, reef rock and sandstone: triplanar projection
  // avoids UV stretching on the original irregular geometry. Existing family
  // palettes, erosion, lighting and procedural relief remain in place.
  float mappedFamily = uFamily < 2.5 ? 1.0 : 0.0;
  if (uRockMapsReady > 0.5 && mappedFamily > 0.5 && nf > 0.02) {
    vec3 w = pow(abs(normalize(vNrm)), vec3(4.0));
    w /= max(w.x + w.y + w.z, 0.0001);
    vec3 q = vWorld * 0.48;
    vec3 colX = texture2D(uRockColorMap, q.yz).rgb;
    vec3 colY = texture2D(uRockColorMap, q.xz).rgb;
    vec3 colZ = texture2D(uRockColorMap, q.xy).rgb;
    vec3 mapped = colX * w.x + colY * w.y + colZ * w.z;
    albedo *= mix(vec3(1.0), clamp(mapped * 1.8 + 0.25, 0.45, 1.6), 0.48 * nf);

    vec3 nx = texture2D(uRockNormalMap, q.yz).xyz * 2.0 - 1.0;
    vec3 ny = texture2D(uRockNormalMap, q.xz).xyz * 2.0 - 1.0;
    vec3 nz = texture2D(uRockNormalMap, q.xy).xyz * 2.0 - 1.0;
    vec3 baseN = normalize(vNrm);
    vec3 texN = normalize(vec3(nx.z * sign(baseN.x), nx.x, nx.y) * w.x
                        + vec3(ny.x, ny.z * sign(baseN.y), ny.y) * w.y
                        + vec3(nz.x, nz.y, nz.z * sign(baseN.z)) * w.z);
    N = normalize(mix(N, texN, 0.20 * nf));
    float r = texture2D(uRockRoughnessMap, q.yz).r * w.x
            + texture2D(uRockRoughnessMap, q.xz).r * w.y
            + texture2D(uRockRoughnessMap, q.xy).r * w.z;
    roughness = mix(roughness, clamp(r, 0.35, 0.96), 0.65 * nf);
  }
  vec3 col = litSurface(albedo, N, vWorld, roughness, clamp(vAO, 0.0, 1.0), 1.0);
  col+=albedo*sunlightAt(vWorld.y)*caveOpeningLight(vWorld)*.42*max(dot(N,uSunDir),.15);
  col *= uDarken;
  col = applyWater(col, vWorld);
  gl_FragColor = vec4(col, 1.0);
}
`;

// Asset is loaded once and shared by every rock material. Node-based geometry
// tests have no DOM and simply keep the original procedural shader fallback.
const rockMaps = {
  uRockColorMap: { value: null }, uRockNormalMap: { value: null },
  uRockRoughnessMap: { value: null }, uRockMapsReady: { value: 0 },
};
if (typeof document !== 'undefined') {
  const loader = new THREE.TextureLoader();
  const root = './assets/textures/rock022/';
  let loaded = 0;
  const load = (uniform, file, srgb) => {
    const tex = loader.load(root + file, () => {
      if (++loaded === 3) rockMaps.uRockMapsReady.value = 1;
    }, undefined, (error) => console.warn('Rock texture could not be loaded; retaining procedural material.', error));
    tex.wrapS = tex.wrapT = THREE.RepeatWrapping;
    if (srgb) tex.colorSpace = THREE.SRGBColorSpace;
    uniform.value = tex;
  };
  load(rockMaps.uRockColorMap, 'Rock022_1K-JPG_Color.jpg', true);
  load(rockMaps.uRockNormalMap, 'Rock022_1K-JPG_NormalGL.jpg', false);
  load(rockMaps.uRockRoughnessMap, 'Rock022_1K-JPG_Roughness.jpg', false);
}

const cache = new Map();

/**
 * @param {object} opts family: 'limestone'|'reef'|'sandstone'|'basalt'|'mineral'
 */
export function createRockMaterial(opts = {}) {
  const fam = opts.family ?? 'limestone';
  const key = [
    fam, opts.detail ?? 1, opts.darken ?? 1, opts.caveLit ?? 1,
    opts.wetness ?? 0.6, opts.mineral ?? 0, opts.side ?? 'front',
  ].join('|');
  if (!opts.unique && cache.has(key)) return cache.get(key);

  const mat = new THREE.ShaderMaterial({
    uniforms: withShared({
      ...rockMaps,
      uDetail: { value: opts.detail ?? 1.0 },
      uDarken: { value: opts.darken ?? 1.0 },
      uCaveLit: { value: opts.caveLit ?? 1.0 },
      uFamily: { value: FAMILY[fam] ?? 0 },
      uWetness: { value: opts.wetness ?? 0.6 },
      uMineral: { value: opts.mineral ?? 0 },
    }),
    vertexShader: ROCK_VS,
    fragmentShader: ROCK_FS,
    side: opts.side === 'double' ? THREE.DoubleSide : THREE.FrontSide,
    transparent: !!opts.transparent,
  });
  mat.name = 'rock_' + fam;
  cache.set(key, mat);
  return mat;
}

export const rockMaterial = createRockMaterial({ family: 'limestone', detail: 1.0 });

import assert from 'node:assert/strict';
import * as THREE from '../vendor/three.module.js';
import {TerrainField} from '../src/world/geography.js?rev=09';
import {SwimController} from '../src/player/controller.js?rev=09';
import {buildGeology} from '../src/world/geology.js?rev=09';
import {buildCaverns} from '../src/world/caverns.js?rev=09';
import {buildPortals} from '../src/world/portals.js?rev=09';
const field=new TerrainField().build(),c=new SwimController(field);
buildGeology(field,c);buildCaverns(field,c);
const original=c.colliders.length;
const portals=buildPortals(field,c.colliders,c.surfaceSolids).userData.portals;
assert.equal(portals.length,7);assert.equal(c.colliders.length,original,'no collider removed to clear a gate');
for(const p of portals){
 assert(p.clearanceVerified,`${p.id} gate has no clear site`);
 for(const s of c.surfaceSolids){const b=s.bounds;assert(!(p.x+12.5>b.min.x&&p.x-12.5<b.max.x&&p.z+12.5>b.min.z&&p.z-12.5<b.max.z&&p.centreY+10>b.min.y&&p.centreY-10<b.max.y),`${p.id} intersects ${s.source}`);}
 let reaches=0;
 for(const [dx,dz] of [[1,0],[-1,0],[0,1],[0,-1]]){
  c.setPose(p.x+dx*24,p.centreY,p.z+dz*24,Math.atan2(dx,dz),0);c.keys.clear();c.addKey('KeyW',true);
  for(let i=0;i<100;i++){c.update(.05);if(Math.hypot(c.pos.x-p.x,c.pos.z-p.z)<p.radius*1.55 && Math.abs(c.pos.y-p.centreY)<p.radius*1.5){reaches++;break;}}
 }
 assert(reaches>=2,`${p.id} has fewer than two short approach paths`);
 console.log(`${p.id}: visual bounds clear; ${reaches}/4 local collision-enabled approaches`);
}
// Probe actual visible boulder triangles, not their conservative ellipsoid cores.
const candidates=c.surfaceSolids.filter(s=>s.source.startsWith('boulder:glasshorizon:'));
let hits=0;
for(const s of candidates.slice(0,12)){
 const b=s.bounds,centre=b.getCenter(new THREE.Vector3());
 const origin=new THREE.Vector3(b.max.x+6,centre.y,centre.z),dir=centre.clone().sub(origin).normalize();
 const mesh=new THREE.Mesh(s.geometry,new THREE.MeshBasicMaterial({side:THREE.DoubleSide}));
 const ray=new THREE.Raycaster(origin,dir,0,1000),hit=ray.intersectObject(mesh,false)[0];
 if(!hit)continue;
 const point=hit.point.clone().addScaledVector(dir,-.35),old=point.clone();
 if(s.createGuard().resolve(point,1.15)&&point.distanceTo(old)>.1)hits++;
}
assert(hits>=4,`actual rock surface contact expected, got ${hits}`);
console.log(`PASS: ${hits} sampled visible Glass Horizon boulder surfaces produce triangle contact; not a full-world proof.`);

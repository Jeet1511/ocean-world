// Bounded local schooling for the existing instanced fish. Reynolds-inspired
// separation, alignment and cohesion plus a home-range constraint, terrain
// clearance and swimmer avoidance. Not a species-accurate ecological model.
const clamp=(v,a,b)=>Math.max(a,Math.min(b,v));
// Signed approximate clearance from the same conservative rock cores used by
// movement. These are NOT exact visible mesh or cavern-roof queries.
// Conservative broad phase for the *existing* approximate distance function.
// It may admit extra objects but never rejects a core whose distance is below
// the requested threshold. In particular, the ellipsoid's approximation uses
// its minimum radius, so its expanded axes must scale by threshold/minRadius.
export function obstacleMayBeNear(c,x,y,z,threshold){
 if(c.type==='ell'){
  const min=Math.min(c.rx,c.ry,c.rz),f=1+threshold/min;
  return Math.abs(x-c.x)<=c.rx*f && Math.abs(y-c.y)<=c.ry*f && Math.abs(z-c.z)<=c.rz*f;
 }
 if(c.type==='cyl'){
  const r=c.r+threshold;
  return Math.abs(x-c.x)<=r && y>=c.yBase-threshold && y<=c.yTop+threshold && Math.abs(z-c.z)<=r;
 }
 if(c.type==='cap'){
  const r=c.r+threshold;
  return x>=Math.min(c.x1,c.x2)-r && x<=Math.max(c.x1,c.x2)+r &&
         y>=Math.min(c.y1,c.y2)-r && y<=Math.max(c.y1,c.y2)+r &&
         z>=Math.min(c.z1,c.z2)-r && z<=Math.max(c.z1,c.z2)+r;
 }
 return true;
}
// Reuse one result object per simulation instead of allocating thousands of
// short-lived vectors during each fixed school step.
function obstacleDistance(c,x,y,z,out){
 let dx,dy,dz,r;
 if(c.type==='ell'){
  dx=x-c.x;dy=y-c.y;dz=z-c.z;
  const d=Math.hypot(dx/c.rx,dy/c.ry,dz/c.rz),min=Math.min(c.rx,c.ry,c.rz);
  let nx=dx/(c.rx*c.rx),ny=dy/(c.ry*c.ry),nz=dz/(c.rz*c.rz),n=Math.hypot(nx,ny,nz);
  if(n<1e-9){out.dist=-min;out.x=1;out.y=0;out.z=0;return out;}
  out.dist=(d-1)*min;out.x=nx/n;out.y=ny/n;out.z=nz/n;return out;
 }
 if(c.type==='cyl'){
  dx=x-c.x;dz=z-c.z;const h=Math.hypot(dx,dz)||1e-9;
  const vertical=y<c.yBase?y-c.yBase:y>c.yTop?y-c.yTop:0, radial=h-c.r;
  if(vertical!==0 && radial<0){out.dist=Math.abs(vertical);out.x=0;out.y=Math.sign(vertical);out.z=0;return out;}
  if(vertical!==0 && radial>=0){let d=Math.hypot(radial,vertical);out.dist=d;out.x=dx/h*radial/d;out.y=vertical/d;out.z=dz/h*radial/d;return out;}
  out.dist=radial;out.x=dx/h;out.y=0;out.z=dz/h;return out;
 }
 if(c.type==='cap'){
  const ax=c.x1,ay=c.y1,az=c.z1,bx=c.x2-ax,by=c.y2-ay,bz=c.z2-az;
  const t=clamp(((x-ax)*bx+(y-ay)*by+(z-az)*bz)/(bx*bx+by*by+bz*bz||1),0,1);
  dx=x-ax-t*bx;dy=y-ay-t*by;dz=z-az-t*bz;r=c.r;
  const d=Math.hypot(dx,dy,dz);if(d<1e-9){out.dist=-r;out.x=1;out.y=0;out.z=0;return out;}
  out.dist=d-r;out.x=dx/d;out.y=dy/d;out.z=dz/d;return out;
 }
 out.dist=Infinity;out.x=0;out.y=0;out.z=0;return out;
}
export class SchoolSimulation {
 constructor(field, center, offsets, phases, random, colliders = [], profile = {}) {
  this.field=field;this.center=center;this.positions=offsets;this.previous=new Float32Array(offsets);
  this.velocities=new Float32Array(offsets.length);this.previousVelocities=new Float32Array(offsets.length);this.nextPositions=new Float32Array(offsets.length);
  this.nextVelocities=new Float32Array(offsets.length);this.phases=phases;this.count=phases.length;
  this.radius=profile.radius ?? 15;this.maxSpeed=profile.maxSpeed ?? 2.6;
  this.cohesion=profile.cohesion ?? .10;this.alignment=profile.alignment ?? .55;
  this.clearance=1.1;this.ceiling=-1.0;this.time=0;
  this.neighborChecks=0;this._obstacleResult={dist:Infinity,x:0,y:0,z:0};
  this.activityEnabled=!!profile.activity;
  this.bottomActivity=!!profile.bottomActivity;
  this.activityState='cruising';this.activityFactor=1;
  this.obstacles=colliders.filter(c=>{
   let x,z,reach;
   if(c.type==='ell'){x=c.x;z=c.z;reach=Math.max(c.rx,c.rz);}
   else if(c.type==='cyl'){x=c.x;z=c.z;reach=c.r;}
   else if(c.type==='cap'){x=(c.x1+c.x2)/2;z=(c.z1+c.z2)/2;reach=c.r+Math.hypot(c.x2-c.x1,c.z2-c.z1)/2;}
   else return false;
   return Math.hypot(center.x-x,center.z-z)<reach+25;
  });
  this.unresolvedSpawns=0;
  for(let i=0;i<this.count;i++){
   const j=i*3, a=random()*Math.PI*2, speed=Math.min(1.2+random()*.7,this.maxSpeed*.9);
   this.velocities[j]=Math.cos(a)*speed;this.velocities[j+1]=0;this.velocities[j+2]=Math.sin(a)*speed;
   this.constrain(j, 0, 0);
   // Seek nearby free water without deleting or relocating the school itself.
   for(let attempt=0;attempt<64 && this.inObstacle(j);attempt++){
    this.positions[j]=(random()-.5)*28;this.positions[j+2]=(random()-.5)*28;
    this.positions[j+1]=(random()-.5)*6;
    this.constrain(j,0,0);
   }
   if(this.inObstacle(j))this.unresolvedSpawns++;
  }
  this.previous.set(this.positions);this.previousVelocities.set(this.velocities);
 }
 inObstacle(j){
  const p=this.positions,c=this.center,x=c.x+p[j],y=c.y+p[j+1],z=c.z+p[j+2];
  return this.obstacles.some(o=>obstacleMayBeNear(o,x,y,z,.5)&&obstacleDistance(o,x,y,z,this._obstacleResult).dist<.5);
 }
 floor(x,z){return this.field.surfaceHeightAt ? this.field.surfaceHeightAt(x,z):this.field.heightAt(x,z);}
 constrain(j, oldX, oldZ){
  const p=this.positions,c=this.center;
  let floor=this.floor(c.x+p[j],c.z+p[j+2])+this.clearance;
  if(floor>this.ceiling){p[j]=oldX;p[j+2]=oldZ;floor=this.floor(c.x+oldX,c.z+oldZ)+this.clearance;}
  p[j+1]=clamp(c.y+p[j+1],Math.min(floor,this.ceiling),this.ceiling)-c.y;
 }
 step(dt, player, predators = []) {
  dt=clamp(dt,0,0.25); if(!dt)return;
  const p=this.positions,v=this.velocities,c=this.center,n=this.count;
  const nextP=this.nextPositions,nextV=this.nextVelocities;
  this.previous.set(p);this.previousVelocities.set(v);this.time+=dt;
  // Spatial bins preserve the same 5 m neighbourhood but avoid comparing
  // every fish to every other fish. This is rebuilt once per fixed step.
  const cells=new Map(), cellSize=5;
  for(let i=0;i<n;i++){
   const k=i*3, cx=Math.floor(p[k]/cellSize), cz=Math.floor(p[k+2]/cellSize);
   const key=cx+','+cz; let cell=cells.get(key);
   if(!cell){cell=[];cells.set(key,cell);} cell.push(i);
  }
  this.neighborChecks=0;
  // Cheap broad-phase: only predators close enough to this school's home
  // range reach the individual-fish avoidance loop. This is a behavioral
  // approximation, not a simulation of hunting or food-web population change.
  const nearbyPredators=[];
  const reach=this.radius+22;
  for(const threat of predators){
   if(!threat || !Number.isFinite(threat.x+threat.y+threat.z))continue;
   const dx=threat.x-c.x,dy=threat.y-c.y,dz=threat.z-c.z;
   if(dx*dx+dy*dy+dz*dz<reach*reach)nearbyPredators.push(threat);
  }
  this.nearbyPredatorCount=nearbyPredators.length;
  // A slow, independently phased cruise / foraging / resting cycle modulates
  // movement continuously; nearby predators override it with an alert state.
  // It is a visual behavior model, not a simulated food web or life cycle.
  if(this.activityEnabled){
   const cycle=(this.time+(this.phases[0]||0)*13.7)%88;
   this.activityState=nearbyPredators.length?'alert':cycle<52?'cruising':cycle<73?'foraging':'resting';
   const target=this.activityState==='alert'?1:this.activityState==='resting'?.42:this.activityState==='foraging'?.70:1;
   this.activityFactor+=(target-this.activityFactor)*Math.min(1,dt*.65);
  }
  const speedLimit=Math.max(.15,this.maxSpeed*this.activityFactor);
  for(let i=0;i<n;i++){
   const k=i*3,x=p[k],y=p[k+1],z=p[k+2],vx=v[k],vy=v[k+1],vz=v[k+2];
   let sepX=0,sepY=0,sepZ=0,cohX=0,cohY=0,cohZ=0,aliX=0,aliY=0,aliZ=0,near=0;
   const cx=Math.floor(x/cellSize),cz=Math.floor(z/cellSize);
   for(let gx=cx-1;gx<=cx+1;gx++)for(let gz=cz-1;gz<=cz+1;gz++){
    const cell=cells.get(gx+','+gz);if(!cell)continue;
    for(const j of cell){
     if(j===i)continue;this.neighborChecks++;
     const q=j*3,dx=p[q]-x,dy=p[q+1]-y,dz=p[q+2]-z,d2=dx*dx+dy*dy+dz*dz;
     if(d2<25 && d2>1e-6){near++;cohX+=p[q];cohY+=p[q+1];cohZ+=p[q+2];aliX+=v[q];aliY+=v[q+1];aliZ+=v[q+2];
      if(d2<2.25){const t=(1.5-Math.sqrt(d2))/Math.sqrt(d2);sepX-=dx*t;sepY-=dy*t;sepZ-=dz*t;}}
    }
   }
   let ax=sepX*1.4,ay=sepY*1.1,az=sepZ*1.4;
   if(near){ax+=(cohX/near-x)*this.cohesion+(aliX/near-vx)*this.alignment;ay+=(cohY/near-y)*this.cohesion*.8+(aliY/near-vy)*this.alignment*.9;az+=(cohZ/near-z)*this.cohesion+(aliZ/near-vz)*this.alignment;}
   const d=Math.hypot(x,z);if(d>this.radius){const pull=(d-this.radius)*.24;ax-=x/d*pull;az-=z/d*pull;}
   ay-=y*.18;
   if(this.bottomActivity && this.activityState==='foraging'){
    const target=this.floor(c.x+x,c.z+z)+1.8;
    ay+=clamp((target-(c.y+y))*.13,-.25,.25);
   }
   // Approximate avoidance of nearby analytic cores. Outer ledges and
   // cavern roofs still need exact geometry checks and remain a QA caveat.
   for(const obstacle of this.obstacles){
    const wx=c.x+x,wy=c.y+y,wz=c.z+z;
    if(!obstacleMayBeNear(obstacle,wx,wy,wz,4))continue;
    const q=obstacleDistance(obstacle,wx,wy,wz,this._obstacleResult);
    if(q.dist<4){const force=Math.min(8,(4-q.dist)*.8);ax+=q.x*force;ay+=q.y*force;az+=q.z*force;}
   }
   const wave=this.time*.30+this.phases[i];ax+=Math.cos(wave)*.10;az+=Math.sin(wave)*.10;
   if(player){const dx=c.x+x-player.x,dy=c.y+y-player.y,dz=c.z+z-player.z,dd=Math.hypot(dx,dy,dz);
     if(dd<7 && dd>.001){const push=(7-dd)*.42/dd;ax+=dx*push;ay+=dy*push;az+=dz*push;}}
   for(const threat of nearbyPredators){
     const dx=c.x+x-threat.x,dy=c.y+y-threat.y,dz=c.z+z-threat.z,dd=Math.hypot(dx,dy,dz);
     if(dd<15 && dd>.001){const push=(15-dd)*.62/dd;ax+=dx*push;ay+=dy*push*.65;az+=dz*push;}
   }
   let nx=vx+ax*dt,ny=clamp(vy+ay*dt,-.9,.9),nz=vz+az*dt,speed=Math.hypot(nx,ny,nz);
   if(speed>speedLimit){let s=speedLimit/speed;nx*=s;ny*=s;nz*=s;}
   else if(speed<Math.min(.65,speedLimit*.55)){
    const a=this.phases[i]+this.time*.12, boost=Math.min(.45,speedLimit*.30);
    nx+=Math.cos(a)*boost;nz+=Math.sin(a)*boost;
   }
   const ox=x+nx*dt,oz=z+nz*dt;let yAbs=c.y+y+ny*dt;
   const floor=this.floor(c.x+ox,c.z+oz)+this.clearance;
   if(floor>this.ceiling){nextP[k]=x;nextP[k+2]=z;nx=-vx*.6;nz=-vz*.6;}
   else {nextP[k]=ox;nextP[k+2]=oz;}
   // The next offsets are Float32 and can round slightly, so resample at the
   // stored coordinates rather than changing the original safety calculation.
   const safeFloor=this.floor(c.x+nextP[k],c.z+nextP[k+2])+this.clearance;
   if(yAbs<safeFloor){yAbs=safeFloor;ny=Math.abs(ny)*.3;}
   if(yAbs>this.ceiling){yAbs=this.ceiling;ny=-Math.abs(ny)*.3;}
   // Refuse steps entering an analytic rock core; fish already inside may
   // still move outward. Mesh outlines and cavern roofs remain separate QA.
   for(const obstacle of this.obstacles){
    const wx=c.x+nextP[k],wz=c.z+nextP[k+2];
    if(!obstacleMayBeNear(obstacle,wx,yAbs,wz,.3))continue;
    const next=obstacleDistance(obstacle,wx,yAbs,wz,this._obstacleResult).dist;
    if(next<.3){
      const old=obstacleDistance(obstacle,c.x+x,c.y+y,c.z+z,this._obstacleResult).dist;
      if(next<old){nextP[k]=x;nextP[k+2]=z;yAbs=c.y+y;nx=-vx*.4;ny=-vy*.4;nz=-vz*.4;break;}
    }
   }
   nextP[k+1]=yAbs-c.y;nextV[k]=nx;nextV[k+1]=ny;nextV[k+2]=nz;
  }
  p.set(nextP);v.set(nextV);
 }
}

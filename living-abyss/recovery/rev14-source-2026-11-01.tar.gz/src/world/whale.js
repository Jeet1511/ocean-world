// Multiple licensed animated blue whales on open-water helical patrols.
// Non-solid, sampled clearance only; no claim of real migration or
// collision-certified AI.
import * as THREE from '../../vendor/three.module.js';
import {GLTFLoader} from '../../vendor/jsm/loaders/GLTFLoader.js';
import {clone} from '../../vendor/jsm/utils/SkeletonUtils.js';
import {withShared} from '../shaders/common.js?rev=14';
import {MARINE_VS,MARINE_FS} from './large-marine.js?rev=14';

const whaleCache={};
async function loadWhaleAsset(){
  if(whaleCache.promise)return whaleCache.promise;
  whaleCache.promise=new GLTFLoader().loadAsync('./assets/models/marine_pass12/blue-whale.glb')
    .then(asset=>{whaleCache.asset=asset;return asset;});
  return whaleCache.promise;
}

export async function addBlueWhales(scene,field,colliders,plannedRoutes=null){
  const routes=plannedRoutes||planWhaleRoutes(field,colliders);
  if(!routes.length)return null;
  const asset=await loadWhaleAsset();
  if(!asset.animations.length)throw new Error('Blue-whale animation missing');
  const group=new THREE.Group();group.name='blue_whales';scene.add(group);
  const states=[],white=new THREE.DataTexture(new Uint8Array([255,255,255,255]),1,1);
  white.needsUpdate=true;
  const materials=new Map();
  for(const route of routes){
    const model=clone(asset.scene),orient=new THREE.Group();orient.rotation.y=Math.PI/2;orient.add(model);
    const mixer=new THREE.AnimationMixer(model);mixer.clipAction(asset.animations[0]).play();mixer.update(0);
    orient.updateMatrixWorld(true);
    const bounds=new THREE.Box3().setFromObject(orient),size=bounds.getSize(new THREE.Vector3()),center=bounds.getCenter(new THREE.Vector3());
    if(!Number.isFinite(size.x)||size.x<.01)throw new Error('Invalid whale model bounds');
    orient.position.copy(center).multiplyScalar(-1);
    const rig=new THREE.Group();rig.add(orient);rig.scale.setScalar(route.size/size.x);
    const host=new THREE.Group();host.name='blue_whale_visitor';host.add(rig);
    model.traverse(o=>{
      if(!o.isMesh)return;
      const old=o.material;
      if(!materials.has(old))materials.set(old,new THREE.ShaderMaterial({
        uniforms:withShared({uMap:{value:old.map||white},uBase:{value:old.color?.clone()||new THREE.Color(1,1,1)},uMapped:{value:old.map?1:0}}),
        vertexShader:MARINE_VS,fragmentShader:MARINE_FS,side:THREE.DoubleSide,
      }));
      o.material=materials.get(old);o.frustumCulled=false;
    });
    mixer.setTime(route.phase/Math.PI*asset.animations[0].duration);
    group.add(host);
    const state={...route,host,mixer};
    state.host.position.set(route.x+Math.cos(route.phase)*route.radius,route.y+Math.sin(route.phase*0.5+route.verticalPhase)*route.verticalAmp,route.z+Math.sin(route.phase)*route.radius);
    states.push(state);
  }
  function update(dt,camera){
    for(const state of states){
      const d2=state.host.position.distanceToSquared(camera),factor=d2<400?.5:1;
      state.phase+=Math.min(dt,.1)*state.speed*factor;
      const a=state.phase;
      const vertical=Math.sin(a*0.5+state.verticalPhase)*state.verticalAmp;
      const x=state.x+Math.cos(a)*state.radius;
      const z=state.z+Math.sin(a)*state.radius;
      const y=state.y+vertical;
      state.host.position.set(x,y,z);
      const vertSpeed=Math.cos(a*0.5+state.verticalPhase)*state.verticalAmp*0.5;
      const pitch=-Math.atan2(vertSpeed,state.speed*state.radius*0.9+0.01);
      const bank=-Math.cos(a)*0.35;
      const q=new THREE.Quaternion();
      q.setFromEuler(new THREE.Euler(pitch,Math.atan2(-Math.cos(a),-Math.sin(a)),bank,'YXZ'));
      state.host.quaternion.copy(q);
      state.host.visible=state.host.position.distanceToSquared(camera)<260*260;
      if(state.host.visible)state.mixer.update(dt*factor);
    }
  }
  function lodStep(dt,tier,camera){
    const limits={NEAR:{range:260,mix:1,factor:1},MEDIUM:{range:260,mix:.7,factor:.35},FAR:{range:260,mix:.4,factor:.1},OFF:{range:260,mix:0,factor:0}};
    const lim=limits[tier]||limits.OFF;
    for(const state of states){
      const d2=state.host.position.distanceToSquared(camera);
      const d=Math.sqrt(d2);
      if(d>lim.range){state.host.visible=false;continue;}
      state.host.visible=true;
      const alpha=Math.min(1,d/lim.range);
      state.phase+=Math.min(dt,.1)*state.speed*lim.factor;
      const a=state.phase;
      const vertical=Math.sin(a*0.5+state.verticalPhase)*state.verticalAmp*lim.mix;
      const x=state.x+Math.cos(a)*state.radius;
      const z=state.z+Math.sin(a)*state.radius;
      const y=state.y+vertical;
      state.host.position.set(x,y,z);
      const vertSpeed=Math.cos(a*0.5+state.verticalPhase)*state.verticalAmp*lim.mix*0.5;
      const pitch=-Math.atan2(vertSpeed,state.speed*state.radius*0.9+0.01);
      const bank=-Math.cos(a)*0.35*lim.mix;
      const q=new THREE.Quaternion();
      q.setFromEuler(new THREE.Euler(pitch,Math.atan2(-Math.cos(a),-Math.sin(a)),bank,'YXZ'));
      state.host.quaternion.copy(q);
      state.mixer.update(dt*lim.factor);
    }
  }
  return {states,update,lodStep,lodEntities:states.map(s=>s.host)};
}

// Backward-compatible single-route wrapper used by older callers.
export async function addBlueWhale(scene,field,colliders,plannedRoute=null){
  const result=await addBlueWhales(scene,field,colliders,plannedRoute?[plannedRoute]:null);
  if(!result)return null;
  const w=result.states[0];
  return {state:w,update:(dt,camera)=>result.update(dt,camera)};
}
